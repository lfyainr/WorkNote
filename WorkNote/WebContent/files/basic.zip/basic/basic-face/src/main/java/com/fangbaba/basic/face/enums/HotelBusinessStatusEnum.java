package com.fangbaba.basic.face.enums;


public enum HotelBusinessStatusEnum {
	BUSINESS_NOT(10, "未开通"),
	BUSINESS_DOING(20, "开通中"),
	BUSINESS_OK(30, "已开通"),
	;

	private final Integer id;
	private final String name;

	private HotelBusinessStatusEnum(Integer id, String name) {
		this.id = id;
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public static HotelBusinessEnum getByID(Integer id) {
		for (HotelBusinessEnum temp : HotelBusinessEnum.values()) {
			if (temp.getId().equals(id)) {
				return temp;
			}
		}
		throw MyErrorEnum.errorParm.getMyException("枚举ID错误");
	}
}
