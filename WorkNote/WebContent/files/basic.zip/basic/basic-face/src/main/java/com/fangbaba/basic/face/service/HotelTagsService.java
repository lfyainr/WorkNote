package com.fangbaba.basic.face.service;

import java.util.List;
import java.util.Map;

import com.fangbaba.basic.face.bean.BasicHotelTags;
import com.fangbaba.basic.face.bean.Tags;

/**
 * 酒店标签接口
 * @author 李善维
 */
public interface HotelTagsService {
	
	/**
	 * 更新维护酒店标签关系
	 *
	 * @param bean {hotel,tagsList}
	 */
	void updateHotelTags(String hotelpmsid, List<Long> ids);
	
	/**
	 * 查询酒店对应的标签
	 *
	 * @param hotelid
	 */
	List<Tags> queryTagsByHotelid(Long hotelid);
	
	/**
	 * 查询酒店标签和所有标签
	 * @param hotelid
	 * @return
	 */
	BasicHotelTags queryHotelTagsByHotelid(String hotelpmsid);
	
	/**
	 * 分页查酒店，然后查出酒店对应的标签
	 * @param hotelids
	 * @param pageno
	 * @param pagesize
	 * @return
	 */
	Map<String,List<Tags>> queryTagsByHotelid(int pageno, int pagesize);
	
	/**
	 * 添加标签及所属标签组
	 *
	 * @param tagList
	 */
	void addTags(List<Tags> tagList);
	
	/**
	 * 删除标签
	 *
	 * @param tagList
	 */
	void delTags(List<Tags> tagList);
	
	/**
	 * 查询所有标签
	 * @return
	 */
	public List<Tags> queryAllTags();
}
