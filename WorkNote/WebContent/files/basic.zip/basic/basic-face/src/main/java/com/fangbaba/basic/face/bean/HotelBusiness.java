package com.fangbaba.basic.face.bean;

import java.util.Date;

public class HotelBusiness {
    private Long id;

    private Long hotelid;

    private String hotelpms;

    private Integer purchasing;

    private Integer distribution;

    private Integer washing;

    private String washingmode;

    private Date distributionCreatetime;

    private Date washingCreatetime;

    private Date purchasingCreatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getHotelid() {
        return hotelid;
    }

    public void setHotelid(Long hotelid) {
        this.hotelid = hotelid;
    }

    public String getHotelpms() {
        return hotelpms;
    }

    public void setHotelpms(String hotelpms) {
        this.hotelpms = hotelpms == null ? null : hotelpms.trim();
    }

    public Integer getPurchasing() {
        return purchasing;
    }

    public void setPurchasing(Integer purchasing) {
        this.purchasing = purchasing;
    }

    public Integer getDistribution() {
        return distribution;
    }

    public void setDistribution(Integer distribution) {
        this.distribution = distribution;
    }

    public Integer getWashing() {
        return washing;
    }

    public void setWashing(Integer washing) {
        this.washing = washing;
    }

    public String getWashingmode() {
        return washingmode;
    }

    public void setWashingmode(String washingmode) {
        this.washingmode = washingmode == null ? null : washingmode.trim();
    }

    public Date getDistributionCreatetime() {
        return distributionCreatetime;
    }

    public void setDistributionCreatetime(Date distributionCreatetime) {
        this.distributionCreatetime = distributionCreatetime;
    }

    public Date getWashingCreatetime() {
        return washingCreatetime;
    }

    public void setWashingCreatetime(Date washingCreatetime) {
        this.washingCreatetime = washingCreatetime;
    }

    public Date getPurchasingCreatetime() {
        return purchasingCreatetime;
    }

    public void setPurchasingCreatetime(Date purchasingCreatetime) {
        this.purchasingCreatetime = purchasingCreatetime;
    }
}