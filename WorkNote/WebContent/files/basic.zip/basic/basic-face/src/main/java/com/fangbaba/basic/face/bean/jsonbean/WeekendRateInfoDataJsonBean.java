package com.fangbaba.basic.face.bean.jsonbean;

/**
 * @author he
 * 周末价及星期jsonbean
 */
public class WeekendRateInfoDataJsonBean {
	private String week;
	private String price;
	public String getWeek() {
		return week;
	}
	public void setWeek(String week) {
		this.week = week;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
}
