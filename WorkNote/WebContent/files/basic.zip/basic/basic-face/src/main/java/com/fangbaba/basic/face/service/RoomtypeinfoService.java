package com.fangbaba.basic.face.service;

import java.util.List;

import com.fangbaba.basic.face.bean.RoomtypeinfoModel;

/**
 * 房型扩展信息查询服务
 * @author zzy
 *
 */
public interface RoomtypeinfoService {
	
	/**
	 * 根据房型id查扩展数据
	 * @param roomtypeid
	 * @return
	 */
	public RoomtypeinfoModel findRoomtypeinfoByRoomtypeId(Long roomtypeid);
	
	/**
	 * 根据多个房型id查扩展数据
	 * @param roomtypeids
	 * @return
	 */
	public List<RoomtypeinfoModel> findRoomtypeinfoByRoomtypeIds(List<Long> roomtypeids);
	
	/**
	 * crm同步roomtypeinfo信息
	 * @param json
	 */
	public void crmRoomTypeInfoUpdate(String json);
	
	/**
	 * 同步roomtypeinfo信息
	 * @param roomtypeinfos
	 */
	public void syncRoomTypeInfos(List<RoomtypeinfoModel> roomtypeinfos);
}
