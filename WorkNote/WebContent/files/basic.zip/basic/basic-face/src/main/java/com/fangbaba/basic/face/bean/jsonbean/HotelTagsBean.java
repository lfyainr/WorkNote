package com.fangbaba.basic.face.bean.jsonbean;

import java.io.Serializable;
import java.util.List;

import com.fangbaba.basic.face.bean.Tags;

public class HotelTagsBean implements Serializable {
	
	private static final long serialVersionUID = -2464648274363691381L;
	
	/**酒店id*/
	private Long hotelid;
	/**标签列表*/
	private List<Tags> tagsList;
	
	public Long getHotelid() {
		return hotelid;
	}
	public void setHotelid(Long hotelid) {
		this.hotelid = hotelid;
	}
	public List<Tags> getTagsList() {
		return tagsList;
	}
	public void setTagsList(List<Tags> tagsList) {
		this.tagsList = tagsList;
	}
	
}
