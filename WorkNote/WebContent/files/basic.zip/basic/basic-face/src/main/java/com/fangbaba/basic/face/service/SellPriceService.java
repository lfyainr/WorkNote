package com.fangbaba.basic.face.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.fangbaba.basic.face.bean.RackRateModel;

public interface SellPriceService {
	/**
	 * @param hotelid
	 * @param roomtypeid
	 * @param date
	 * 查询价格
	 */
	BigDecimal queryPrice(Long hotelid,Long roomtypeid,String date) throws Exception;
	
	/**
	 * 按照门市价来的价格
	 * @param hotelid
	 * @param days
	 * 按时间列表取价格
	 */
	Map<String,BigDecimal> queryPriceByDaysOld(Long hotelid,List<Long> days) throws Exception;
	
	/**
	 * 新分销价格
	 * @param hotelid
	 * @param days
	 * 按时间列表取价格
	 */
	Map<String,BigDecimal> queryPriceByDays(Long hotelid,List<Long> days) throws Exception;
	
	/**
	 * @param hotelid
	 * @param roomtypeid
	 * 查询分销价
	 */
	BigDecimal querySalePrice(Long hotelid,Long roomtypeid);
	
	/**
	 * 查询门市价
	 * @param hotelid
	 * @param roomtypeids
	 * @return
	 */
	public Map<String, BigDecimal> findRackRateByConditions(Long hotelid,List<Long> roomtypeids, Date begintime, Date endtime) throws Exception;
	
	/**
	 * 签约酒店生成门市价
	 * @param hotelids
	 * @return
	 */
	public Boolean genRackRateAndDistributePrices(List<Long> hotelids);
	
}
