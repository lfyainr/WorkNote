/**
 * 
 */
package com.fangbaba.basic.face.service;

import java.math.BigDecimal;

/**
 * @author yub
 *
 */
public interface StatisticsService {

	/**
	 * 获得本区入住率排名
	 * @param pmsOrderId
	 * @return
	 */
	public BigDecimal findOccupancyRankingOfRegion(String hotelpms);
	
	/**
	 * 获得本区平均房价
	 * @param pmsOrderId
	 * @return
	 */
	public BigDecimal findMiddleRateOfRegion(String hotelpms);
}
