/**
 * @author he
 * 周末门市价json
 */
package com.fangbaba.basic.face.bean.jsonbean;

import java.util.ArrayList;
import java.util.List;

/**
 {
	uuid： //唯一标示    32位uuid
	function : syncweekend //指令名称
	timestamp : yyymmddh24miss    20150110238990
	pmstypeid： //pms厂商编码 详见代码定义 1 2 3 4等
	hotelid:’’， //酒店id
	roomtype:[{
		id:’’,  //房型id
		name:’’,  //房型名称
		data：[{
			week: , //日期  星期日0 星期一 1 星期二 2 星期三 3 星期四 4 星期五 5 星期六 6
			price:’’, //门市价
		}]
	}]
  }
 */
public class WeekendRateJsonBean {
	private String pmstypeid; // pms厂商编码 详见代码定义 1 2 3 4等
	private String hotelid;// 酒店pms
	private List<WeekendRateInfoJsonBean> roomtype = new ArrayList<WeekendRateInfoJsonBean>();
	public String getPmstypeid() {
		return pmstypeid;
	}
	public void setPmstypeid(String pmstypeid) {
		this.pmstypeid = pmstypeid;
	}
	public String getHotelid() {
		return hotelid;
	}
	public void setHotelid(String hotelid) {
		this.hotelid = hotelid;
	}
	public List<WeekendRateInfoJsonBean> getRoomtype() {
		return roomtype;
	}
	public void setRoomtype(List<WeekendRateInfoJsonBean> roomtype) {
		this.roomtype = roomtype;
	}

	

}