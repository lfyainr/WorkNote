package com.fangbaba.basic.face.bean.jsonbean;

/**
 * @author he
 * 特殊价及日期jsonbean
 */
public class DailyRateInfoDataJsonBean {
	private String day;  // 日期  yyyymmdd 
	private String price; //门市价
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
}
