package com.fangbaba.basic.face.bean;

import java.io.Serializable;

public class Hoteltags implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 919324822439949265L;

	private Long id;

    private Long hotelid;

    private Long tagid;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getHotelid() {
        return hotelid;
    }

    public void setHotelid(Long hotelid) {
        this.hotelid = hotelid;
    }

    public Long getTagid() {
        return tagid;
    }

    public void setTagid(Long tagid) {
        this.tagid = tagid;
    }
}