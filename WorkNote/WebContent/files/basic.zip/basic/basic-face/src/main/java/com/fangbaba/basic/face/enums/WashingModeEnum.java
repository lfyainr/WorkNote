package com.fangbaba.basic.face.enums;

/**
 * 
 * @author zzy
 *
 */
public enum WashingModeEnum {
	source("1", "原洗"),
	mix("2", "混洗"),;

	private final String id;
	private final String name;

	private WashingModeEnum(String id, String name) {
		this.id = id;
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public static WashingModeEnum getByID(String id) {
		for (WashingModeEnum temp : WashingModeEnum.values()) {
			if (temp.getId().equals(id)) {
				return temp;
			}
		}
		throw MyErrorEnum.errorParm.getMyException("枚举ID错误");
	}
}
