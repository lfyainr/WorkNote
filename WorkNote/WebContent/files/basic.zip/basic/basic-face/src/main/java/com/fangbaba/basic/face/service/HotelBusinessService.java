package com.fangbaba.basic.face.service;

import java.util.Date;
import java.util.List;

import com.fangbaba.basic.face.base.RetInfo;
import com.fangbaba.basic.face.bean.HotelBusiness;
import com.fangbaba.basic.face.enums.HotelBusinessEnum;

public interface HotelBusinessService {
	
	/**
	 * 打开某业务
	 * @param hotelpms
	 * @param business
	 * @return
	 */
	public RetInfo<String> openBusiness(String hotelpms, HotelBusinessEnum business);
	/**
	 * 打开某业务
	 * @param hotelpms
	 * @param business
	 * @return
	 */
	public RetInfo<String> openBusiness(String hotelpms, HotelBusinessEnum business, String optUser);
	
	/**
	 * 关闭某业务
	 * @param hotelpms
	 * @param business
	 * @return
	 */
	public RetInfo<String> closeBusiness(String hotelpms, HotelBusinessEnum business);
	/**
	 * 关闭某业务
	 * @param hotelpms
	 * @param business
	 * @return
	 */
	public RetInfo<String> closeBusiness(String hotelpms, HotelBusinessEnum business, String optUser);

	/**
	 * 查询某业务开通状态
	 * @param hotelpms
	 * @param business
	 * @return
	 */
	public RetInfo<String> queryBusinessStateByHotelpms(String hotelpms, HotelBusinessEnum business);
	
	/**
	 * @param hotelid
	 * @return
	 */
	public HotelBusiness queryHotelBusinessByHotelid(Long hotelid);
	
	/**
	 * @param hotelid
	 * @return
	 */
	public boolean updateWashMode(Long hotelid, String washingmode);
	
	/**
	 * 酒店审核通过，处理带开通的业务的状态
	 * @param hotelPms
	 */
	public void hotelConfirmSyncBusinessState(String hotelPms);
	
	/**
	 * 开通关闭业务
	 * @param hotelpms
	 * @param business
	 * @param optUser
	 * @param openDate
	 * @return
	 */
	public RetInfo<String> openBusiness(String hotelpms, HotelBusinessEnum business, String optUser, String openDate);
	/**
	 * 查询酒店业务开通情况
	 * @param hotelids
	 * @param begintime
	 * @param endtime
	 * @return 开通的酒店的id数组
	 */
	public RetInfo<List<Long>> queryHotelBusinessState(HotelBusinessEnum business, List<Long> hotelids, Date begintime, Date endtime);
}
