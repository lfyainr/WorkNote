package com.fangbaba.basic.face.bean;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 分销价格
 *
 * @author zhiwei
 * @since v1.0
 */
public class DistributionPrice implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5924969703275782961L;

	private String day;

	private BigDecimal price;

	private String week;

	private Long roomtypeId;

	private Long hotelid;

	public Long getHotelid() {
		return hotelid;
	}

	public void setHotelid(Long hotelid) {
		this.hotelid = hotelid;
	}

	public Long getRoomtypeId() {
		return roomtypeId;
	}

	public void setRoomtypeId(Long roomtypeId) {
		this.roomtypeId = roomtypeId;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public String getWeek() {
		return week;
	}

	public void setWeek(String week) {
		this.week = week;
	}

}