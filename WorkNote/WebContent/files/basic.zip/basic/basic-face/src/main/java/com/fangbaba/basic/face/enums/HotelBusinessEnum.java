package com.fangbaba.basic.face.enums;

public enum HotelBusinessEnum {
	SWITCHS("switch", "分销"),
	WASHING("washing", "洗涤"),
	PURCHASING("purchasing", "采购"),
	;

	private final String id;
	private final String name;

	private HotelBusinessEnum(String id, String name) {
		this.id = id;
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public static HotelBusinessEnum getByID(String id) {
		for (HotelBusinessEnum temp : HotelBusinessEnum.values()) {
			if (temp.getId().equals(id)) {
				return temp;
			}
		}
		throw MyErrorEnum.errorParm.getMyException("枚举ID错误");
	}
}
