package com.fangbaba.basic.face.bean;

import java.io.Serializable;
import java.util.Date;

public class Tags implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1204239682021594745L;

	private Long id;

    private String tagname;

    private Long taggroupid;

    private Date createtime;

    private Date updatetime;
    
    private Taggroup group;
    
    public Taggroup getGroup() {
		return group;
	}

	public void setGroup(Taggroup group) {
		this.group = group;
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTagname() {
        return tagname;
    }

    public void setTagname(String tagname) {
        this.tagname = tagname == null ? null : tagname.trim();
    }

    public Long getTaggroupid() {
        return taggroupid;
    }

    public void setTaggroupid(Long taggroupid) {
        this.taggroupid = taggroupid;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}