package com.fangbaba.basic.face.bean.jsonbean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
/*{
    pmstypeid:””//酒店厂商
   	timestamp: //yyymmddh24miss    20150110238990
    hotelid:’’,  //酒店id
    hotelname:'',   //酒店名称
    hotelcitycode:'',   //城市编码
    hoteladdress:'',  //酒店地址
    hotelfax:'',  //酒店传真
    hotelcontactor:'',   //酒店联系人
    hoteldesc:'',       //酒店描述
    psbcode: ‘’, //psb编码
    phone: ‘’, //电话
    roomtype:[{
      id:’’,  //房型id
      name:’’,  //房型名称
      price:’’, //门市价
      room:[{
        id:’’,  //房间id
        roomno:’’,  //房间号
      }],//房间
    }],//房型
  }*/

public class PmsHotelJsonBean implements Serializable {
	
	private static final long serialVersionUID = -5040604925248255082L;
	private String pmstype;//酒店厂商
	private String hotelid;//酒店pmsid
	private Long hotelgdsid;//酒店在gds的id
	private Map<String, Long> idsmap;
	private String hotelname;//酒店名称
	private Integer hotelcitycode; //市行政编码
	private String hoteladdress;  //酒店地址
	private String hotelfax;   //酒店传真
	private String hotelcontactor;  //酒店开关
	private String hoteldesc;   //酒店描述
	private String psbcode;//psb编码
	private String phone;//电话
	private String timestamp; //时间戳
	private List<PmsRoomtypeJsonBean> roomtype = new ArrayList<PmsRoomtypeJsonBean>();//房型列表
	
	public String getHotelname() {
		return hotelname;
	}
	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}
	
	public List<PmsRoomtypeJsonBean> getRoomtype() {
		return roomtype;
	}
	public void setRoomtype(List<PmsRoomtypeJsonBean> roomtype) {
		this.roomtype = roomtype;
	}
	public String getPmstype() {
		return pmstype;
	}
	public void setPmstype(String pmstype) {
		this.pmstype = pmstype;
	}
	public String getHotelid() {
		return hotelid;
	}
	public void setHotelid(String hotelid) {
		this.hotelid = hotelid;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}

	
	/**
	 * @return the hotelcitycode
	 */
	public Integer getHotelcitycode() {
		return hotelcitycode;
	}
	/**
	 * @param hotelcitycode the hotelcitycode to set
	 */
	public void setHotelcitycode(Integer hotelcitycode) {
		this.hotelcitycode = hotelcitycode;
	}
	/**
	 * @return the hoteladdress
	 */
	public String getHoteladdress() {
		return hoteladdress;
	}
	/**
	 * @param hoteladdress the hoteladdress to set
	 */
	public void setHoteladdress(String hoteladdress) {
		this.hoteladdress = hoteladdress;
	}
	/**
	 * @return the hotelfax
	 */
	public String getHotelfax() {
		return hotelfax;
	}
	/**
	 * @param hotelfax the hotelfax to set
	 */
	public void setHotelfax(String hotelfax) {
		this.hotelfax = hotelfax;
	}
	/**
	 * @return the hotelcontactor
	 */
	public String getHotelcontactor() {
		return hotelcontactor;
	}
	/**
	 * @param hotelcontactor the hotelcontactor to set
	 */
	public void setHotelcontactor(String hotelcontactor) {
		this.hotelcontactor = hotelcontactor;
	}
	/**
	 * @return the hoteldesc
	 */
	public String getHoteldesc() {
		return hoteldesc;
	}
	/**
	 * @param hoteldesc the hoteldesc to set
	 */
	public void setHoteldesc(String hoteldesc) {
		this.hoteldesc = hoteldesc;
	}
	/**
	 * @return the timestamp
	 */
	public String getTimestamp() {
		return timestamp;
	}
	/**
	 * @param timestamp the timestamp to set
	 */
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	
	public Long getHotelgdsid() {
		return hotelgdsid;
	}
	public void setHotelgdsid(Long hotelgdsid) {
		this.hotelgdsid = hotelgdsid;
	}
	public Map getIdsmap() {
		return idsmap;
	}
	public void setIdsmap(Map idsmap) {
		this.idsmap = idsmap;
	}
	public String getPsbcode() {
		return psbcode;
	}
	public void setPsbcode(String psbcode) {
		this.psbcode = psbcode;
	}
}
