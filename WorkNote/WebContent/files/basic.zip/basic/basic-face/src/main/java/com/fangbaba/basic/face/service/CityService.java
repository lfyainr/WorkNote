package com.fangbaba.basic.face.service;

import java.util.List;

import com.fangbaba.basic.face.base.RetInfo;
import com.fangbaba.basic.face.bean.CityModel;
import com.fangbaba.basic.face.bean.ProvinceModel;

public interface CityService {
	List<CityModel> queryAllCitys();
	List<CityModel> queryAllCitysByProvinceCode(Integer proid);

	/**
	 * 根据city Code 查询 city
	 * @param cityCode
	 * @return
	 */
	RetInfo<CityModel> queryByCode( String citycode);
}
