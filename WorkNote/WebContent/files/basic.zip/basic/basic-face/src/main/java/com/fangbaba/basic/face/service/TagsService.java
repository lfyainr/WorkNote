package com.fangbaba.basic.face.service;

import java.util.List;

import com.fangbaba.basic.face.bean.Tags;

/**
 * @author zzy
 *
 */
public interface TagsService {

	public List<Tags> queryTagsByGroupId(Long groupId);
}
