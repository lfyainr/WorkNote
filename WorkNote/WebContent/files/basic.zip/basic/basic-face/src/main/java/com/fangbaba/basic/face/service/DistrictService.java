package com.fangbaba.basic.face.service;

import java.util.List;

import com.fangbaba.basic.face.base.RetInfo;
import com.fangbaba.basic.face.bean.CityModel;
import com.fangbaba.basic.face.bean.DistrictModel;

public interface DistrictService {
	List<DistrictModel> queryAllDistricts();

	/**
	 * 根据 district Code 查询 DistrictModel
	 * @param districtcode
	 * @return
	 */
	RetInfo<DistrictModel> queryByCode( String districtcode);
}
