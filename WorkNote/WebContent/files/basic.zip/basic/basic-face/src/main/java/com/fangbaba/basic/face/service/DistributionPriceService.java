package com.fangbaba.basic.face.service;

import java.util.List;

import com.fangbaba.basic.face.bean.DistributionPrice;
import com.fangbaba.basic.face.bean.RackDistributePrice;

/**
 * 分销特殊价格服务
 *
 * @author zhiwei
 * @since v1.0
 */
public interface DistributionPriceService {

	/**
	 * 保存特殊价格（GDS）
	 * 
	 * @param message
	 * @return
	 */
	public Integer saveDistributionSpecialPrice(String message);

	/**
	 * 保存日常价格
	 * 
	 * @param message
	 * @return
	 */
	public Integer saveDistributionDailPrice(String message);

	/**
	 * 查询日常价格（GDS）
	 * 
	 * @param hotelPms
	 * @param roomtypePmsNo
	 * @return
	 */
	public RackDistributePrice queryDistributionDailPrice(String hotelPms, String roomtypePmsNo);

	/**
	 * 查询分销价格（GDS）
	 * 
	 * @param hotelPmsNo
	 * @param roomtypePmsNo
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	public List<DistributionPrice> queryDistributionPrice(String hotelPmsNo, String roomtypePmsNo, String startTime, String endTime);

	public List<DistributionPrice> queryDistributionPriceByhotelIdAndRoomTypeId(Long hotelid, Long roomtypeId, String startTime, String endTime);

}
