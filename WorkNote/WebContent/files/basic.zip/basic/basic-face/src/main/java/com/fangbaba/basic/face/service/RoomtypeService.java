package com.fangbaba.basic.face.service;

import java.math.BigDecimal;
import java.util.List;

import com.fangbaba.basic.face.bean.RoomtypeModel;
import com.fangbaba.basic.face.bean.jsonbean.PmsRoomtypeJsonBean;
import com.fangbaba.basic.face.bean.jsonbean.RoomtypeJsonBean;

public interface RoomtypeService {
	/**
	 * @param id
	 *            通过房型id查门市价
	 */
	BigDecimal queryPriceByRoomTypeId(Long id);

	/**
	 * @param hotelid
	 *            通过酒店id查询房型列表
	 */
	List<RoomtypeModel> queryByHotelId(Long hotelid);

	/**
	 * @param pms
	 *            通过pms号查询
	 */
	RoomtypeModel queryByPmsAndHotelid(String pms, Long hotelid);

	/**
	 * @param id
	 *            通过房型id查询
	 */
	public RoomtypeModel queryById(Long id);
	
	/**
	 * 
	 * @param roomtypeids
	 * @return
	 */
	public List<RoomtypeModel> queryByIds(List<Long> roomtypeids);

	/**
	 * 增加房型
	 *
	 * @param roomtypeModel
	 */
	public void addRoomtype(RoomtypeModel roomtypeModel);

	/**
	 * 同步HMS基本房型、房间信息
	 *
	 * @param roomtypeModels
	 * @return
	 */
	boolean syncRoomtypeForHMS(List<RoomtypeJsonBean> roomtypeModels);

	/**
	 * 根据pms房型id和房间id查询
	 * 
	 * @param hotelid
	 * @param pmsString
	 * @return
	 */
	List<RoomtypeModel> queryByRoomtypePmsAndHotelId(Long hotelid, String pmsString);
	
	/**
	 * Crm同步房型信息
	 * @param hotelid
	 * @param roomtypes
	 */
	public void syncRoomtypes(Long hotelid, List<PmsRoomtypeJsonBean> roomtypes);
}
