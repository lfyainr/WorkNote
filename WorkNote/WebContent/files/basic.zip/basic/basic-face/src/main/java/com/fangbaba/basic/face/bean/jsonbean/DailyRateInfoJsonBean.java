package com.fangbaba.basic.face.bean.jsonbean;

import java.util.ArrayList;
import java.util.List;

/**
 * @author yub 特殊价详细jsonbean
 */
public class DailyRateInfoJsonBean {
	private String id;// 房型pms
	private String name;// 房型名称
	private List<DailyRateInfoDataJsonBean> data = new ArrayList<DailyRateInfoDataJsonBean>();// 门市价

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<DailyRateInfoDataJsonBean> getData() {
		return data;
	}

	public void setData(List<DailyRateInfoDataJsonBean> data) {
		this.data = data;
	}

}
