package com.fangbaba.basic.face.bean;

import java.io.Serializable;
import java.util.List;

public class BasicHotelTags implements Serializable{

	private static final long serialVersionUID = 4366065991017614134L;

	
	/**
	 * 所有标签
	 */
	private List<Tags> allTags;

	/**
	 * 酒店关联的标签
	 */
	private List<Tags> hotelTags;
	
	public List<Tags> getAllTags() {
		return allTags;
	}

	public void setAllTags(List<Tags> allTags) {
		this.allTags = allTags;
	}

	public List<Tags> getHotelTags() {
		return hotelTags;
	}

	public void setHotelTags(List<Tags> hotelTags) {
		this.hotelTags = hotelTags;
	}

}
