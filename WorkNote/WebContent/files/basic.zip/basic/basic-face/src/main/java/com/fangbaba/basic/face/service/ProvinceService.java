package com.fangbaba.basic.face.service;

import java.util.List;

import com.fangbaba.basic.face.base.RetInfo;
import com.fangbaba.basic.face.bean.ProvinceModel;

public interface ProvinceService {
	List<ProvinceModel> queryAllProvinces();

	/**
	 * 根据province Code 查询 province
	 * @param provCode
	 * @return
	 */
	RetInfo<ProvinceModel> queryByCode( String provCode);
}
