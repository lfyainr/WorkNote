package com.fangbaba.basic.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fangbaba.basic.face.service.StatisticsService;
import com.fangbaba.basic.service.HotelService;
//import com.fangbaba.basic.face.service.OtaRoomtypeService;

@Controller
@RequestMapping(value = "/basic")
public class HotelESController {

	
	private static Logger logger = LoggerFactory.getLogger(HotelESController.class);
	
	@Autowired
	private HotelService hotelService;
	@Autowired
	private StatisticsService statisticsService;
	

	@RequestMapping(value = "/initeshotel", method = RequestMethod.POST)
	public ResponseEntity<String> initESHotel() {
		logger.info("HotelESController /initESHotel begin");
		hotelService.initESHotelInfo();
		return new ResponseEntity<String>("ok", HttpStatus.OK);
	}

	
	
	/**
	 * 测试统计接口(测试完成后 丢弃 注释 作记录 )
	 * @param hotelpms
	 * @return
	 */
//	@RequestMapping(value = "/statistics", method = RequestMethod.POST)
//	public ResponseEntity<Map<String, Object>> findStatistics(String hotelpms) {
//		BigDecimal middlerate = statisticsService.findMiddleRateOfRegion(hotelpms);
//		BigDecimal occupancyrate = statisticsService.findOccupancyRankingOfRegion(hotelpms);
//		Map<String, Object> map = new HashMap<String, Object>();
//		map.put("middlerate", middlerate);
//		map.put("occupancyrate", occupancyrate);
//		return new ResponseEntity<Map<String, Object>>(map, HttpStatus.OK);
//	}
}
