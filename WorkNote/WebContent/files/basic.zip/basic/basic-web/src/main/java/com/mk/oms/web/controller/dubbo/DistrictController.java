package com.mk.oms.web.controller.dubbo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.bean.DistributionPrice;
import com.fangbaba.basic.face.bean.RackDistributePrice;
import com.fangbaba.basic.face.service.DistributionPriceService;
import com.mk.oms.bean.ResultDubbo;

/**
 * 分销相关的读取dubbo数据并返回前端的接口
 * 
 * @author ananyuan
 *
 */
@Controller
@RequestMapping("/district")
public class DistrictController {
	private Logger log = Logger.getLogger(getClass());

	@Autowired
	private DistributionPriceService distributionPriceService;

	/**
	 * 查询平时价格
	 * 
	 * @param request
	 * @param roomtypePmsNo
	 *            房型ID
	 * @return
	 */
	@RequestMapping(value = "/query/normal")
	@ResponseBody
	public ResultDubbo queryNormal() {
		String hotelId = "3ZyeYNlYZ6LEhi6WWak1";

		RackDistributePrice rtnObj = distributionPriceService.queryDistributionDailPrice(hotelId, "174We7hIxdaV8mRg5aN31qj");

		ResultDubbo result = new ResultDubbo(true);
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("price", rtnObj.getPrice());

		result.set_DATA_(data);

		return result;
	}

	/**
	 * 查询分销价格
	 * 
	 * @param request
	 * @param roomtypePmsNo
	 *            房型ID
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/query/days")
	@ResponseBody
	public ResultDubbo queryDays(String roomtypePmsNo, String startTime, String endTime) throws Exception {
		String hotelId = "";

		List<DistributionPrice> priceList = distributionPriceService.queryDistributionPrice(hotelId, roomtypePmsNo, startTime, endTime);

		ResultDubbo result = new ResultDubbo(true);
		result.set_DATA_(priceList);

		return result;
	}

	/**
	 * 设置平时价格
	 * 
	 * @param request
	 * @param roomtypePmsNo
	 *            房型ID
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/save/normal")
	@ResponseBody
	public ResultDubbo saveNormal() throws Exception {
		String hotelId = "";

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("hotelPmsNo", hotelId);
		JSONArray jsonArray = new JSONArray();

		JSONObject price = new JSONObject();
		price.put("roomtypePmsNo", "174We7hIxdaV8mRg5aN31qj");
		price.put("price", new BigDecimal(10.00));
		jsonArray.add(price);

		jsonObject.put("price", jsonArray);

		int rtnValue = distributionPriceService.saveDistributionSpecialPrice(jsonObject.toString());

		ResultDubbo result = new ResultDubbo(true);

		return result;
	}

	/**
	 * 设置特殊价格
	 * 
	 * @param request
	 * @param roomtypePmsNo
	 *            房型ID
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/save/special")
	@ResponseBody
	public ResultDubbo saveSpecial(HttpServletRequest request, String roomtypePmsNo) throws Exception {
		String hotelId = "";

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("hotelPmsNo", hotelId);
		JSONArray jsonArray = new JSONArray();

		JSONObject price = new JSONObject();
		price.put("roomtypePmsNo", "174We7hIxdaV8mRg5aN31qj");
		price.put("price", new BigDecimal(10.00));
		price.put("day", "2016-02-28");
		jsonArray.add(price);

		jsonObject.put("price", jsonArray);

		int rtnValue = distributionPriceService.saveDistributionSpecialPrice(jsonObject.toString());

		ResultDubbo result = new ResultDubbo(true);

		return result;
	}

	/**
	 * 根据开始时间、结束时间得到两个时间段内所有的日期
	 * 
	 * @param start
	 *            开始日期
	 * @param end
	 *            结束日期
	 * @return 两个日期之间的日期
	 */
	public List<Long> getDateList(Date start, Date end) {
		List<Long> ret = new ArrayList<Long>();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(start);
		Date tmpDate = calendar.getTime();
		long endTime = end.getTime();
		while (tmpDate.before(end) || tmpDate.getTime() == endTime) {
			ret.add(calendar.getTime().getTime());
			calendar.add(Calendar.DATE, 1);
			tmpDate = calendar.getTime();
		}
		return ret;
	}
}
