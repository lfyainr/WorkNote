package com.fangbaba.basic.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.base.RetInfo;
import com.fangbaba.basic.face.bean.CityModel;
import com.fangbaba.basic.face.bean.DistrictModel;
import com.fangbaba.basic.face.bean.HotelModel;
import com.fangbaba.basic.face.bean.MyException;
import com.fangbaba.basic.face.bean.ProvinceModel;
import com.fangbaba.basic.face.bean.RoomModel;
import com.fangbaba.basic.face.bean.RoomtypeModel;
import com.fangbaba.basic.face.bean.Tags;
import com.fangbaba.basic.face.bean.vo.HotelVo;
import com.fangbaba.basic.face.enums.HotelBusinessEnum;
import com.fangbaba.basic.face.service.CityService;
import com.fangbaba.basic.face.service.DistrictService;
import com.fangbaba.basic.face.service.HotelBusinessService;
import com.fangbaba.basic.face.service.HotelSaleConfigService;
import com.fangbaba.basic.face.service.HotelTagsService;
//import com.fangbaba.basic.face.service.OtaRoomtypeService;
import com.fangbaba.basic.face.service.ProvinceService;
import com.fangbaba.basic.kafka.StandardKafkaConsumer;
import com.fangbaba.basic.service.HotelService;
import com.fangbaba.basic.service.RoomService;
import com.fangbaba.basic.service.RoomtypeService;
import com.fangbaba.basic.service.SellPriceService;
import com.fangbaba.order.common.utils.DateUtils;

@Controller
@RequestMapping(value = "/basic")
public class BasicController {

	
	private static Logger logger = LoggerFactory.getLogger(BasicController.class);
	@Autowired
	private HotelService hotelService;
	
	@Autowired
	private CityService cityService;
	
	@Autowired
	private RoomService roomService;
	
	@Autowired
	private RoomtypeService roomtypeService;
	
	@Autowired
	private DistrictService districtService;
	
	@Autowired
	private ProvinceService provinceService;
//	@Autowired
//	private OtaRoomtypeService otaRoomtypeService;
	@Autowired
	private HotelSaleConfigService hotelSaleConfigService;
	@Autowired
	private StandardKafkaConsumer consumer;
	@Autowired
	private SellPriceService sellPriceService;
	@Autowired
	private HotelTagsService hotelTagsService;
	@Autowired
	private HotelBusinessService hotelBusinessService;
	
	@RequestMapping(value = "/synchotel", method = RequestMethod.POST)
	public ResponseEntity<String> searchES(String json) {
		logger.info("basiccontroller /synchotel begin param:{}",json);
		hotelService.syncHotelInfo(json);
		return new ResponseEntity<String>("ok", HttpStatus.OK);
	}
	
	@RequestMapping(value = "/queryallhotels", method = RequestMethod.POST)
	public ResponseEntity<List<HotelModel>> queryAllHotels(){
		return new ResponseEntity<List<HotelModel>>(hotelService.queryAllHotels(), HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/querybyid", method = RequestMethod.POST)
	public ResponseEntity<HotelModel>  queryById(Long id){
		return new ResponseEntity<HotelModel>(hotelService.queryById(id), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/queryhotelbypms", method = RequestMethod.POST)
	public ResponseEntity<HotelModel>  queryHotelByPms(String pms){
		return new ResponseEntity<HotelModel>(hotelService.queryByPms(pms), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/querydetail", method = RequestMethod.POST)
	public ResponseEntity<HotelVo>  queryDetail(Long id,String begintime,String endtime){
		return new ResponseEntity<HotelVo>(hotelService.queryDetail(id, begintime, endtime), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/queryallcitys", method = RequestMethod.POST)
	public ResponseEntity<List<CityModel>>  queryAllCitys(){
		return new ResponseEntity<List<CityModel>>(cityService.queryAllCitys(), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/queryalldistricts", method = RequestMethod.POST)
	public ResponseEntity<List<DistrictModel>>  queryAllDistricts(){
		return new ResponseEntity<List<DistrictModel>>(districtService.queryAllDistricts(), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/queryallprovinces", method = RequestMethod.POST)
	public ResponseEntity<List<ProvinceModel>>  queryAllProvinces(){
		return new ResponseEntity<List<ProvinceModel>>(provinceService.queryAllProvinces(), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/querybyroomtypeid", method = RequestMethod.POST)
	public ResponseEntity<List<RoomModel>>  queryByRoomTypeId(Long roomtypeid){
		return new ResponseEntity<List<RoomModel>>(roomService.queryByRoomTypeId(roomtypeid), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/queryroombypms", method = RequestMethod.POST)
	public ResponseEntity<RoomModel>  queryRoomByPms(String pms){
		return new ResponseEntity<RoomModel>(roomService.queryByPms(pms), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/queryroombyid", method = RequestMethod.POST)
	public ResponseEntity<RoomModel>  queryRoomById(Long id){
		return new ResponseEntity<RoomModel>(roomService.queryById(id), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/delroombyroomtypeid", method = RequestMethod.POST)
	public ResponseEntity<String>  delRoomByRoomtypeid(Long roomtypeid){
		roomService.delRoomByRoomtypeid(roomtypeid);
		return new ResponseEntity<String>("OK", HttpStatus.OK);
	}
	
	@RequestMapping(value = "/querypricebyroomtypeid", method = RequestMethod.POST)
	public ResponseEntity<BigDecimal>  queryPriceByRoomTypeId(Long id){
		return new ResponseEntity<BigDecimal>(roomtypeService.queryPriceByRoomTypeId(id), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/querybyhotelid", method = RequestMethod.POST)
	public ResponseEntity<List<RoomtypeModel>>  queryByHotelId(Long id){
		return new ResponseEntity<List<RoomtypeModel>>(roomtypeService.queryByHotelId(id), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/querybypms", method = RequestMethod.POST)
	public ResponseEntity<RoomtypeModel>  queryByPms(String pms,Long hotelid){
		return new ResponseEntity<RoomtypeModel>(roomtypeService.queryByPmsAndHotelid(pms, hotelid), HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/queryroomtypebyid", method = RequestMethod.POST)
	public ResponseEntity<RoomtypeModel>  queryRoomTypeById(Long id){
		return new ResponseEntity<RoomtypeModel>(roomtypeService.queryById(id), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/savehotelconfig/{hotelid}/{salenum}", method = RequestMethod.GET)
	public ResponseEntity<String>  savehotelconfig(@PathVariable Long hotelid,@PathVariable Integer salenum){
		String s = "success";
		hotelSaleConfigService.saveConfig(hotelid, salenum);
		return new ResponseEntity<String>(s, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/syncrackrate", method = RequestMethod.POST)
	public ResponseEntity<String> syncrackrate(String json) {
		consumer.consumeRackRate(json);
		return new ResponseEntity<String>("ok", HttpStatus.OK);
	}
	@RequestMapping(value = "/syncweekendrate", method = RequestMethod.POST)
	public ResponseEntity<String> syncweekendrate(String json) {
		consumer.consumeWeekendRate(json);
		return new ResponseEntity<String>("ok", HttpStatus.OK);
	}
	@RequestMapping(value = "/syncdailyrate", method = RequestMethod.POST)
	public ResponseEntity<String> syncdailyrate(String json) {
		consumer.consumeDailyRate(json);
		return new ResponseEntity<String>("ok", HttpStatus.OK);
	}
	@RequestMapping(value = "/queryprice", method = RequestMethod.POST)
	public ResponseEntity<BigDecimal> queryprice(Long hotelid,Long roomtypeid,String date) throws Exception {
		BigDecimal price = sellPriceService.queryPrice(hotelid, roomtypeid, date);
		return new ResponseEntity<BigDecimal>(price, HttpStatus.OK);
	}
	@RequestMapping(value = "/queryTagsByHotelid", method = RequestMethod.POST)
	public ResponseEntity<JSONArray> queryTagsByHotelid(HttpServletRequest request) throws Exception {
		String hotelid = request.getParameter("hotelid");
		checkParam(request, "hotelid");
		
		List<Tags> tags = hotelTagsService.queryTagsByHotelid(Long.parseLong(hotelid));
		
		JSONArray j = new JSONArray();
		if (tags != null && tags.size() > 0) {
			j = (JSONArray) JSONArray.toJSON(tags);
		}
		return new ResponseEntity<JSONArray>(j, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/queryhotelbytagids", method = RequestMethod.POST)
	public ResponseEntity<JSONObject> queryhotelbytagids(HttpServletRequest request) throws Exception {
		checkParam(request, "pageno,pagesize,tagids");
		String pageno = request.getParameter("pageno");
		String pagesize = request.getParameter("pagesize");
		String _tagids = request.getParameter("tagids");
		String _tagids2 = request.getParameter("tagids2");
		String hotelname = request.getParameter("hotelname");
		HotelModel h = new HotelModel();
		h.setHotelname(hotelname);
		List<Long> tagids = new ArrayList<>();
		for (String id : _tagids.split(",")) {
			tagids.add(Long.parseLong(id));
		}
		List<Long> tagids2 = new ArrayList<>();
		for (String id : _tagids2.split(",")) {
			tagids2.add(Long.parseLong(id));
		}
		List<List<Long>> _ids = new ArrayList<>();
		_ids.add(tagids);
		_ids.add(tagids2);
		Map<String, Object> m = hotelService.queryByConditions(h, _ids, Integer.parseInt(pageno), Integer.parseInt(pagesize));
		JSONObject j = new JSONObject(m);
		System.err.println(j.toJSONString());
		return new ResponseEntity<JSONObject>(j, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/openWashing", method = RequestMethod.POST)
	public ResponseEntity<Boolean> openWashing(HttpServletRequest request) throws Exception {
		String pmsid = request.getParameter("hotelpmsid");
		String optuser = request.getParameter("optuser");
		String opendate = request.getParameter("opendate");
		optuser = optuser == null ? "酒店老板":optuser;
		RetInfo<String> r = hotelBusinessService.openBusiness(pmsid, HotelBusinessEnum.WASHING, optuser, opendate);
		return new ResponseEntity<Boolean>(r.isResult(), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/closeWashing", method = RequestMethod.POST)
	public ResponseEntity<Boolean> closeWashing(HttpServletRequest request) throws Exception {
		String pmsid = request.getParameter("hotelpmsid");
		String optuser = request.getParameter("optuser");
		optuser = optuser == null ? "酒店老板":optuser;
		RetInfo<String> r = hotelBusinessService.closeBusiness(pmsid, HotelBusinessEnum.WASHING, optuser);
		return new ResponseEntity<Boolean>(r.isResult(), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/queryWashingByHotelpms", method = RequestMethod.POST)
	public ResponseEntity<Boolean> queryWashingByHotelpms(HttpServletRequest request) throws Exception {
		String pmsid = request.getParameter("hotelpmsid");
		RetInfo<String> r = hotelBusinessService.queryBusinessStateByHotelpms(pmsid, HotelBusinessEnum.WASHING);
		return new ResponseEntity<Boolean>(r.isResult(), HttpStatus.OK);
	}

	public void checkParam(HttpServletRequest request, String params) {
		if (params != null && params.length() > 0) {
			for (String p : params.split(",")) {
				String param = request.getParameter(p);
				if (StringUtils.isBlank(param)) {
					throw new MyException("-1", "参数：" + p + "不可以为空");
				}
			}
		}
	}

	@RequestMapping(value = "/queryProvenceBycode", method = RequestMethod.POST)
	public ResponseEntity<RetInfo<ProvinceModel>> queryProvenceBycode(HttpServletRequest request) throws Exception {
		String pmsid = request.getParameter("provcode");
		RetInfo<ProvinceModel> r = provinceService.queryByCode(pmsid);
		return new ResponseEntity<RetInfo<ProvinceModel>>(r, HttpStatus.OK);
	}
	@RequestMapping(value = "/queryCityBycode", method = RequestMethod.POST)
	public ResponseEntity<RetInfo<CityModel>> queryCityBycode(HttpServletRequest request) throws Exception {
		String pmsid = request.getParameter("citycode");
		RetInfo<CityModel> r = cityService.queryByCode(pmsid);
		return new ResponseEntity<RetInfo<CityModel>>(r, HttpStatus.OK);
	}
	@RequestMapping(value = "/queryDistrictBycode", method = RequestMethod.POST)
	public ResponseEntity<RetInfo<DistrictModel>> queryDistrictBycode(HttpServletRequest request) throws Exception {
		String pmsid = request.getParameter("discode");
		RetInfo<DistrictModel> r =  districtService.queryByCode(pmsid);
		return new ResponseEntity<RetInfo<DistrictModel>>(r, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/findrackrates", method = RequestMethod.POST)
	public ResponseEntity<JSONObject> findrackrates(HttpServletRequest request) throws Exception {
		checkParam(request, "begintime,endtime");
		String hotelid = request.getParameter("hotelid");
		String roomtypeids = request.getParameter("roomtypeids");
		roomtypeids = roomtypeids == null ? "":roomtypeids;
		String begintime = request.getParameter("begintime");
		String endtime = request.getParameter("endtime");
		List<Long> _roomtypeids = new ArrayList<>();
		for (String i : roomtypeids.split(",")) {
			if (StringUtils.isNotBlank(i)) {
				_roomtypeids.add(Long.parseLong(i));
			}
		}
		Map<String, BigDecimal> m = sellPriceService.findRackRateByConditions(StringUtils.isBlank(hotelid) ? null : Long.parseLong(hotelid), _roomtypeids, DateUtils.getDateFromString(begintime), DateUtils.getDateFromString(endtime));
		JSONObject j = new JSONObject();
		j.putAll(m);
		System.err.println(j.toJSONString());
		return new ResponseEntity<JSONObject>(j, HttpStatus.OK);
	}
	@RequestMapping(value = "/queryhotelbusinessstate", method = RequestMethod.POST)
	public ResponseEntity<JSONObject> queryHotelBusinessState(HttpServletRequest request) throws Exception {
		checkParam(request, "begintime,endtime");
		String _business = request.getParameter("business");
		String hotelids = request.getParameter("hotelids");
		hotelids = hotelids == null ? "":hotelids;
		String begintime = request.getParameter("begintime");
		String endtime = request.getParameter("endtime");
		List<Long> _hotelids = new ArrayList<>();
		for (String i : hotelids.split(",")) {
			if (StringUtils.isNotBlank(i)) {
				_hotelids.add(Long.parseLong(i));
			}
		}
		HotelBusinessEnum business = HotelBusinessEnum.getByID(_business);
		RetInfo<List<Long>> ret = hotelBusinessService.queryHotelBusinessState(business, _hotelids, DateUtils.getDateFromString(begintime), DateUtils.getDateFromString(endtime));
		JSONObject j = new JSONObject();
		j.put("list", ret.getObj());
		System.err.println(j.toJSONString());
		return new ResponseEntity<JSONObject>(j, HttpStatus.OK);
	}
}
