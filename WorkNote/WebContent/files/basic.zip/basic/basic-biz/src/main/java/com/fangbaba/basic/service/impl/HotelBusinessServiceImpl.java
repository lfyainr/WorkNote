package com.fangbaba.basic.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.base.RetInfo;
import com.fangbaba.basic.face.bean.HotelBusiness;
import com.fangbaba.basic.face.bean.HotelBusinessExample;
import com.fangbaba.basic.face.bean.HotelBusinessExample.Criteria;
import com.fangbaba.basic.face.bean.HotelModel;
import com.fangbaba.basic.face.bean.MyException;
import com.fangbaba.basic.face.enums.HotelBusinessEnum;
import com.fangbaba.basic.face.enums.HotelBusinessStatusEnum;
import com.fangbaba.basic.face.enums.MyErrorEnum;
import com.fangbaba.basic.face.service.HotelBusinessService;
import com.fangbaba.basic.face.service.HotelService;
import com.fangbaba.basic.kafka.StandardKafkaProducer;
import com.fangbaba.basic.mappers.HotelBusinessMapper;
import com.fangbaba.basic.util.MD5Util;
import com.fangbaba.basic.util.NetUtil;
import com.fangbaba.basic.util.UrlUtil;
import com.fangbaba.order.common.utils.DateUtils;
import com.lz.mongo.bislog.BisLog;
import com.lz.mongo.bislog.BisLogDelegate;

@Service
public class HotelBusinessServiceImpl implements HotelBusinessService {
	private static final Logger logger = LoggerFactory.getLogger(HotelBusinessServiceImpl.class);
	
	@Autowired
	private HotelService hotelService;
	@Autowired
	private HotelBusinessMapper hotelBusinessMapper;
	@Autowired
	private StandardKafkaProducer kafkaProducer;
	@Autowired
	private BisLogDelegate bisLogDelegate;
	
	private static Map<String, Integer> businessStatusMap = new HashMap<>();
	static {
		// 各个业务的开通、关闭对应的字典
		businessStatusMap.put(HotelBusinessEnum.SWITCHS.getId() + "T", HotelBusinessStatusEnum.BUSINESS_OK.getId());
		businessStatusMap.put(HotelBusinessEnum.SWITCHS.getId() + "F", HotelBusinessStatusEnum.BUSINESS_NOT.getId());
		businessStatusMap.put(HotelBusinessEnum.WASHING.getId() + "T", HotelBusinessStatusEnum.BUSINESS_OK.getId());
		businessStatusMap.put(HotelBusinessEnum.WASHING.getId() + "F", HotelBusinessStatusEnum.BUSINESS_NOT.getId());
		businessStatusMap.put(HotelBusinessEnum.PURCHASING.getId() + "T", HotelBusinessStatusEnum.BUSINESS_OK.getId());
		businessStatusMap.put(HotelBusinessEnum.PURCHASING.getId() + "F", HotelBusinessStatusEnum.BUSINESS_NOT.getId());
	}

	@Override
	public RetInfo<String> openBusiness(String hotelpms, HotelBusinessEnum business, String optUser) {
		logger.info("openBusiness,{},business:{},optuser:{}", hotelpms, business, optUser);
		RetInfo<String> retInfo = updateBusinessData(hotelpms, business, "T", optUser, null);
		return retInfo;
	}
	
	@Override
	public RetInfo<String> openBusiness(String hotelpms, HotelBusinessEnum business, String optUser, String openDate) {
		logger.info("openBusiness,{},business:{},optuser:{},openDate:{}", hotelpms, business, optUser, openDate);
		RetInfo<String> retInfo = updateBusinessData(hotelpms, business, "T", optUser, openDate);
		return retInfo;
	}
	
	@Override
	public RetInfo<String> openBusiness(String hotelpms, HotelBusinessEnum business) {
		logger.info("openBusiness,{},business:{}", hotelpms, business);
		RetInfo<String> retInfo = updateBusinessData(hotelpms, business, "T", "system", null);
		return retInfo;
	}
	
	@Override
	public RetInfo<String> closeBusiness(String hotelpms, HotelBusinessEnum business) {
		logger.info("closeBusiness,{},business:{}", hotelpms, business);
		RetInfo<String> retInfo = updateBusinessData(hotelpms, business, "F", "system", null);
		return retInfo;
	}

	private RetInfo<String> updateBusinessData(String hotelpms, HotelBusinessEnum business, String optflag, String optUser, String openDate) {
		logger.info("updateBusinessData,hotelpms:{},business:{},flag:{},openDate:{}", hotelpms, business, optflag, openDate);
		RetInfo<String> retInfo = new RetInfo<String>();
		HotelModel hotelModel = hotelService.queryByPms(hotelpms.trim());
		if (hotelModel == null) {
			logger.info("通过pms查询不到酒店");
			retInfo.setCode(MyErrorEnum.customError.getErrorCode());
			retInfo.setResult(false);
			retInfo.setMsg("通过pms查询不到酒店");
			return retInfo;
		}
		Integer flag = getOpenFlag(hotelModel, business, optflag);
		
		HotelBusinessExample example = new HotelBusinessExample();
		Criteria criteria = example.createCriteria();
		criteria.andHotelpmsEqualTo(hotelpms);
		List<HotelBusiness> hotelBusiness = hotelBusinessMapper.selectByExample(example);
		if (CollectionUtils.isNotEmpty(hotelBusiness)) {// 存在 update
			for (HotelBusiness bis : hotelBusiness) {
				setStatusByBusiness(bis, business, flag, optUser, openDate);
				hotelBusinessMapper.updateByPrimaryKey(bis);
			}
		} else {
			HotelBusiness bis = new HotelBusiness();
			bis.setHotelpms(hotelpms);
			bis.setHotelid(hotelModel.getId());
			setStatusByBusiness(bis, business, flag, optUser, openDate);
			hotelBusinessMapper.insertSelective(bis);
		}
		retInfo.setResult(true);
		// 酒店业务开通关闭发送消息
		hotelBusinessChangeSendMessage(business, hotelModel, flag);
		
		return retInfo;
	}


	@Override
	public RetInfo<String> closeBusiness(String hotelpms, HotelBusinessEnum business, String optUser) {
		logger.info("closeBusiness,{},business:{},optuser:{}", hotelpms, business, optUser);
		RetInfo<String> retInfo = updateBusinessData(hotelpms, business, "F", optUser, null);
		return retInfo;
	}

	@Override
	public RetInfo<String> queryBusinessStateByHotelpms(String hotelpms, HotelBusinessEnum business) {
		logger.info("queryBusinessStateByHotelpms,{},{}", hotelpms, business);
		RetInfo<String> retInfo = new RetInfo<String>();
		HotelModel hotelModel = hotelService.queryByPms(hotelpms.trim());
		if (hotelModel == null) {
			logger.info("通过pms查询不到酒店");
			retInfo.setCode(MyErrorEnum.customError.getErrorCode());
			retInfo.setResult(false);
			retInfo.setMsg("通过pms查询不到酒店");
			return retInfo;
		}
		HotelBusinessExample example = new HotelBusinessExample();
		Criteria criteria = example.createCriteria();
		criteria.andHotelpmsEqualTo(hotelpms);
		List<HotelBusiness> hotelBusinesses = hotelBusinessMapper.selectByExample(example);
		if (CollectionUtils.isNotEmpty(hotelBusinesses)) {// 存在 update
			logger.info("hotelBusinesses is:{}", JSONObject.toJSON(hotelBusinesses));
			for (HotelBusiness hotelBusiness : hotelBusinesses) {
				retInfo.setResult(true);
				retInfo.setObj("F");
				// 获取当前业务的状态字典码
				Integer status = getStatusByBusiness(business, hotelBusiness);
				// 大于F的（> 100），则开通过，返回T
				if (status != null && status.intValue() > businessStatusMap.get(business.getId() + "F").intValue()) {
					retInfo.setObj("T");
				}
				// 等于F，则没有开通过，返回F
				if (status == null || status.intValue() == businessStatusMap.get(business.getId() + "F").intValue()) {
					retInfo.setObj("F");
				} 
				logger.info("返回1,retinfo:{}", JSONObject.toJSON(retInfo));		
				return retInfo;
			}
		} else {
			retInfo.setResult(true);
			retInfo.setObj("F");
			retInfo.setCode("");
			retInfo.setMsg("");
			return retInfo;
		}
		logger.info("返回2,retinfo:{}", JSONObject.toJSON(retInfo));
		return retInfo;
	}
	
	@Override
	public HotelBusiness queryHotelBusinessByHotelid(Long hotelid){
		logger.info("queryHotelBusinessByHotelid:hotelid:{}", hotelid);
		HotelBusinessExample example = new HotelBusinessExample();
		Criteria criteria = example.createCriteria();
		criteria.andHotelidEqualTo(hotelid);
		List<HotelBusiness> hotelBusinesses = hotelBusinessMapper.selectByExample(example);
		if (CollectionUtils.isNotEmpty(hotelBusinesses)) {
			for (HotelBusiness hotelBusiness : hotelBusinesses) {
				return hotelBusiness;
			}
		}
		return null;
	}
	
	/**
	 * 
	 * @param business
	 * @param hotelBusiness
	 * @return
	 */
	private Integer getStatusByBusiness(HotelBusinessEnum business, HotelBusiness hotelBusiness) {
		Integer status = -1;
		switch (business) {
		case SWITCHS:
			status = hotelBusiness.getDistribution();
			break;
		case WASHING:
			status = hotelBusiness.getWashing();
			break;
		case PURCHASING:
			status = hotelBusiness.getPurchasing();
			break;

		default:
			break;
		}
		return status;
	}
	private void setStatusByBusiness( HotelBusiness hotelBusiness, HotelBusinessEnum business, Integer flag, String optUser, String openDate) {
		Date date = StringUtils.isNotBlank(openDate) ? DateUtils.getDateFromString(openDate) : new Date();
		switch (business) {
		case SWITCHS:
			if (flag > HotelBusinessStatusEnum.BUSINESS_NOT.getId()) {
				// 调openapi：酒店折扣数据的初始化
				initHotelDiscount(hotelBusiness.getHotelpms());
			}
			
			BisLog bisLog = new BisLog();
			bisLog.setSystem("basic");
			bisLog.setBussinessId(hotelBusiness.getHotelid().toString());
			bisLog.setBussinssType(flag.toString());
			bisLog.setOperator(optUser);
			bisLog.setContent(String.format("酒店id：%d进行【%s】的【%s】操作", hotelBusiness.getHotelid(), business.getName(), flag == 10 ? "关闭" : "开通") );
			bisLog.setCreateTime(new Date());
			bisLogDelegate.saveBisLog(bisLog);
			
			hotelBusiness.setDistribution(flag);
			if (hotelBusiness.getDistributionCreatetime() == null) {
				hotelBusiness.setDistributionCreatetime(date);
			}
			break;
		case WASHING:
			hotelBusiness.setWashing(flag);
			if (hotelBusiness.getWashingCreatetime() == null) {
				hotelBusiness.setWashingCreatetime(date);
			}
			break;
		case PURCHASING:
			hotelBusiness.setPurchasing(flag);
			if (hotelBusiness.getPurchasingCreatetime() == null) {
				hotelBusiness.setPurchasingCreatetime(date);
			}
			break;
			
		default:
			break;
		}
	}
	
	/**
	 * 
	 * @param business
	 * @param opt
	 * @return
	 */
	private Integer getOpenFlag(HotelModel hotelModel, HotelBusinessEnum business, String opt) {
		logger.info("getOpenFlag:hotelmodel:{},business:{},opt:{}", JSONObject.toJSON(hotelModel), business, opt);
		Integer flag = -1;
		if (businessStatusMap.containsKey(business.getId() + opt)) {
			flag = businessStatusMap.get(business.getId() + opt);
		}
		if (flag != HotelBusinessStatusEnum.BUSINESS_NOT.getId()) {
			if (hotelModel.getState() != null && (hotelModel.getState().intValue() == 4 || hotelModel.getState().intValue() == 5)) {
				// 如果酒店审核，则设置为OK
				flag = HotelBusinessStatusEnum.BUSINESS_OK.getId();
			} else {
				// 如果酒店未审核，则设置为DOING
				flag = HotelBusinessStatusEnum.BUSINESS_DOING.getId();
			}
		}
		logger.info("getOpenFlag:flag:{}", flag);
		return flag;
	}

	@Override
	public boolean updateWashMode(Long hotelid, String washingmode) {
		HotelBusinessExample example = new HotelBusinessExample();
		Criteria criteria = example.createCriteria();
		criteria.andHotelidEqualTo(hotelid);
		List<HotelBusiness> hotelBusinesses = hotelBusinessMapper.selectByExample(example);
		if (CollectionUtils.isNotEmpty(hotelBusinesses)) {// 存在 update
			for (HotelBusiness hotelBusiness : hotelBusinesses) {
				hotelBusiness.setWashingmode(washingmode);
				hotelBusinessMapper.updateByPrimaryKey(hotelBusiness);
			}
		}
		return false;
	}
	@Override
	public void hotelConfirmSyncBusinessState(String hotelPms){
		HotelModel hotelModel = hotelService.queryByPms(hotelPms);
		HotelBusinessExample example = new HotelBusinessExample();
		Criteria criteria = example.createCriteria();
		criteria.andHotelpmsEqualTo(hotelPms);
		List<HotelBusiness> hotelBusinesses = hotelBusinessMapper.selectByExample(example);
		if (CollectionUtils.isNotEmpty(hotelBusinesses)) {// 存在 update
			for (HotelBusiness hotelBusiness : hotelBusinesses) {
				if (hotelBusiness.getDistribution() != null 
						&& hotelBusiness.getDistribution().intValue() > HotelBusinessStatusEnum.BUSINESS_NOT.getId()) {
					hotelBusiness.setDistribution(HotelBusinessStatusEnum.BUSINESS_OK.getId());
					if (hotelBusiness.getDistributionCreatetime() == null) {
						hotelBusiness.setDistributionCreatetime(new Date());
					}
					// 酒店开通分销
					hotelBusinessChangeSendMessage(HotelBusinessEnum.SWITCHS, hotelModel, HotelBusinessStatusEnum.BUSINESS_OK.getId());
				}
				if (hotelBusiness.getWashing() != null 
						&& hotelBusiness.getWashing().intValue() > HotelBusinessStatusEnum.BUSINESS_NOT.getId()) {
					hotelBusiness.setWashing(HotelBusinessStatusEnum.BUSINESS_OK.getId());
					if (hotelBusiness.getWashingCreatetime() == null) {
						hotelBusiness.setWashingCreatetime(new Date());
					}
					// 酒店开通洗涤
					hotelBusinessChangeSendMessage(HotelBusinessEnum.WASHING, hotelModel, HotelBusinessStatusEnum.BUSINESS_OK.getId());
				}
				if (hotelBusiness.getPurchasing() != null 
						&& hotelBusiness.getPurchasing().intValue() > HotelBusinessStatusEnum.BUSINESS_NOT.getId()) {
					hotelBusiness.setPurchasing(HotelBusinessStatusEnum.BUSINESS_OK.getId());
					if (hotelBusiness.getPurchasingCreatetime() == null) {
						hotelBusiness.setPurchasingCreatetime(new Date());
					}
					// 酒店开通采购
					hotelBusinessChangeSendMessage(HotelBusinessEnum.PURCHASING, hotelModel, HotelBusinessStatusEnum.BUSINESS_OK.getId());
				}
				hotelBusinessMapper.updateByPrimaryKey(hotelBusiness);
			}
		}
	}
	
	/**
	 * 
	 * @param business
	 * @param hotelModel
	 * @param flag
	 */
	private void hotelBusinessChangeSendMessage(HotelBusinessEnum business, HotelModel hotelModel, Integer flag) {
		JSONObject msg = new JSONObject();
		msg.put("hotelid", hotelModel.getHotelpms());
		msg.put("flag", flag.intValue() >= HotelBusinessStatusEnum.BUSINESS_DOING.getId() ? "T" : "F");
		msg.put("business", business.getId().toLowerCase());
		kafkaProducer.sendHotelBusinessChange(msg.toJSONString());
		
		if (business.getId().equals(HotelBusinessEnum.SWITCHS.getId()) && HotelBusinessStatusEnum.BUSINESS_OK.getId().equals(flag)) {
			JSONObject message = new JSONObject();
			message.put("hotelid", hotelModel.getId());
			kafkaProducer.sendHotelDistrictOpen(message.toJSONString());
		}
		if (business.getId().equals(HotelBusinessEnum.SWITCHS.getId()) && HotelBusinessStatusEnum.BUSINESS_NOT.getId().equals(flag)) {
			JSONObject message = new JSONObject();
			message.put("hotelid", hotelModel.getId());
			kafkaProducer.sendHotelDistrictClose(message.toJSONString());
		}
	}
	
	/**
	 * 酒店折扣数据的初始化
	 * @param hotelid
	 * @return
	 */
	private boolean initHotelDiscount(String hotelpms) {
		try {
			logger.info("initHotelDiscount,hotelpms:{}", hotelpms);
			NameValuePair[] nameValuePairs = {};
			NameValuePair[] headers = { new NameValuePair("HOTELID", hotelpms), 
					new NameValuePair("TOKEN", MD5Util.encryption(UrlUtil.getValue("oms.token"))) };
			String data = NetUtil.methodPost(UrlUtil.getValue("openapi_url") + "/distribution/inithoteldiscount", headers, nameValuePairs);
			JSONObject jsonObj = (JSONObject) JSONObject.parseObject(data);
			if ("OK".equals(jsonObj.getString("_MSG_"))) {
				logger.info("initHotelDiscount,data:{}", data);
				return true;
			} else if("ERROR".equals(jsonObj.getString("_MSG_")))
				logger.info("initHotelDiscount,errorcode{},errormessage{}", jsonObj.getString("_ERROR_"), jsonObj.getString("_ERRORMESSAGE_"));
			throw new MyException(jsonObj.getString("_ERROR_"), jsonObj.getString("_ERRORMESSAGE_"));
		} catch (Exception e) {
			logger.error("无法连接OPENAPI ###########################");
			throw e;
		}
	}

	@Override
	public RetInfo<List<Long>> queryHotelBusinessState(HotelBusinessEnum business, List<Long> hotelids, Date begintime, Date endtime) {
		logger.info("queryHotelBusinessState,business{},hotelids{},begintime{},endtime{}", business, hotelids, begintime, endtime);
		if (CollectionUtils.isEmpty(hotelids)) {
			throw new RuntimeException("酒店id数组不可以为空");
		}
		HotelBusinessExample example = new HotelBusinessExample();
		Criteria criteria = example.createCriteria();
		criteria.andHotelidIn(hotelids);
		// 如果是分销
		if (business.equals(HotelBusinessEnum.SWITCHS)) {
			criteria.andDistributionCreatetimeGreaterThanOrEqualTo(begintime);
			criteria.andDistributionCreatetimeLessThanOrEqualTo(endtime);
		}
		// 如果是洗涤
		if (business.equals(HotelBusinessEnum.WASHING)) {
			criteria.andWashingCreatetimeGreaterThanOrEqualTo(begintime);
			criteria.andWashingCreatetimeLessThanOrEqualTo(endtime);
		}
		// 如果是采购
		if (business.equals(HotelBusinessEnum.PURCHASING)) {
			criteria.andPurchasingCreatetimeGreaterThanOrEqualTo(begintime);
			criteria.andPurchasingCreatetimeLessThanOrEqualTo(endtime);
		}
		List<HotelBusiness> list = hotelBusinessMapper.selectByExample(example);
		List<Long> ids = new ArrayList<Long>();
		for (HotelBusiness hotelBusiness : list) {
			ids.add(hotelBusiness.getHotelid());
		}
		RetInfo<List<Long>> retinfo = new RetInfo<List<Long>>();
		retinfo.setObj(ids);
		logger.info("queryHotelBusinessState.ok");
		return retinfo;
	}
}
