package com.fangbaba.basic.service;

import java.util.List;
import java.util.Map;

import com.fangbaba.basic.face.bean.RoomModel;
import com.fangbaba.basic.face.bean.jsonbean.PmsRoomJsonBean;

public interface RoomService extends com.fangbaba.basic.face.service.RoomService {
	/**
	 * 同步房间信息
	 * @param map 
	 * 
	 * @param json
	 */
	void syncRoomInfo(Long roomtypeid, List<PmsRoomJsonBean> rooms, Map<String, Long> map);

	/**
	 * 根据房型删除房间
	 */
	void delRoomByRoomtypeid(Long roomtypeid);

	/**
	 * crm修改房间
	 * 
	 * @param roomModel
	 */
	void updateRoomByRoomPms(RoomModel roomModel);

}
