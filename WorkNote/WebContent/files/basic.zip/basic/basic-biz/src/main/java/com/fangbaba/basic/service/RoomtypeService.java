package com.fangbaba.basic.service;

import java.util.List;
import java.util.Map;

import com.fangbaba.basic.face.bean.RoomtypeModel;
import com.fangbaba.basic.face.bean.jsonbean.PmsRoomtypeJsonBean;

public interface RoomtypeService extends com.fangbaba.basic.face.service.RoomtypeService {
	/**
	 * 同步房型信息
	 * @param map 
	 * 
	 * @param json
	 */
	void syncRoomtypeInfo(Long hotelid, List<PmsRoomtypeJsonBean> roomtypes, Map<String, Long> map);

	/**
	 * 根据房型PMS更新房型
	 * 
	 * @param roomtypeModel
	 */
	void updateRoomTypeByRoomTypePms(RoomtypeModel roomtypeModel);

	/**
	 * 根据pms得到唯一的房型
	 * 
	 * @param pmsNo
	 * @return
	 */
	RoomtypeModel queryByPmsOnly(Long hotelId, String pmsNo);
	
	/**
	 * 同步房型信息
	 * @param hotelid
	 * @param roomtypes
	 * @param map
	 */
	public void syncRoomtypeInfos(Long hotelid, List<PmsRoomtypeJsonBean> roomtypes, Map<String, Long> map);
	
	public void syncPushCrmSyncAddRoomType(String json);
	
	public void syncPushCrmSyncDelRoomType(String json);
}
