package com.fangbaba.basic.mappers;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.fangbaba.basic.face.bean.DailyRateModel;
import com.fangbaba.basic.po.DailyRateModelExample;

public interface DailyRateModelMapper {
    int countByExample(DailyRateModelExample example);

    int deleteByExample(DailyRateModelExample example);

    int deleteByPrimaryKey(Long id);

    int insert(DailyRateModel record);

    int insertSelective(DailyRateModel record);

    List<DailyRateModel> selectByExample(DailyRateModelExample example);

    DailyRateModel selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") DailyRateModel record, @Param("example") DailyRateModelExample example);

    int updateByExample(@Param("record") DailyRateModel record, @Param("example") DailyRateModelExample example);

    int updateByPrimaryKeySelective(DailyRateModel record);

    int updateByPrimaryKey(DailyRateModel record);
    
    List<DailyRateModel> findDailyRates(@Param("hotelid") Long hotelid, @Param("roomtypeids") List<Long> roomtypeids, @Param("begintime") int begintime, @Param("endtime") int endtime);
}