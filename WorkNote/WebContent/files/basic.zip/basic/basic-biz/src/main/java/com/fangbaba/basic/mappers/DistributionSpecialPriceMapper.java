package com.fangbaba.basic.mappers;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.fangbaba.basic.face.bean.DistributionSpecialPrice;
import com.fangbaba.basic.face.bean.DistributionSpecialPriceExample;

public interface DistributionSpecialPriceMapper {
	int countByExample(DistributionSpecialPriceExample example);

	int deleteByExample(DistributionSpecialPriceExample example);

	int deleteByPrimaryKey(Long id);

	int insert(DistributionSpecialPrice record);

	int insertSelective(DistributionSpecialPrice record);

	List<DistributionSpecialPrice> selectByExample(DistributionSpecialPriceExample example);

	DistributionSpecialPrice selectByPrimaryKey(Long id);

	int updateByExampleSelective(@Param("record") DistributionSpecialPrice record, @Param("example") DistributionSpecialPriceExample example);

	int updateByExample(@Param("record") DistributionSpecialPrice record, @Param("example") DistributionSpecialPriceExample example);

	int updateByPrimaryKeySelective(DistributionSpecialPrice record);

	int updateByPrimaryKey(DistributionSpecialPrice record);

	/**
	 * 批量插入分销特殊价
	 * 
	 * @param list
	 * @return
	 */
	int batchInsert(List<DistributionSpecialPrice> list);

	int deleteByBatchDay(Long hotelId, Long rommTypeId, List<Date> list);

	/**
	 * 查询特殊价格
	 * 
	 * @param hotelid
	 * @param RoomTypeId
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	List<DistributionSpecialPrice> selectDistributionSpecialPrice(Long hotelid, Long RoomTypeId, String startTime, String endTime);
}