package com.fangbaba.basic.mappers;

import com.fangbaba.basic.face.bean.Tags;
import com.fangbaba.basic.face.bean.TagsExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface TagsMapper {
    int countByExample(TagsExample example);

    int deleteByExample(TagsExample example);

    int deleteByPrimaryKey(Long id);

    int insert(Tags record);

    int insertSelective(Tags record);

    List<Tags> selectByExample(TagsExample example);

    Tags selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") Tags record, @Param("example") TagsExample example);

    int updateByExample(@Param("record") Tags record, @Param("example") TagsExample example);

    int updateByPrimaryKeySelective(Tags record);

    int updateByPrimaryKey(Tags record);
    
    List<Tags> queryTagsByHotelid(@Param("hotelid") Long hotelid);

    List<Tags> queryTagsByHotelids(@Param("hotelids") List<Long> hotelids, @Param("pageno") int pageno, @Param("pagesize") int pagesize);
    
    List<Tags> queryTagsByIds(@Param("ids") List<Long> ids);
    
    int batchAddTagRecord(List<Tags> tagList);
    
    int batchDelTagRecord(List<Tags> tagList);
    
    List<Tags> queryTagsByGroupId(@Param("taggroupid") Long taggroupid);
    
    List<Tags> queryAllTags();
}