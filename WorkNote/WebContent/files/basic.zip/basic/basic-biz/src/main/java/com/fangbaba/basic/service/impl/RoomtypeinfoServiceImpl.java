package com.fangbaba.basic.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.bean.RoomtypeinfoModel;
import com.fangbaba.basic.face.service.RoomtypeinfoService;
import com.fangbaba.basic.mappers.RoomtypeinfoModelMapper;

@Service
public class RoomtypeinfoServiceImpl implements RoomtypeinfoService {

	private static Logger logger = LoggerFactory.getLogger(RoomtypeinfoServiceImpl.class);
	@Autowired
	RoomtypeinfoModelMapper roomtypeinfoModelMapper;
	
	@Override
	public RoomtypeinfoModel findRoomtypeinfoByRoomtypeId(Long roomtypeid) {
		logger.info("findRoomtypeinfoByRoomtypeId:roomtypeid:{}", roomtypeid);
		RoomtypeinfoModel roomtypeinfo = roomtypeinfoModelMapper.findRoomtypeinfoByRoomtypeId(roomtypeid);
		return roomtypeinfo;
	}

	@Override
	public List<RoomtypeinfoModel> findRoomtypeinfoByRoomtypeIds(List<Long> roomtypeids) {
		logger.info("findRoomtypeinfoByRoomtypeIds:roomtypeids:{}", roomtypeids);
		List<RoomtypeinfoModel> roomtypeinfos = roomtypeinfoModelMapper.findRoomtypeinfoByRoomtypeIds(roomtypeids);
		return roomtypeinfos;
	}
	
	@Override
	public void crmRoomTypeInfoUpdate(String json){
		logger.info("crmRoomTypeInfoUpdate:json:{}", json);
		JSONArray js = JSONObject.parseArray(json);
		if (js != null && js.size() > 0) {
			for (int i = 0; i < js.size(); i++) {
				JSONObject j = (JSONObject) js.get(i);
				Long roomTypeId = j.getLong("roomTypeId");
				RoomtypeinfoModel roomtypeinfo = roomtypeinfoModelMapper.findRoomtypeinfoByRoomtypeId(roomTypeId);
				if (roomtypeinfo != null) {
					setBeanProperties(j, roomtypeinfo);
					roomtypeinfoModelMapper.updateByPrimaryKey(roomtypeinfo);
					logger.info("crmRoomTypeInfoUpdate:update:{}", JSONObject.toJSON(roomtypeinfo));
				} else {
					roomtypeinfo = new RoomtypeinfoModel();
					setBeanProperties(j, roomtypeinfo);
					roomtypeinfoModelMapper.insertSelective(roomtypeinfo);
					logger.info("crmRoomTypeInfoUpdate:insert:{}", JSONObject.toJSON(roomtypeinfo));
				}
			}
		}
		logger.info("crmRoomTypeInfoUpdate:ok");
	}
	
	@Override
	public void syncRoomTypeInfos(List<RoomtypeinfoModel> roomtypeinfos) {
		logger.info("syncRoomTypeInfos:roomtypeinfos:{}", JSONObject.toJSON(roomtypeinfos));
		for (RoomtypeinfoModel roomtypeinfoModel : roomtypeinfos) {
			RoomtypeinfoModel roomtypeinfo = roomtypeinfoModelMapper.findRoomtypeinfoByRoomtypeId(roomtypeinfoModel.getRoomtypeid());
			if (roomtypeinfo == null) {
				logger.info("syncRoomTypeInfos.insertSelective:roomtypeinfo:{}", JSONObject.toJSON(roomtypeinfoModel));
				roomtypeinfoModelMapper.insertSelective(roomtypeinfoModel);
			} else {
				logger.info("syncRoomTypeInfos.updateByPrimaryKey:roomtypeinfo:{}", JSONObject.toJSON(roomtypeinfo));
				roomtypeinfoModelMapper.updateByPrimaryKey(roomtypeinfo);
			}
		}
		logger.info("syncRoomTypeInfos.ok");
	}

	private void setBeanProperties(JSONObject j, RoomtypeinfoModel roomtypeinfo) {
		roomtypeinfo.setRoomtypeid(j.getLong("roomTypeId"));
		roomtypeinfo.setMaxarea(j.getBigDecimal("maxArea"));
		roomtypeinfo.setBedtype(j.getLong("bedType"));
		roomtypeinfo.setBedsize(j.getString("bedSize"));
		roomtypeinfo.setPics(j.getString("pics"));
	}
}
