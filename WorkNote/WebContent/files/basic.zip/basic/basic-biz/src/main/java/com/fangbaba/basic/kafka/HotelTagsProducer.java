package com.fangbaba.basic.kafka;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mk.kafka.client.stereotype.MkMessageService;
import com.mk.kafka.client.stereotype.MkTopicProducer;

@MkMessageService
public class HotelTagsProducer {

	private Logger logger = LoggerFactory.getLogger(HotelTagsProducer.class);

	@MkTopicProducer(topic = "Basic_SyncHoteltags", partitions = 1, serializerClass = "com.mk.kafka.client.serializer.SerializerEncoder", replicationFactor = 1)
	public void sendHoteltags(Map message) {
		logger.info("StandardKafkaProducer send a message:" + message);
	}
}
