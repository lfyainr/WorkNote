package com.fangbaba.basic.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.bean.BasicHotelTags;
import com.fangbaba.basic.face.bean.HotelModel;
import com.fangbaba.basic.face.bean.Hoteltags;
import com.fangbaba.basic.face.bean.Tags;
import com.fangbaba.basic.face.service.HotelService;
import com.fangbaba.basic.face.service.HotelTagsService;
import com.fangbaba.basic.kafka.HotelTagsProducer;
import com.fangbaba.basic.mappers.HoteltagsMapper;
import com.fangbaba.basic.mappers.TagsMapper;
import com.fangbaba.order.common.enums.BasicErrorEnum;

/**
 * 酒店标签Service
 * 
 * @author 李善维
 */
@Service
public class HotelTagsServiceImpl implements HotelTagsService {
	
	private Logger logger = LoggerFactory.getLogger(HotelTagsServiceImpl.class);
	
	@Autowired
	TagsMapper tagsMapper;
	@Autowired
	HoteltagsMapper hoteltagsMapper;
	@Autowired
	HotelTagsProducer hotelTagsProducer;
	@Autowired
	private HotelService hotelService;

	@Override
	public void updateHotelTags(String hotelpmsid, List<Long> ids) {
		logger.info("udateHotelTags:参数:{},ids:{}", hotelpmsid, ids);
		HotelModel hotel = hotelService.queryByPms(hotelpmsid);
		if (hotel == null || ids == null || ids.size() == 0) {
			logger.info("udateHotelTags:判断酒店hotel:{}", hotel);
			return;
		}
		
		List<Tags> tagList = tagsMapper.queryTagsByIds(ids);
		tagList = tagsMapper.queryTagsByIds(ids);
		// 1.先删掉酒店的标签
		hoteltagsMapper.deleteHotelTags(hotel.getId());
		List<Tags> tags = new ArrayList<>();
		
		// 2.然后插入酒店和标签的关系数据
		for (Tags tag : tagList) {
			Hoteltags ht = new Hoteltags();
			ht.setHotelid(hotel.getId());
			ht.setTagid(tag.getId());
			hoteltagsMapper.insertSelective(ht);
			tags.add(tag);
		}
		
		// 发送MQ
		Map<String, List<Tags>> message = new HashMap<>();
		message.put(String.valueOf(hotel.getId()), tags);
		hotelTagsProducer.sendHoteltags(message);
		logger.info("udateHotelTags:end:send message:{}", message);
	}

	@Override
	public List<Tags> queryTagsByHotelid(Long hotelid) {
		logger.info("queryTagsByHotelid:参数:{}", hotelid);
		List<Tags> tags = tagsMapper.queryTagsByHotelid(hotelid);
		logger.info("queryTagsByHotelid:{}", tags.size());
		return tags;
	}

	@Override
	public void addTags(List<Tags> tagList) {
		logger.info("HotelTagsServiceImpl::addTags:参数:{}", tagList);
		int cnt = tagsMapper.batchAddTagRecord(tagList);
		if (cnt <= 0) {
			logger.info("HotelTagsServiceImpl::addTags::插入标签数据库出错!");
			throw BasicErrorEnum.BATCH_ADD_TAGS.getException();
		}
		logger.info("HotelTagsServiceImpl::addTags:参数:{}", tagList);
	}

	@Override
	public void delTags(List<Tags> tagList) {
		logger.info("HotelTagsServiceImpl::delTags:参数:{}", tagList);
		int cnt = tagsMapper.batchDelTagRecord(tagList);
		if (cnt <= 0) {
			logger.info("HotelTagsServiceImpl::delTags::删除标签数据库出错!");
			throw BasicErrorEnum.BATCH_DEL_TAGS.getException();
		}
		logger.info("HotelTagsServiceImpl::delTags:参数:{}", tagList);
	}

	@Override
	public Map<String, List<Tags>> queryTagsByHotelid(int pageno, int pagesize) {
		logger.info("queryTagsByHotelid:参数:{}，{}", pageno, pagesize);
		HotelModel hotelModel = new HotelModel();
		List<HotelModel> hotels = hotelService.queryByCondition(hotelModel, null, pageno, pagesize);
		if (hotels == null || hotels.size() == 0)
			return null;
		
		Map<String, List<Tags>> allTags = new HashMap<>();
		for (HotelModel hotel : hotels) {
			List<Long> hotelids = new ArrayList<>();
			hotelids.add(hotel.getId());
			allTags.put(String.valueOf(hotel.getId()), tagsMapper.queryTagsByHotelids(hotelids, 0, 1000));
		}
		logger.info("queryTagsByHotelid:{},{}", allTags.keySet().size(), JSONObject.toJSON(allTags));
		return allTags;
	}

	@Override
	public BasicHotelTags queryHotelTagsByHotelid(String hotelpmsid) {
		logger.info("queryHotelTagsByHotelid:{}", hotelpmsid);
		HotelModel hotel = hotelService.queryByPms(hotelpmsid);
		List<Tags> alltags = tagsMapper.queryAllTags();
		List<Tags> hoteltags = tagsMapper.queryTagsByHotelid(hotel.getId());
		BasicHotelTags tags = new BasicHotelTags();
		tags.setAllTags(alltags);
		tags.setHotelTags(hoteltags);
		return tags;
	}
	
	@Override
	public List<Tags> queryAllTags() {
		List<Tags> alltags = tagsMapper.queryAllTags();
		return alltags;
	}
}
