package com.fangbaba.basic.kafka;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.bean.HotelExtension;
import com.fangbaba.basic.face.bean.HotelModel;
import com.fangbaba.basic.face.bean.RoomModel;
import com.fangbaba.basic.face.bean.RoomtypeModel;
import com.fangbaba.basic.face.bean.jsonbean.DailyRateJsonBean;
import com.fangbaba.basic.face.bean.jsonbean.RackRateJsonBean;
import com.fangbaba.basic.face.bean.jsonbean.WeekendRateJsonBean;
import com.fangbaba.basic.face.enums.MyErrorEnum;
import com.fangbaba.basic.face.service.HotelBusinessService;
import com.fangbaba.basic.face.service.RoomtypeinfoService;
import com.fangbaba.basic.service.HotelExtensionService;
import com.fangbaba.basic.service.HotelService;
import com.fangbaba.basic.service.RoomService;
import com.fangbaba.basic.service.RoomtypeService;
import com.fangbaba.basic.service.SellPriceService;
import com.fangbaba.order.common.utils.DateUtils;
import com.google.gson.Gson;
import com.mk.kafka.client.stereotype.MkMessageService;
import com.mk.kafka.client.stereotype.MkTopicConsumer;

@MkMessageService
public class StandardKafkaConsumer {
	@Autowired
	private HotelService hotelService;
	@Autowired
	private SellPriceService sellPriceService;
	@Autowired
	private HotelExtensionService hotelExtensionService;
	@Autowired
	private RoomService roomService;
	@Autowired
	private RoomtypeService roomtypeService;
	@Autowired
	private RoomtypeinfoService roomtypeinfoService;
	@Autowired
	private StandardKafkaProducer standardKafkaProducer;
	@Autowired
	private HotelBusinessService hotelBusinessService;

	private Gson gson = new Gson();

	private Logger logger = LoggerFactory.getLogger(StandardKafkaConsumer.class);

	/**
	 * 同步酒店信息
	 */
	@MkTopicConsumer(topic = "PushCrmHotelMsg", group = "Basic_Switch_PmsSyncHotel", invokeThreadCount=1, serializerClass = "com.mk.kafka.client.serializer.StringDecoder")
	public void consumeHotel(String json) {
		logger.info("Switch_PmsSyncHotel consume begin:" + json);
		hotelService.syncHotelInfo(json);
		logger.info("Switch_PmsSyncHotel consume end:" + json);
	}
	
	/**
	 * 同步门市价
	 */
	@MkTopicConsumer(topic = "Switch_PmsSyncRackRate", group = "Basic_Switch_PmsSyncRackRate", serializerClass = "com.mk.kafka.client.serializer.StringDecoder")
	public void consumeRackRate(String json) {
		logger.info("Switch_PmsSyncRackRate consume begin:" + json);
		try {
			if (StringUtils.isEmpty(json)) {
				throw MyErrorEnum.errorParm.getMyException("参数错误!没有传json数据");
			}
			// 解析json
			RackRateJsonBean rackRateJsonBean = gson.fromJson(json, RackRateJsonBean.class);
			if (rackRateJsonBean == null) {
				throw MyErrorEnum.errorParm.getMyException("json数据错误:json--" + json);
			}
			if (StringUtils.isEmpty(rackRateJsonBean.getHotelid())) {
				throw MyErrorEnum.errorParm.getMyException("参数错误!hotelid为空");
			}
//			if (rackRateJsonBean.getRoomtype().size() == 0) {
//				throw MyErrorEnum.errorParm.getMyException("参数错误!roomtype数据为空");
//			}
			// hotel 根据pms查询
			HotelModel hotelModel = hotelService.queryByPms(rackRateJsonBean.getHotelid());
			if (hotelModel == null) {
				throw MyErrorEnum.errorParm.getMyException("未找到pms为 " + rackRateJsonBean.getHotelid() + " 的酒店信息");
			}
			Long hotelid = hotelModel.getId();

			boolean ischange = sellPriceService.syncRackRate(rackRateJsonBean, hotelid);
			if (ischange) {
				// 更新es
				standardKafkaProducer.sendInitEsMessage(hotelid.toString());
				
				standardKafkaProducer.sendRackRateChange(hotelid.toString());
			}
		} catch (Exception e) {
			logger.error("Switch_PmsSyncRackRate consume error " + json, e);
		}
		logger.info("Switch_PmsSyncRackRate consume end:" + json);
	}

	/**
	 * 同步特殊价
	 */
	@MkTopicConsumer(topic = "Switch_PmsSyncDailyRate", group = "Basic_Switch_PmsSyncDailyRate", serializerClass = "com.mk.kafka.client.serializer.StringDecoder")
	public void consumeDailyRate(String json) {
		logger.info("Switch_PmsSyncDailyRate consume begin:" + json);
		try {
			if (StringUtils.isEmpty(json)) {
				throw MyErrorEnum.errorParm.getMyException("参数错误!没有传json数据");
			}
			// 解析json
			DailyRateJsonBean dailyRateJsonBean = gson.fromJson(json, DailyRateJsonBean.class);
			if (dailyRateJsonBean == null) {
				throw MyErrorEnum.errorParm.getMyException("json数据错误:json--" + json);
			}
			if (StringUtils.isEmpty(dailyRateJsonBean.getHotelid())) {
				throw MyErrorEnum.errorParm.getMyException("参数错误!hotelid为空");
			}
//			if (dailyRateJsonBean.getRoomtype().size() == 0) {
//				throw MyErrorEnum.errorParm.getMyException("参数错误!roomtype数据为空");
//			}

			// hotel 根据pms查询
			HotelModel hotelModel = hotelService.queryByPms(dailyRateJsonBean.getHotelid());
			if (hotelModel == null) {
				throw MyErrorEnum.errorParm.getMyException("未找到pms为 " + dailyRateJsonBean.getHotelid() + " 的酒店信息");
			}
			Long hotelid = hotelModel.getId();

			boolean ischange = sellPriceService.syncDailyRate(dailyRateJsonBean, hotelid);

			if (ischange) {
				// 更新es
				standardKafkaProducer.sendInitEsMessage(hotelid.toString());
			}
		} catch (Exception e) {
			logger.error("Switch_PmsSyncDailyRate consume error " + json, e);
		}
		logger.info("Switch_PmsSyncDailyRate consume end:" + json);
	}

	/**
	 * 同步周末价
	 */
	@MkTopicConsumer(topic = "Switch_PmsSyncWeekendRate", group = "Basic_Switch_PmsSyncWeekendRate", serializerClass = "com.mk.kafka.client.serializer.StringDecoder")
	public void consumeWeekendRate(String json) {
		logger.info("Switch_PmsSyncWeekendRate consume begin:" + json);
		try {
			if (StringUtils.isEmpty(json)) {
				throw MyErrorEnum.errorParm.getMyException("参数错误!没有传json数据");
			}
			// 解析json
			WeekendRateJsonBean weekendRateJsonBean = gson.fromJson(json, WeekendRateJsonBean.class);
			if (weekendRateJsonBean == null) {
				throw MyErrorEnum.errorParm.getMyException("json数据错误:json--" + json);
			}
			if (StringUtils.isEmpty(weekendRateJsonBean.getHotelid())) {
				throw MyErrorEnum.errorParm.getMyException("参数错误!hotelid为空");
			}
//			if (weekendRateJsonBean.getRoomtype().size() == 0) {
//				throw MyErrorEnum.errorParm.getMyException("参数错误!roomtype数据为空");
//			}
			// hotel 根据pms查询
			HotelModel hotelModel = hotelService.queryByPms(weekendRateJsonBean.getHotelid());
			if (hotelModel == null) {
				throw MyErrorEnum.errorParm.getMyException("未找到pms为 " + weekendRateJsonBean.getHotelid() + " 的酒店信息");
			}
			Long hotelid = hotelModel.getId();

			boolean ischange = sellPriceService.syncWeekendRate(weekendRateJsonBean, hotelid);
			if (ischange) {
				// 更新es
				standardKafkaProducer.sendInitEsMessage(hotelid.toString());
			}
		} catch (Exception e) {
			logger.error("Switch_PmsSyncWeekendRate consume error " + json, e);
		}

		logger.info("Switch_PmsSyncWeekendRate consume end:" + json);
	}

	/**
	 * 订阅酒店修改
	 * 
	 * @param hotelModel
	 */
	@MkTopicConsumer(topic = "crm_hotelUpdate", group = "Basic_Switch_PmsSyncWeekendRate", serializerClass = "com.mk.kafka.client.serializer.SerializerDecoder")
	public void consumeUpdateHotel(HotelModel hotelModel) {
		hotelService.updateHotelByHotelPms(hotelModel);
		hotelModel = hotelService.queryByPms(hotelModel.getHotelpms());
		// 酒店审核通过，处理带开通的业务的状态
		if (hotelModel.getState() != null && hotelModel.getState().intValue() == 4) {
			hotelBusinessService.hotelConfirmSyncBusinessState(hotelModel.getHotelpms());
		}
		// 通知外部系统此订单被修改了。
		standardKafkaProducer.sendSyncHotelChange(hotelModel.getId().toString());
		// 如果设置了channelid，则发送消息
		if (hotelModel.getChannelid() != null) {
			standardKafkaProducer.sendHotelChannelIdUpdate("{'hotelid': " + hotelModel.getId() + ", 'channelid': " + hotelModel.getChannelid() + "}");
		}
	}

	/**
	 * 酒店上下线
	 * 
	 * @param message
	 */
	@MkTopicConsumer(topic = "Switch_PmsSyncChangeOnlineStatus", group = "Basic_Switch_PmsSyncWeekendRate", serializerClass = "com.mk.kafka.client.serializer.StringDecoder")
	public void consumSwitch_PmsSyncChangeOnlineStatus(String message) {
		hotelService.updateHotelOnlineState(message);
	}

	/**
	 * 订阅房间修改
	 * 
	 * @param roomModel
	 */
	@MkTopicConsumer(topic = "crm_roomUpdate", group = "Basic_Switch_PmsSyncWeekendRate", serializerClass = "com.mk.kafka.client.serializer.SerializerDecoder")
	public void consumeUpdateRoom(RoomModel roomModel) {
		roomService.updateRoomByRoomPms(roomModel);
	}

	/**
	 * 订阅房型修改
	 * 
	 * @param roomtypeModel
	 */
	@MkTopicConsumer(topic = "crm_roomTypeUpdate", group = "Basic_Switch_PmsSyncWeekendRate", serializerClass = "com.mk.kafka.client.serializer.SerializerDecoder")
	public void consumeUpdateRoomType(RoomtypeModel roomtypeModel) {
		roomtypeService.updateRoomTypeByRoomTypePms(roomtypeModel);
	}

	/**
	 * 订阅酒店图片修改
	 * 
	 * @param hotelExtension
	 */
	@MkTopicConsumer(topic = "crm_roomTypeUpdate", group = "Basic_Switch_PmsSyncWeekendRate", serializerClass = "com.mk.kafka.client.serializer.SerializerDecoder")
	public void consumeUpdateHotelPic(HotelExtension hotelExtension) {
		hotelExtensionService.updatePicByHotelPms(hotelExtension.getHotelPms(), hotelExtension.getHotelpic());
	}
	
	// 收到同步房型信息
	@MkTopicConsumer(topic = "PushCrmSyncHotelOfSwitchMsg", group = "Basic_Switch_PmsSyncHotel", invokeThreadCount=1, serializerClass = "com.mk.kafka.client.serializer.StringDecoder")
	public void consumePushCrmSyncHotelOfSwitchMsg(String json) {
		logger.info("consumePushCrmSyncHotelOfSwitchMsg consume begin:" + json);
		hotelService.syncPushCrmSyncHotelOfSwitchMsg(json);
		logger.info("consumePushCrmSyncHotelOfSwitchMsg consume end:" + json);
	}
	
	// 收到crm增加房型消息
	@MkTopicConsumer(topic = "PushCrmSyncAddRoomTypeOfSwitchMsg", group = "Basic_Switch_PmsSyncHotel", invokeThreadCount=1, serializerClass = "com.mk.kafka.client.serializer.StringDecoder")
	public void consumePushCrmSyncAddRoomType(String json) {
		logger.info("consumePushCrmSyncAddRoomType consume begin:" + json);
		roomtypeService.syncPushCrmSyncAddRoomType(json);
		logger.info("consumePushCrmSyncAddRoomType consume end:" + json);
	}
	
	// 收到crm删除房型消息
	@MkTopicConsumer(topic = "pushCrmSyncDelRoomTypeOfSwitchMsg", group = "Basic_Switch_PmsSyncHotel", invokeThreadCount=1, serializerClass = "com.mk.kafka.client.serializer.StringDecoder")
	public void consumePushCrmSyncDelRoomType(String json) {
		logger.info("consumePushCrmSyncDelRoomType consume begin:" + json);
		roomtypeService.syncPushCrmSyncDelRoomType(json);
		logger.info("consumePushCrmSyncDelRoomType consume end:" + json);
	}
	
	// 收到crm房型更新信息
	@MkTopicConsumer(topic = "crm_roomTypeInfoUpdate", group = "Basic_Switch_PmsSyncHotel", invokeThreadCount=1, serializerClass = "com.mk.kafka.client.serializer.StringDecoder")
	public void crmRoomTypeInfoUpdate(String json) {
		logger.info("consumePushCrmSyncDelRoomType consume begin:" + json);
		roomtypeinfoService.crmRoomTypeInfoUpdate(json);
		logger.info("consumePushCrmSyncDelRoomType consume end:" + json);
	}
	
	@MkTopicConsumer(topic = "CRM_Push_Switch_syncStatusOnline", group = "Basic_Switch_syncStatusOnline", invokeThreadCount=1, serializerClass = "com.mk.kafka.client.serializer.StringDecoder")
	public void syncStatusOnline(String json) {
		logger.info("syncStatusOnline begin:" + json);
		hotelService.syncStatusOnline(json);
		logger.info("syncStatusOnline end:" + json);
	}

}
