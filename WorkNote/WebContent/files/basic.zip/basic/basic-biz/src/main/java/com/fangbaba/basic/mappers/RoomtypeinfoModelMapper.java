package com.fangbaba.basic.mappers;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.fangbaba.basic.face.bean.RoomtypeinfoModel;
import com.fangbaba.basic.face.bean.RoomtypeinfoModelExample;

public interface RoomtypeinfoModelMapper {
    int countByExample(RoomtypeinfoModelExample example);

    int deleteByExample(RoomtypeinfoModelExample example);

    int deleteByPrimaryKey(Long id);

    int insert(RoomtypeinfoModel record);

    int insertSelective(RoomtypeinfoModel record);

    List<RoomtypeinfoModel> selectByExampleWithBLOBs(RoomtypeinfoModelExample example);

    List<RoomtypeinfoModel> selectByExample(RoomtypeinfoModelExample example);

    RoomtypeinfoModel selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") RoomtypeinfoModel record, @Param("example") RoomtypeinfoModelExample example);

    int updateByExampleWithBLOBs(@Param("record") RoomtypeinfoModel record, @Param("example") RoomtypeinfoModelExample example);

    int updateByExample(@Param("record") RoomtypeinfoModel record, @Param("example") RoomtypeinfoModelExample example);

    int updateByPrimaryKeySelective(RoomtypeinfoModel record);

    int updateByPrimaryKeyWithBLOBs(RoomtypeinfoModel record);

    int updateByPrimaryKey(RoomtypeinfoModel record);
    
    public RoomtypeinfoModel findRoomtypeinfoByRoomtypeId(@Param("roomtypeid") Long roomtypeid);

	public List<RoomtypeinfoModel> findRoomtypeinfoByRoomtypeIds(@Param("roomtypeids") List<Long> roomtypeids);
}