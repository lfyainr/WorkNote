package com.fangbaba.basic.mappers;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.fangbaba.basic.face.bean.DistributionDailyPrice;
import com.fangbaba.basic.face.bean.DistributionDailyPriceExample;

public interface DistributionDailyPriceMapper {
	int countByExample(DistributionDailyPriceExample example);

	int deleteByExample(DistributionDailyPriceExample example);

	int deleteByPrimaryKey(Long id);

	int insert(DistributionDailyPrice record);

	int insertSelective(DistributionDailyPrice record);

	List<DistributionDailyPrice> selectByExample(DistributionDailyPriceExample example);

	DistributionDailyPrice selectByPrimaryKey(Long id);

	int updateByExampleSelective(@Param("record") DistributionDailyPrice record, @Param("example") DistributionDailyPriceExample example);

	int updateByExample(@Param("record") DistributionDailyPrice record, @Param("example") DistributionDailyPriceExample example);

	int updateByPrimaryKeySelective(DistributionDailyPrice record);

	int updateByPrimaryKey(DistributionDailyPrice record);

	/**
	 * 批量插入分销日常价
	 * 
	 * @param list
	 * @return
	 */
	int batchInsert(List<DistributionDailyPrice> list);

	/**
	 * 根据房型删除
	 * 
	 * @param list
	 * @return
	 */
	int deleteByRoomTypeId(Long hotelId, List<DistributionDailyPrice> list);

	/**
	 * 根据酒店房型查分销日常价
	 * 
	 * @param hotelPms
	 * @param roomtypePmsNo
	 * @return
	 */
	DistributionDailyPrice selectByHotelAndRoomtype(@Param("hotelId") Long hotelId, @Param("roomtypeId") Long roomtypeId);

}