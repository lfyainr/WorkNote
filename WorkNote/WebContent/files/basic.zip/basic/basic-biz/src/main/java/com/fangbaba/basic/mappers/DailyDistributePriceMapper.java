package com.fangbaba.basic.mappers;

import com.fangbaba.basic.face.bean.DailyDistributePrice;
import com.fangbaba.basic.face.bean.DailyDistributePriceExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DailyDistributePriceMapper {
    int countByExample(DailyDistributePriceExample example);

    int deleteByExample(DailyDistributePriceExample example);

    int deleteByPrimaryKey(Long id);

    int insert(DailyDistributePrice record);

    int insertSelective(DailyDistributePrice record);

    List<DailyDistributePrice> selectByExample(DailyDistributePriceExample example);

    DailyDistributePrice selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") DailyDistributePrice record, @Param("example") DailyDistributePriceExample example);

    int updateByExample(@Param("record") DailyDistributePrice record, @Param("example") DailyDistributePriceExample example);

    int updateByPrimaryKeySelective(DailyDistributePrice record);

    int updateByPrimaryKey(DailyDistributePrice record);
}