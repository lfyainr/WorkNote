package com.fangbaba.basic.face.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HotelBusinessExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    protected int limitStart = -1;

    protected int limitEnd = -1;

    public HotelBusinessExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimitStart(int limitStart) {
        this.limitStart=limitStart;
    }

    public int getLimitStart() {
        return limitStart;
    }

    public void setLimitEnd(int limitEnd) {
        this.limitEnd=limitEnd;
    }

    public int getLimitEnd() {
        return limitEnd;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Long value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Long value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Long value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Long value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Long value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Long value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Long> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Long> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Long value1, Long value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Long value1, Long value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andHotelidIsNull() {
            addCriterion("hotelid is null");
            return (Criteria) this;
        }

        public Criteria andHotelidIsNotNull() {
            addCriterion("hotelid is not null");
            return (Criteria) this;
        }

        public Criteria andHotelidEqualTo(Long value) {
            addCriterion("hotelid =", value, "hotelid");
            return (Criteria) this;
        }

        public Criteria andHotelidNotEqualTo(Long value) {
            addCriterion("hotelid <>", value, "hotelid");
            return (Criteria) this;
        }

        public Criteria andHotelidGreaterThan(Long value) {
            addCriterion("hotelid >", value, "hotelid");
            return (Criteria) this;
        }

        public Criteria andHotelidGreaterThanOrEqualTo(Long value) {
            addCriterion("hotelid >=", value, "hotelid");
            return (Criteria) this;
        }

        public Criteria andHotelidLessThan(Long value) {
            addCriterion("hotelid <", value, "hotelid");
            return (Criteria) this;
        }

        public Criteria andHotelidLessThanOrEqualTo(Long value) {
            addCriterion("hotelid <=", value, "hotelid");
            return (Criteria) this;
        }

        public Criteria andHotelidIn(List<Long> values) {
            addCriterion("hotelid in", values, "hotelid");
            return (Criteria) this;
        }

        public Criteria andHotelidNotIn(List<Long> values) {
            addCriterion("hotelid not in", values, "hotelid");
            return (Criteria) this;
        }

        public Criteria andHotelidBetween(Long value1, Long value2) {
            addCriterion("hotelid between", value1, value2, "hotelid");
            return (Criteria) this;
        }

        public Criteria andHotelidNotBetween(Long value1, Long value2) {
            addCriterion("hotelid not between", value1, value2, "hotelid");
            return (Criteria) this;
        }

        public Criteria andHotelpmsIsNull() {
            addCriterion("hotelpms is null");
            return (Criteria) this;
        }

        public Criteria andHotelpmsIsNotNull() {
            addCriterion("hotelpms is not null");
            return (Criteria) this;
        }

        public Criteria andHotelpmsEqualTo(String value) {
            addCriterion("hotelpms =", value, "hotelpms");
            return (Criteria) this;
        }

        public Criteria andHotelpmsNotEqualTo(String value) {
            addCriterion("hotelpms <>", value, "hotelpms");
            return (Criteria) this;
        }

        public Criteria andHotelpmsGreaterThan(String value) {
            addCriterion("hotelpms >", value, "hotelpms");
            return (Criteria) this;
        }

        public Criteria andHotelpmsGreaterThanOrEqualTo(String value) {
            addCriterion("hotelpms >=", value, "hotelpms");
            return (Criteria) this;
        }

        public Criteria andHotelpmsLessThan(String value) {
            addCriterion("hotelpms <", value, "hotelpms");
            return (Criteria) this;
        }

        public Criteria andHotelpmsLessThanOrEqualTo(String value) {
            addCriterion("hotelpms <=", value, "hotelpms");
            return (Criteria) this;
        }

        public Criteria andHotelpmsLike(String value) {
            addCriterion("hotelpms like", value, "hotelpms");
            return (Criteria) this;
        }

        public Criteria andHotelpmsNotLike(String value) {
            addCriterion("hotelpms not like", value, "hotelpms");
            return (Criteria) this;
        }

        public Criteria andHotelpmsIn(List<String> values) {
            addCriterion("hotelpms in", values, "hotelpms");
            return (Criteria) this;
        }

        public Criteria andHotelpmsNotIn(List<String> values) {
            addCriterion("hotelpms not in", values, "hotelpms");
            return (Criteria) this;
        }

        public Criteria andHotelpmsBetween(String value1, String value2) {
            addCriterion("hotelpms between", value1, value2, "hotelpms");
            return (Criteria) this;
        }

        public Criteria andHotelpmsNotBetween(String value1, String value2) {
            addCriterion("hotelpms not between", value1, value2, "hotelpms");
            return (Criteria) this;
        }

        public Criteria andPurchasingIsNull() {
            addCriterion("purchasing is null");
            return (Criteria) this;
        }

        public Criteria andPurchasingIsNotNull() {
            addCriterion("purchasing is not null");
            return (Criteria) this;
        }

        public Criteria andPurchasingEqualTo(Integer value) {
            addCriterion("purchasing =", value, "purchasing");
            return (Criteria) this;
        }

        public Criteria andPurchasingNotEqualTo(Integer value) {
            addCriterion("purchasing <>", value, "purchasing");
            return (Criteria) this;
        }

        public Criteria andPurchasingGreaterThan(Integer value) {
            addCriterion("purchasing >", value, "purchasing");
            return (Criteria) this;
        }

        public Criteria andPurchasingGreaterThanOrEqualTo(Integer value) {
            addCriterion("purchasing >=", value, "purchasing");
            return (Criteria) this;
        }

        public Criteria andPurchasingLessThan(Integer value) {
            addCriterion("purchasing <", value, "purchasing");
            return (Criteria) this;
        }

        public Criteria andPurchasingLessThanOrEqualTo(Integer value) {
            addCriterion("purchasing <=", value, "purchasing");
            return (Criteria) this;
        }

        public Criteria andPurchasingIn(List<Integer> values) {
            addCriterion("purchasing in", values, "purchasing");
            return (Criteria) this;
        }

        public Criteria andPurchasingNotIn(List<Integer> values) {
            addCriterion("purchasing not in", values, "purchasing");
            return (Criteria) this;
        }

        public Criteria andPurchasingBetween(Integer value1, Integer value2) {
            addCriterion("purchasing between", value1, value2, "purchasing");
            return (Criteria) this;
        }

        public Criteria andPurchasingNotBetween(Integer value1, Integer value2) {
            addCriterion("purchasing not between", value1, value2, "purchasing");
            return (Criteria) this;
        }

        public Criteria andDistributionIsNull() {
            addCriterion("distribution is null");
            return (Criteria) this;
        }

        public Criteria andDistributionIsNotNull() {
            addCriterion("distribution is not null");
            return (Criteria) this;
        }

        public Criteria andDistributionEqualTo(Integer value) {
            addCriterion("distribution =", value, "distribution");
            return (Criteria) this;
        }

        public Criteria andDistributionNotEqualTo(Integer value) {
            addCriterion("distribution <>", value, "distribution");
            return (Criteria) this;
        }

        public Criteria andDistributionGreaterThan(Integer value) {
            addCriterion("distribution >", value, "distribution");
            return (Criteria) this;
        }

        public Criteria andDistributionGreaterThanOrEqualTo(Integer value) {
            addCriterion("distribution >=", value, "distribution");
            return (Criteria) this;
        }

        public Criteria andDistributionLessThan(Integer value) {
            addCriterion("distribution <", value, "distribution");
            return (Criteria) this;
        }

        public Criteria andDistributionLessThanOrEqualTo(Integer value) {
            addCriterion("distribution <=", value, "distribution");
            return (Criteria) this;
        }

        public Criteria andDistributionIn(List<Integer> values) {
            addCriterion("distribution in", values, "distribution");
            return (Criteria) this;
        }

        public Criteria andDistributionNotIn(List<Integer> values) {
            addCriterion("distribution not in", values, "distribution");
            return (Criteria) this;
        }

        public Criteria andDistributionBetween(Integer value1, Integer value2) {
            addCriterion("distribution between", value1, value2, "distribution");
            return (Criteria) this;
        }

        public Criteria andDistributionNotBetween(Integer value1, Integer value2) {
            addCriterion("distribution not between", value1, value2, "distribution");
            return (Criteria) this;
        }

        public Criteria andWashingIsNull() {
            addCriterion("washing is null");
            return (Criteria) this;
        }

        public Criteria andWashingIsNotNull() {
            addCriterion("washing is not null");
            return (Criteria) this;
        }

        public Criteria andWashingEqualTo(Integer value) {
            addCriterion("washing =", value, "washing");
            return (Criteria) this;
        }

        public Criteria andWashingNotEqualTo(Integer value) {
            addCriterion("washing <>", value, "washing");
            return (Criteria) this;
        }

        public Criteria andWashingGreaterThan(Integer value) {
            addCriterion("washing >", value, "washing");
            return (Criteria) this;
        }

        public Criteria andWashingGreaterThanOrEqualTo(Integer value) {
            addCriterion("washing >=", value, "washing");
            return (Criteria) this;
        }

        public Criteria andWashingLessThan(Integer value) {
            addCriterion("washing <", value, "washing");
            return (Criteria) this;
        }

        public Criteria andWashingLessThanOrEqualTo(Integer value) {
            addCriterion("washing <=", value, "washing");
            return (Criteria) this;
        }

        public Criteria andWashingIn(List<Integer> values) {
            addCriterion("washing in", values, "washing");
            return (Criteria) this;
        }

        public Criteria andWashingNotIn(List<Integer> values) {
            addCriterion("washing not in", values, "washing");
            return (Criteria) this;
        }

        public Criteria andWashingBetween(Integer value1, Integer value2) {
            addCriterion("washing between", value1, value2, "washing");
            return (Criteria) this;
        }

        public Criteria andWashingNotBetween(Integer value1, Integer value2) {
            addCriterion("washing not between", value1, value2, "washing");
            return (Criteria) this;
        }

        public Criteria andWashingmodeIsNull() {
            addCriterion("washingmode is null");
            return (Criteria) this;
        }

        public Criteria andWashingmodeIsNotNull() {
            addCriterion("washingmode is not null");
            return (Criteria) this;
        }

        public Criteria andWashingmodeEqualTo(String value) {
            addCriterion("washingmode =", value, "washingmode");
            return (Criteria) this;
        }

        public Criteria andWashingmodeNotEqualTo(String value) {
            addCriterion("washingmode <>", value, "washingmode");
            return (Criteria) this;
        }

        public Criteria andWashingmodeGreaterThan(String value) {
            addCriterion("washingmode >", value, "washingmode");
            return (Criteria) this;
        }

        public Criteria andWashingmodeGreaterThanOrEqualTo(String value) {
            addCriterion("washingmode >=", value, "washingmode");
            return (Criteria) this;
        }

        public Criteria andWashingmodeLessThan(String value) {
            addCriterion("washingmode <", value, "washingmode");
            return (Criteria) this;
        }

        public Criteria andWashingmodeLessThanOrEqualTo(String value) {
            addCriterion("washingmode <=", value, "washingmode");
            return (Criteria) this;
        }

        public Criteria andWashingmodeLike(String value) {
            addCriterion("washingmode like", value, "washingmode");
            return (Criteria) this;
        }

        public Criteria andWashingmodeNotLike(String value) {
            addCriterion("washingmode not like", value, "washingmode");
            return (Criteria) this;
        }

        public Criteria andWashingmodeIn(List<String> values) {
            addCriterion("washingmode in", values, "washingmode");
            return (Criteria) this;
        }

        public Criteria andWashingmodeNotIn(List<String> values) {
            addCriterion("washingmode not in", values, "washingmode");
            return (Criteria) this;
        }

        public Criteria andWashingmodeBetween(String value1, String value2) {
            addCriterion("washingmode between", value1, value2, "washingmode");
            return (Criteria) this;
        }

        public Criteria andWashingmodeNotBetween(String value1, String value2) {
            addCriterion("washingmode not between", value1, value2, "washingmode");
            return (Criteria) this;
        }

        public Criteria andDistributionCreatetimeIsNull() {
            addCriterion("distribution_createtime is null");
            return (Criteria) this;
        }

        public Criteria andDistributionCreatetimeIsNotNull() {
            addCriterion("distribution_createtime is not null");
            return (Criteria) this;
        }

        public Criteria andDistributionCreatetimeEqualTo(Date value) {
            addCriterion("distribution_createtime =", value, "distributionCreatetime");
            return (Criteria) this;
        }

        public Criteria andDistributionCreatetimeNotEqualTo(Date value) {
            addCriterion("distribution_createtime <>", value, "distributionCreatetime");
            return (Criteria) this;
        }

        public Criteria andDistributionCreatetimeGreaterThan(Date value) {
            addCriterion("distribution_createtime >", value, "distributionCreatetime");
            return (Criteria) this;
        }

        public Criteria andDistributionCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("distribution_createtime >=", value, "distributionCreatetime");
            return (Criteria) this;
        }

        public Criteria andDistributionCreatetimeLessThan(Date value) {
            addCriterion("distribution_createtime <", value, "distributionCreatetime");
            return (Criteria) this;
        }

        public Criteria andDistributionCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("distribution_createtime <=", value, "distributionCreatetime");
            return (Criteria) this;
        }

        public Criteria andDistributionCreatetimeIn(List<Date> values) {
            addCriterion("distribution_createtime in", values, "distributionCreatetime");
            return (Criteria) this;
        }

        public Criteria andDistributionCreatetimeNotIn(List<Date> values) {
            addCriterion("distribution_createtime not in", values, "distributionCreatetime");
            return (Criteria) this;
        }

        public Criteria andDistributionCreatetimeBetween(Date value1, Date value2) {
            addCriterion("distribution_createtime between", value1, value2, "distributionCreatetime");
            return (Criteria) this;
        }

        public Criteria andDistributionCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("distribution_createtime not between", value1, value2, "distributionCreatetime");
            return (Criteria) this;
        }

        public Criteria andWashingCreatetimeIsNull() {
            addCriterion("washing_createtime is null");
            return (Criteria) this;
        }

        public Criteria andWashingCreatetimeIsNotNull() {
            addCriterion("washing_createtime is not null");
            return (Criteria) this;
        }

        public Criteria andWashingCreatetimeEqualTo(Date value) {
            addCriterion("washing_createtime =", value, "washingCreatetime");
            return (Criteria) this;
        }

        public Criteria andWashingCreatetimeNotEqualTo(Date value) {
            addCriterion("washing_createtime <>", value, "washingCreatetime");
            return (Criteria) this;
        }

        public Criteria andWashingCreatetimeGreaterThan(Date value) {
            addCriterion("washing_createtime >", value, "washingCreatetime");
            return (Criteria) this;
        }

        public Criteria andWashingCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("washing_createtime >=", value, "washingCreatetime");
            return (Criteria) this;
        }

        public Criteria andWashingCreatetimeLessThan(Date value) {
            addCriterion("washing_createtime <", value, "washingCreatetime");
            return (Criteria) this;
        }

        public Criteria andWashingCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("washing_createtime <=", value, "washingCreatetime");
            return (Criteria) this;
        }

        public Criteria andWashingCreatetimeIn(List<Date> values) {
            addCriterion("washing_createtime in", values, "washingCreatetime");
            return (Criteria) this;
        }

        public Criteria andWashingCreatetimeNotIn(List<Date> values) {
            addCriterion("washing_createtime not in", values, "washingCreatetime");
            return (Criteria) this;
        }

        public Criteria andWashingCreatetimeBetween(Date value1, Date value2) {
            addCriterion("washing_createtime between", value1, value2, "washingCreatetime");
            return (Criteria) this;
        }

        public Criteria andWashingCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("washing_createtime not between", value1, value2, "washingCreatetime");
            return (Criteria) this;
        }

        public Criteria andPurchasingCreatetimeIsNull() {
            addCriterion("purchasing_createtime is null");
            return (Criteria) this;
        }

        public Criteria andPurchasingCreatetimeIsNotNull() {
            addCriterion("purchasing_createtime is not null");
            return (Criteria) this;
        }

        public Criteria andPurchasingCreatetimeEqualTo(Date value) {
            addCriterion("purchasing_createtime =", value, "purchasingCreatetime");
            return (Criteria) this;
        }

        public Criteria andPurchasingCreatetimeNotEqualTo(Date value) {
            addCriterion("purchasing_createtime <>", value, "purchasingCreatetime");
            return (Criteria) this;
        }

        public Criteria andPurchasingCreatetimeGreaterThan(Date value) {
            addCriterion("purchasing_createtime >", value, "purchasingCreatetime");
            return (Criteria) this;
        }

        public Criteria andPurchasingCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("purchasing_createtime >=", value, "purchasingCreatetime");
            return (Criteria) this;
        }

        public Criteria andPurchasingCreatetimeLessThan(Date value) {
            addCriterion("purchasing_createtime <", value, "purchasingCreatetime");
            return (Criteria) this;
        }

        public Criteria andPurchasingCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("purchasing_createtime <=", value, "purchasingCreatetime");
            return (Criteria) this;
        }

        public Criteria andPurchasingCreatetimeIn(List<Date> values) {
            addCriterion("purchasing_createtime in", values, "purchasingCreatetime");
            return (Criteria) this;
        }

        public Criteria andPurchasingCreatetimeNotIn(List<Date> values) {
            addCriterion("purchasing_createtime not in", values, "purchasingCreatetime");
            return (Criteria) this;
        }

        public Criteria andPurchasingCreatetimeBetween(Date value1, Date value2) {
            addCriterion("purchasing_createtime between", value1, value2, "purchasingCreatetime");
            return (Criteria) this;
        }

        public Criteria andPurchasingCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("purchasing_createtime not between", value1, value2, "purchasingCreatetime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}