package com.fangbaba.basic.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.common.geo.GeoPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.es.ElasticsearchProxy;
import com.fangbaba.basic.face.bean.HotelModel;
import com.fangbaba.basic.face.bean.MyException;
import com.fangbaba.basic.face.bean.RoomModel;
import com.fangbaba.basic.face.bean.RoomtypeModel;
import com.fangbaba.basic.face.bean.jsonbean.PmsHotelJsonBean;
import com.fangbaba.basic.face.bean.jsonbean.PmsRoomtypeJsonBean;
import com.fangbaba.basic.face.bean.vo.HotelVo;
import com.fangbaba.basic.face.bean.vo.RoomVo;
import com.fangbaba.basic.face.bean.vo.RoomtypeVo;
import com.fangbaba.basic.face.enums.MyErrorEnum;
import com.fangbaba.basic.face.service.RoomService;
import com.fangbaba.basic.kafka.StandardKafkaProducer;
import com.fangbaba.basic.mappers.CityModelMapper;
import com.fangbaba.basic.mappers.DistrictModelMapper;
import com.fangbaba.basic.mappers.HotelModelMapper;
import com.fangbaba.basic.po.ESHotelExample;
import com.fangbaba.basic.po.HotelModelExample;
import com.fangbaba.basic.service.HotelExtensionService;
import com.fangbaba.basic.service.HotelService;
import com.fangbaba.basic.service.RoomtypeService;
import com.fangbaba.order.common.utils.DateUtils;
import com.google.gson.Gson;

/**
 * @author he 酒店相关接口
 */
@Service
public class HotelServiceImpl implements HotelService {

	private static Logger logger = LoggerFactory.getLogger(HotelServiceImpl.class);
	@Autowired
	private HotelModelMapper hotelModelMapper;
	@Autowired
	private RoomtypeService roomtypeService;
	@Autowired
	private RoomService roomService;
	@Autowired
	private HotelExtensionService hotelExtensionService;
	@Autowired
	private ElasticsearchProxy<ESHotelExample> elasticsearchProxy;
	@Autowired
	private DistrictModelMapper districtModelMapper;
	@Autowired
	private CityModelMapper cityModelMapper;
	@Autowired
	private StandardKafkaProducer standardKafkaProducer;
	
	private Gson gson = new Gson();

	private Map<String, String> psbmap = new HashMap<>();
	{
		psbmap.put("1", "聪启");
		psbmap.put("2", "金盾");
		psbmap.put("3", "神盾");
		psbmap.put("4", "达因");
		psbmap.put("5", "江西航信");
		psbmap.put("6", "倚天金硅");
		psbmap.put("7", "普康迪");
		psbmap.put("8", "华动泰越");
	}

	@Override
	public List<HotelModel> selectAllhotelsWithOtaHotels(Long otatype) {
		HotelServiceImpl.logger.info(HotelServiceImpl.class.getName() + ":queryAllHotelsWithOtaHotels begin");
		try {
			return this.hotelModelMapper.selectAllhotelsWithOtaHotels(otatype);
		} catch (Exception e) {
			HotelServiceImpl.logger.error(HotelServiceImpl.class.getName() + ":queryAllHotelsWithOtaHotels error", e);
			throw e;
		}
	}

	@Override
	public List<HotelModel> queryAllHotels() {
		HotelServiceImpl.logger.info(HotelServiceImpl.class.getName() + ":queryAllHotels begin");
		try {
			// return hotelModelMapper.selectByExampleWithBLOBs(null);
			return this.hotelModelMapper.selectAll(null);
		} catch (Exception e) {
			HotelServiceImpl.logger.error(HotelServiceImpl.class.getName() + ":queryAllHotels error", e);
			throw e;
		}
	}

	@Override
	public Map<String, Object> queryByConditions(HotelModel hotelModel, List<List<Long>> tagids, Integer pageNo, Integer pageSize) {
		Map<String, Object> map = new HashMap<String, Object>();
		/*
		 * HotelModelExample example = new HotelModelExample();
		 * HotelModelExample.Criteria criteria = example.createCriteria();
		 * if(StringUtils.isNotEmpty(hotelModel.getHotelname())){
		 * criteria.andHotelnameLike("%"+hotelModel.getHotelname()+"%"); }
		 */
		// 分页的处理
		Integer count = hotelModelMapper.countByExampleByPage(hotelModel, tagids);
		map.put("total", count);
		map.put("data", hotelModelMapper.selectByExampleByPage(hotelModel, tagids, (pageNo - 1) * pageSize, pageSize));
		return map;
	}

	@Override
	public HotelModel queryById(Long id) {
		HotelServiceImpl.logger.info(HotelServiceImpl.class.getName() + ":queryById begin");
		try {
			return this.hotelModelMapper.selectByPrimaryKey(id);
		} catch (Exception e) {
			HotelServiceImpl.logger.error(HotelServiceImpl.class.getName() + ":queryById error", e);
			throw e;
		}
	}

	@Override
	public HotelModel queryByPms(String pms) {
		HotelServiceImpl.logger.info(HotelServiceImpl.class.getName() + ":queryByPms begin");
		try {
			HotelModelExample example = new HotelModelExample();
			HotelModelExample.Criteria criteria = example.createCriteria();
			criteria.andHotelpmsEqualTo(pms);
			List<HotelModel> list = this.hotelModelMapper.selectByExample(example);
			if (CollectionUtils.isNotEmpty(list)) {
				return list.get(0);
			} else {
				return null;
			}
		} catch (Exception e) {
			HotelServiceImpl.logger.error(HotelServiceImpl.class.getName() + ":queryByPms error", e);
			throw e;
		}
	}

	@Override
	public void syncHotelInfo(String json) {
		HotelServiceImpl.logger.info(HotelServiceImpl.class.getName() + ":syncHotelInfo begin params:{}" + json);
		try {                    
			PmsHotelJsonBean pmsHotelJsonBean = JSON.parseObject(json, PmsHotelJsonBean.class);
			List<PmsRoomtypeJsonBean> roomtypes = pmsHotelJsonBean.getRoomtype();
			HotelModel hotelModel = this.queryByPms(pmsHotelJsonBean.getHotelid());
			// 同步酒店信息
			if (hotelModel != null) {
				// 已存在
				hotelModel.setId(pmsHotelJsonBean.getHotelgdsid());
				hotelModel.setRoomnum(this.countRoomNum(roomtypes));
				hotelModel.setHotelphone(pmsHotelJsonBean.getPhone());
				hotelModel.setHotelname(pmsHotelJsonBean.getHotelname());
				hotelModel.setPmstype(pmsHotelJsonBean.getPmstype());
				hotelModel.setDiscode(pmsHotelJsonBean.getHotelcitycode());
				if(hotelModel.getDiscode() != null && hotelModel.getDiscode() > 0) {
					Integer cityCode = districtModelMapper.queryCityCodeByDistrictCode(hotelModel.getDiscode());
					hotelModel.setCitycode(cityCode);
				}
				if(hotelModel.getCitycode() != null && hotelModel.getCitycode() > 0) {
					Integer provinceCode = cityModelMapper.queryProvinceCodeByCityCode(hotelModel.getCitycode());
					hotelModel.setProvcode(provinceCode);
				}
				hotelModel.setDetailaddr(pmsHotelJsonBean.getHoteladdress());
				hotelModel.setIntroduction(pmsHotelJsonBean.getHoteldesc());
				hotelModel.setHotelcontactname(pmsHotelJsonBean.getHotelcontactor());
				hotelModel.setHotelfax(pmsHotelJsonBean.getHotelfax());
				if (psbmap.containsKey(pmsHotelJsonBean.getPsbcode())) {
					hotelModel.setPsbcode(pmsHotelJsonBean.getPsbcode());
					hotelModel.setPsbname(psbmap.get(pmsHotelJsonBean.getPsbcode()));
				} else {
					hotelModel.setPsbcode("");
					hotelModel.setPsbname("");
				}
				this.updateById(hotelModel);
			} else {
				// 不存在
				hotelModel = new HotelModel();
				hotelModel.setRoomnum(this.countRoomNum(roomtypes));
				hotelModel.setId(pmsHotelJsonBean.getHotelgdsid());
				hotelModel.setHotelphone(pmsHotelJsonBean.getPhone());
				hotelModel.setPmstype(pmsHotelJsonBean.getPmstype());
				hotelModel.setHotelpms(pmsHotelJsonBean.getHotelid());
				hotelModel.setHotelname(pmsHotelJsonBean.getHotelname());
				hotelModel.setDiscode(pmsHotelJsonBean.getHotelcitycode());
				if(hotelModel.getDiscode() != null && hotelModel.getDiscode() > 0) {
					Integer cityCode = districtModelMapper.queryCityCodeByDistrictCode(hotelModel.getDiscode());
					hotelModel.setCitycode(cityCode);
				}
				if(hotelModel.getCitycode() != null && hotelModel.getCitycode() > 0) {
					Integer provinceCode = cityModelMapper.queryProvinceCodeByCityCode(hotelModel.getCitycode());
					hotelModel.setProvcode(provinceCode);
				}
				hotelModel.setDetailaddr(pmsHotelJsonBean.getHoteladdress());
				hotelModel.setIntroduction(pmsHotelJsonBean.getHoteldesc());
				hotelModel.setHotelcontactname(pmsHotelJsonBean.getHotelcontactor());
				hotelModel.setHotelfax(pmsHotelJsonBean.getHotelfax());
				if (psbmap.containsKey(pmsHotelJsonBean.getPsbcode())) {
					hotelModel.setPsbcode(pmsHotelJsonBean.getPsbcode());
					hotelModel.setPsbname(psbmap.get(pmsHotelJsonBean.getPsbcode()));
				} else {
					hotelModel.setPsbcode("");
					hotelModel.setPsbname("");
				}
				hotelModelMapper.insertSelective(hotelModel);
			}
			// 同步房型房间信息
			if (roomtypes != null && roomtypes.size() > 0) {
				this.roomtypeService.syncRoomtypeInfo(hotelModel.getId(), roomtypes, pmsHotelJsonBean.getIdsmap());
			} else {
				// 没有房型的情况
				HotelServiceImpl.logger.info("没有同步房型的数据");
			}
			// 消息同步hotelMode
			standardKafkaProducer.sendSyncHotelModel(JSONObject.toJSONString(hotelModel));
		} catch (Exception e) {
			e.printStackTrace();
			HotelServiceImpl.logger.error(HotelServiceImpl.class.getName() + ":syncHotelInfo error", e);
			throw e;
		}
	}
	
	@Override
	public void syncPushCrmSyncHotelOfSwitchMsg(String json) {
		HotelServiceImpl.logger.info(HotelServiceImpl.class.getName() + ":syncPushCrmSyncHotelOfSwitchMsg begin params:{}" + json);
		try {                    
			PmsHotelJsonBean pmsHotelJsonBean = JSON.parseObject(json, PmsHotelJsonBean.class);
			List<PmsRoomtypeJsonBean> roomtypes = pmsHotelJsonBean.getRoomtype();
			HotelModel hotelModel = this.queryByPms(pmsHotelJsonBean.getHotelid());
			// 同步酒店信息
			if (hotelModel != null) {
				// 已存在
				hotelModel.setId(pmsHotelJsonBean.getHotelgdsid());
				hotelModel.setRoomnum(this.countRoomNum(roomtypes));
				hotelModel.setHotelphone(pmsHotelJsonBean.getPhone());
				hotelModel.setHotelname(pmsHotelJsonBean.getHotelname());
				hotelModel.setPmstype(pmsHotelJsonBean.getPmstype());
				hotelModel.setDiscode(pmsHotelJsonBean.getHotelcitycode());
				if(hotelModel.getDiscode() != null && hotelModel.getDiscode() > 0) {
					Integer cityCode = districtModelMapper.queryCityCodeByDistrictCode(hotelModel.getDiscode());
					hotelModel.setCitycode(cityCode);
				}
				if(hotelModel.getCitycode() != null && hotelModel.getCitycode() > 0) {
					Integer provinceCode = cityModelMapper.queryProvinceCodeByCityCode(hotelModel.getCitycode());
					hotelModel.setProvcode(provinceCode);
				}
				hotelModel.setDetailaddr(pmsHotelJsonBean.getHoteladdress());
				hotelModel.setIntroduction(pmsHotelJsonBean.getHoteldesc());
				hotelModel.setHotelcontactname(pmsHotelJsonBean.getHotelcontactor());
				hotelModel.setHotelfax(pmsHotelJsonBean.getHotelfax());
				if (psbmap.containsKey(pmsHotelJsonBean.getPsbcode())) {
					hotelModel.setPsbcode(pmsHotelJsonBean.getPsbcode());
					hotelModel.setPsbname(psbmap.get(pmsHotelJsonBean.getPsbcode()));
				} else {
					hotelModel.setPsbcode("");
					hotelModel.setPsbname("");
				}
				this.updateById(hotelModel);
			} else {
				// 不存在
				hotelModel = new HotelModel();
				hotelModel.setRoomnum(this.countRoomNum(roomtypes));
				hotelModel.setId(pmsHotelJsonBean.getHotelgdsid());
				hotelModel.setHotelphone(pmsHotelJsonBean.getPhone());
				hotelModel.setPmstype(pmsHotelJsonBean.getPmstype());
				hotelModel.setHotelpms(pmsHotelJsonBean.getHotelid());
				hotelModel.setHotelname(pmsHotelJsonBean.getHotelname());
				hotelModel.setDiscode(pmsHotelJsonBean.getHotelcitycode());
				if(hotelModel.getDiscode() != null && hotelModel.getDiscode() > 0) {
					Integer cityCode = districtModelMapper.queryCityCodeByDistrictCode(hotelModel.getDiscode());
					hotelModel.setCitycode(cityCode);
				}
				if(hotelModel.getCitycode() != null && hotelModel.getCitycode() > 0) {
					Integer provinceCode = cityModelMapper.queryProvinceCodeByCityCode(hotelModel.getCitycode());
					hotelModel.setProvcode(provinceCode);
				}
				hotelModel.setDetailaddr(pmsHotelJsonBean.getHoteladdress());
				hotelModel.setIntroduction(pmsHotelJsonBean.getHoteldesc());
				hotelModel.setHotelcontactname(pmsHotelJsonBean.getHotelcontactor());
				hotelModel.setHotelfax(pmsHotelJsonBean.getHotelfax());
				if (psbmap.containsKey(pmsHotelJsonBean.getPsbcode())) {
					hotelModel.setPsbcode(pmsHotelJsonBean.getPsbcode());
					hotelModel.setPsbname(psbmap.get(pmsHotelJsonBean.getPsbcode()));
				} else {
					hotelModel.setPsbcode("");
					hotelModel.setPsbname("");
				}
				hotelModelMapper.insertSelective(hotelModel);
			}
			// 同步房型房间信息
			if (roomtypes != null && roomtypes.size() > 0) {
				this.roomtypeService.syncRoomtypeInfos(hotelModel.getId(), roomtypes, pmsHotelJsonBean.getIdsmap());
			} else {
				// 没有房型的情况
				HotelServiceImpl.logger.info("没有同步房型的数据");
			}
			// 消息同步hotelMode
			standardKafkaProducer.sendSyncHotelModel(JSONObject.toJSONString(hotelModel));
		} catch (Exception e) {
			e.printStackTrace();
			HotelServiceImpl.logger.error(HotelServiceImpl.class.getName() + ":syncHotelInfo error", e);
			throw e;
		}
	}
	
	private int countRoomNum(List<PmsRoomtypeJsonBean> roomtypes) {
		int roomNum = 0;
		for (PmsRoomtypeJsonBean pmsRoomtypeJsonBean : roomtypes) {
			roomNum += pmsRoomtypeJsonBean.getRoom().size();
		}
		return roomNum;
	}

	private void updateById(HotelModel hotelModel) {
		this.hotelModelMapper.updateByPrimaryKeySelective(hotelModel);
	}

	/**
	 * 查询酒店详情
	 */
	@Override
	public HotelVo queryDetail(Long id, String begintime, String endtime) {
		HotelServiceImpl.logger.info(HotelServiceImpl.class.getName() + ":queryDetail begin");
		try {
			HotelModel hotelModel = this.queryById(id);
			HotelVo hotelVo = new HotelVo();
			hotelVo.setId(hotelModel.getId());
			hotelVo.setHotelname(hotelModel.getHotelname());
			hotelVo.setHotelcontactname(hotelModel.getHotelcontactname());
			hotelVo.setDetailaddr(hotelModel.getDetailaddr());
			hotelVo.setLongitude(hotelModel.getLongitude());
			hotelVo.setLatitude(hotelModel.getLatitude());
			hotelVo.setRoomnum(hotelModel.getRoomnum());
			hotelVo.setIsvisible(hotelModel.getIsvisible());
			hotelVo.setIsonline(hotelModel.getIsonline());
			hotelVo.setRetentiontime(hotelModel.getRetentiontime());
			hotelVo.setDefaultleavetime(hotelModel.getDefaultleavetime());
			hotelVo.setHotelphone(hotelModel.getHotelphone());
			hotelVo.setHoteltype(hotelModel.getHoteltype());
			hotelVo.setDiscode(hotelModel.getDiscode());
			hotelVo.setQtphone(hotelModel.getQtphone());
			hotelVo.setCitycode(hotelModel.getCitycode());
			hotelVo.setProvcode(hotelModel.getProvcode());
			hotelVo.setIntroduction(hotelModel.getIntroduction());
			hotelVo.setProvincename(hotelModel.getProvincename());
			hotelVo.setCityname(hotelModel.getCityname());
			hotelVo.setDistrictname(hotelModel.getDistrictname());
			List<RoomtypeModel> roomtypemodels = this.roomtypeService.queryByHotelId(id);
			List<RoomtypeVo> roomtypes = new ArrayList<RoomtypeVo>();
			for (RoomtypeModel roomtypeModel : roomtypemodels) {
				RoomtypeVo roomtypeVo = new RoomtypeVo();
				roomtypeVo.setId(roomtypeModel.getId());
				roomtypeVo.setHotelid(roomtypeModel.getHotelid());
				// need 封装价格
				roomtypeVo.setCost(roomtypeModel.getCost());
				roomtypeVo.setName(roomtypeModel.getName());
				// need 可用房间数
				roomtypeVo.setRoomnum(roomtypeModel.getRoomnum());
				roomtypeVo.setRoomtypepms(roomtypeModel.getRoomtypepms());
				List<RoomModel> roommodels = this.roomService.queryByRoomTypeId(roomtypeModel.getId());
				List<RoomVo> rooms = new ArrayList<RoomVo>();
				// TODO:是否返回具体房间
				for (RoomModel roomModel : roommodels) {
					RoomVo roomVo = new RoomVo();
					roomVo.setId(roomModel.getId());
					roomVo.setRemark(roomModel.getRemark());
					roomVo.setRoomno(roomModel.getRoomno());
					roomVo.setRoompms(roomModel.getRoompms());
					roomVo.setRoomtypeid(roomModel.getRoomtypeid());
					roomVo.setTel(roomModel.getTel());
					rooms.add(roomVo);
				}
				roomtypeVo.setRooms(rooms);
				roomtypes.add(roomtypeVo);
			}
			hotelVo.setRoomtypes(roomtypes);
			return hotelVo;
		} catch (Exception e) {
			HotelServiceImpl.logger.error(HotelServiceImpl.class.getName() + ":queryDetail error", e);
			throw e;
		}
	}

	@Override
	public HotelModel getPrice(HotelModel hotelModel) {
		/*
		 * HotelModelExample example = new HotelModelExample();
		 * com.fangbaba.basic.po.HotelModelExample.Criteria criteria =
		 * example.createCriteria(); criteria.andIdEqualTo(hotelModel.getId());
		 * List<HotelModel> list = this.hotelModelMapper.selectAll(example); if
		 * (CollectionUtils.isNotEmpty(list)) { return list.get(0); } else {
		 * return null; }
		 */
		return this.hotelModelMapper.getPrice(hotelModel);
	}

	@Override
	public boolean syncHotelForHMS(List<HotelModel> hotelModels) {
		if (CollectionUtils.isNotEmpty(hotelModels)) {
			for (HotelModel hotelModel : hotelModels) {
				HotelModel hotelModel2 = this.queryById(hotelModel.getId());
				if (null != hotelModel2) {
					this.updateById(hotelModel);
					//发kafka消息更新ES酒店数据
					standardKafkaProducer.sendUpdateHotelModel(JSONObject.toJSONString(hotelModel));
				}
			}
			return true;
		} else {
			HotelServiceImpl.logger.info("syncHotelForHMS received nothing.");
		}
		return false;
	}

	@Override
	public List<HotelModel> queryHotelWithHotelids(List<Long> hotelids) {
		if (CollectionUtils.isNotEmpty(hotelids)) {
			/*
			 * HotelModelExample example = new HotelModelExample();
			 * HotelModelExample.Criteria criteria = example.createCriteria();
			 * criteria.andIdIn(hotelids);
			 */
			return hotelModelMapper.queryHotelWithHotelids(hotelids);
		}
		return null;
	}

	@Override
	public List<HotelModel> queryHotelPriceWithHotelids(List<Long> hotelids) {
		if (CollectionUtils.isNotEmpty(hotelids)) {

			return hotelModelMapper.queryHotelPriceWithHotelids(hotelids);
		}
		return null;
	}

	@Override
	public void updateHotelByHotelPms(HotelModel hotelModels) {
		logger.info("CRM修改酒店，参数：{}", JSONObject.toJSON(hotelModels));
		if (hotelModels.getId() == null) {
			this.hotelModelMapper.updateByPmsId(hotelModels);
			logger.info("CRM修改酒店:updateByPmsId");
		} else {
			if (hotelModelMapper.selectByPrimaryKey(hotelModels.getId()) != null) {
				hotelModelMapper.updateByPrimaryKey(hotelModels);
				logger.info("CRM修改酒店:updateByPrimaryKey");
			} else {
				hotelModelMapper.insertSelective(hotelModels);
				logger.info("CRM修改酒店:insertSelective");
			}
		}
		hotelExtensionService.updatePicByHotelPms(hotelModels.getHotelpms(), hotelModels.getHotelpic());
		// 发kafka消息更新ES酒店数据
		standardKafkaProducer.sendUpdateHotelModel(JSONObject.toJSONString(hotelModels));
		logger.info("CRM修改酒店.ok");
	}

	/**
	 * data:[{ //数组，批量给出 hotelid:’’， //酒店id action : ‘’ ,
	 * //操作类型（online在线/offline离线） time:’’, //yyyyMMddHHmmss 该状态有效时间 }]
	 */
	@Override
	public void updateHotelOnlineState(String json) {
		logger.info("更改酒店在线状态，参数：{}", json);
		JSONObject message = JSONObject.parseObject(json);
		JSONArray data = message.getJSONArray("data");
		String action;
		for (int i = 0; i < data.size(); i++) {
			JSONObject object = data.getJSONObject(i);
			// 根据pmsId得酒店信息
			List<HotelModel> hotelModelList = this.hotelModelMapper.selectHotelByHotelPms(object.getString("hotelid"));
			if (hotelModelList == null || hotelModelList.size() == 0) {
				logger.error("修改酒店上下线出错，未找到酒店信息，hotelModelList:{}", gson.toJson(hotelModelList));
				return;
			}
			if (hotelModelList.size() > 1) {
				logger.error("修改酒店上下线出错，发现多家酒店，hotelModelList:{}", gson.toJson(hotelModelList));
			}
			HotelModel hotelModel = hotelModelList.get(0);
			if (object.getString("time").length() > 14) {
				object.put("time", object.getString("time").substring(0, 14));
			}
			Date time = DateUtils.getDateFromString(object.getString("time"));
			if (hotelModel == null) {
				logger.error("修改酒店上下线出错，酒店不存在，hotelpms:{}", object.getString("hotelid"));
				return;
			}
			// 比较时间戳
			if (hotelModel.getIsonlinetime() == null || time.after(hotelModel.getIsonlinetime())) {
				action = object.getString("action");
				logger.info("更新酒店在线状态：酒店id:{},状态：{}", hotelModel.getId(), action);
				hotelModel.setIsonlinetime(time);
				if (("online").equals(action)) {
					hotelModel.setIsonline("T");
					this.hotelModelMapper.updateByPrimaryKeySelective(hotelModel);
				} else if (("offline").equals(action)) {
					hotelModel.setIsonline("F");
					this.hotelModelMapper.updateByPrimaryKeySelective(hotelModel);
				}
				//发kafka消息更新ES酒店数据
				standardKafkaProducer.sendUpdateHotelModel(JSONObject.toJSONString(hotelModel));
			}
		}
	}
	
	@Override
	public void syncStatusOnline(String json) {
		logger.info("syncStatusOnline:参数:{}", json);
		JSONObject data = JSONObject.parseObject(json).getJSONObject("data");
		
		String status = "0".equals(data.getString("status")) ? "T" : "F";
		Date time = DateUtils.getDateFromString(data.getString("changetime"));
		JSONArray hotellist = data.getJSONArray("hotellist");
		for (int i = 0; i < hotellist.size(); i++) {
			JSONObject hotelid = hotellist.getJSONObject(i);
			// 根据pmsId得酒店信息
			List<HotelModel> hotelModelList = this.hotelModelMapper.selectHotelByHotelPms(hotelid.getString("hotelid"));
			if (hotelModelList == null || hotelModelList.size() == 0 || hotelModelList.size() > 1) {
				logger.error("修改酒店上下线出错:{}，hotelModelList:{}", hotelModelList.size() > 1 ? "发现多家酒店" : "未找到酒店信息", gson.toJson(hotelModelList));
				return;
			}
			HotelModel hotelModel = hotelModelList.get(0);
			// 比较时间戳
			if (hotelModel.getIsonlinetime() == null || time.after(hotelModel.getIsonlinetime())) {
				logger.info("更新酒店在线状态：酒店id:{},状态：{}", hotelModel.getId(), status);
				hotelModel.setIsonlinetime(time);
				hotelModel.setIsonline(status);
				this.hotelModelMapper.updateByPrimaryKeySelective(hotelModel);
				//发kafka消息更新ES酒店数据
				standardKafkaProducer.sendUpdateHotelModel(JSONObject.toJSONString(hotelModel));
			}
		}
		logger.info("syncStatusOnline:ok");
	}

	@Override
	public void initESHotelInfo() {
		List<HotelModel> hotels = hotelModelMapper.selectAllHotel();
		List<ESHotelExample> hotelExamples = initESHotelPOJO(hotels);
		elasticsearchProxy.deleteAllDocument();
		elasticsearchProxy.batchAddDocument(hotelExamples);
	}

	public List<ESHotelExample> initESHotelPOJO(List<HotelModel> hotels) {
		List<ESHotelExample> esHotelExamples = new LinkedList<ESHotelExample>();
		for (HotelModel hotelModel : hotels) {
			ESHotelExample esHotelExample = new ESHotelExample();
			esHotelExample.setId(hotelModel.getId());
			esHotelExample.setHotelname(hotelModel.getHotelname());
			esHotelExample.setHotelcontactname(hotelModel.getHotelcontactname());
			esHotelExample.setRegtime(hotelModel.getRegtime());
			esHotelExample.setDetailaddr(hotelModel.getDetailaddr());
			esHotelExample.setLongitude(hotelModel.getLongitude());
			esHotelExample.setLatitude(hotelModel.getLatitude());
			esHotelExample.setOpentime(hotelModel.getOpentime());
			esHotelExample.setRepairtime(hotelModel.getRepairtime());
			esHotelExample.setRoomnum(hotelModel.getRoomnum());
			esHotelExample.setBusinesslicensefront(hotelModel.getBusinesslicensefront());
			esHotelExample.setBusinesslicenseback(hotelModel.getBusinesslicenseback());
			esHotelExample.setHotelpms(hotelModel.getHotelpms());
			esHotelExample.setIsvisible(hotelModel.getIsvisible());
			esHotelExample.setIsonline(hotelModel.getIsonline());
			esHotelExample.setIdcardfront(hotelModel.getIdcardfront());
			esHotelExample.setIdcardback(hotelModel.getIdcardback());
			esHotelExample.setRetentiontime(hotelModel.getRetentiontime());
			esHotelExample.setDefaultleavetime(hotelModel.getDefaultleavetime());
			esHotelExample.setHotelphone(hotelModel.getHotelphone());
			esHotelExample.setHoteltype(hotelModel.getHoteltype());
			esHotelExample.setDiscode(hotelModel.getDiscode());
			esHotelExample.setQtphone(hotelModel.getQtphone());
			esHotelExample.setCitycode(hotelModel.getCitycode());
			esHotelExample.setProvcode(hotelModel.getProvcode());
			esHotelExample.setPmstype(hotelModel.getPmstype());
			esHotelExample.setIntroduction(hotelModel.getIntroduction());
			esHotelExample.setProvincename(hotelModel.getProvincename());
			esHotelExample.setCityname(hotelModel.getCityname());
			esHotelExample.setDistrictname(hotelModel.getDistrictname());
			esHotelExample.setRange(hotelModel.getRange());
			esHotelExample.setMinprice(hotelModel.getMinprice());
			esHotelExample.setMaxprice(hotelModel.getMaxprice());
			esHotelExample.setHotelpic(hotelModel.getHotelpic());
			esHotelExample.setOtatype(hotelModel.getOtatype());
			esHotelExample.setMaxnum(hotelModel.getMaxnum());
			esHotelExample.setMinnum(hotelModel.getMinnum());
			esHotelExample.setTotalroom(hotelModel.getTotalroom());
			esHotelExample.setIsonlinetime(hotelModel.getIsonlinetime());
			// 独有属性
			esHotelExample.setOccupancyrate(BigDecimal.ZERO);
			esHotelExample.setMiddlerate(BigDecimal.ZERO);
			esHotelExample.setPin(new GeoPoint(hotelModel.getLatitude().doubleValue(), hotelModel.getLongitude().doubleValue()));
			esHotelExamples.add(esHotelExample);
		}
		return esHotelExamples;
	}

	@Override
	public List<HotelModel> queryByCondition(HotelModel hotelModel, List<List<Long>> tagids, Integer pageNo, Integer pageSize) {
		return hotelModelMapper.selectByExampleByPage(hotelModel, tagids, (pageNo - 1) * pageSize, pageSize);
	}

	@Override
	public List<HotelModel> queryHotelByHotelPms(String hotelpms) {
		return hotelModelMapper.selectHotelByHotelPms(hotelpms);
	}

	@Override
	public HotelModel queryHotelByPmsOnly(String hotelPms) {
		List<HotelModel> hotelList = hotelModelMapper.selectHotelByHotelPms(hotelPms);
		if (hotelList == null || hotelList.size() == 0) {
			logger.error("没 找到这个酒店：{}", hotelPms);
			throw new MyException(MyErrorEnum.errorNotFindHotel);
		}
		if (hotelList.size() > 1) {
			logger.error("发现多个酒店，pmsid:{}", hotelPms);
			throw new MyException(MyErrorEnum.dateError);
		}
		HotelModel hotel = hotelList.get(0);
		return hotel;
	}
	
	@Override
	public void updateHotelState(String hotelpms, Integer state){
		logger.info("updateHotelState::hotelpms{}, state{}", hotelpms, state);
		List<HotelModel> hotels = hotelModelMapper.selectHotelByHotelPms(hotelpms);
		logger.info("updateHotelState::hotels{}", hotels);
		if (CollectionUtils.isNotEmpty(hotels)) {
			for (HotelModel hotelModel : hotels) {
				hotelModel.setState(state);
				hotelModelMapper.updateByPmsId(hotelModel);
			}
		}
		logger.info("updateHotelState::ok");
	}
}
