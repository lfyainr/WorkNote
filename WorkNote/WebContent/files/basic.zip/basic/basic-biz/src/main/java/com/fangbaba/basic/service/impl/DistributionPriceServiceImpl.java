package com.fangbaba.basic.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.bean.DailyDistributePrice;
import com.fangbaba.basic.face.bean.DailyDistributePriceExample;
import com.fangbaba.basic.face.bean.DistributionPrice;
import com.fangbaba.basic.face.bean.HotelModel;
import com.fangbaba.basic.face.bean.RackDistributePrice;
import com.fangbaba.basic.face.bean.RackDistributePriceExample;
import com.fangbaba.basic.face.bean.RoomtypeModel;
import com.fangbaba.basic.face.service.DistributionPriceService;
import com.fangbaba.basic.kafka.StandardKafkaProducer;
import com.fangbaba.basic.mappers.DailyDistributePriceMapper;
import com.fangbaba.basic.mappers.HotelModelMapper;
import com.fangbaba.basic.mappers.RackDistributePriceMapper;
import com.fangbaba.basic.mappers.RoomtypeModelMapper;
import com.fangbaba.basic.service.HotelService;
import com.fangbaba.basic.service.RoomtypeService;
import com.fangbaba.order.common.utils.DateUtils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Service
public class DistributionPriceServiceImpl implements DistributionPriceService {

	@Autowired
	private DailyDistributePriceMapper dailyDistributePriceMapper;
	@Autowired
	private RackDistributePriceMapper rackDistributePriceMapper;
	@Autowired
	private RoomtypeModelMapper roomtypeModelMapper;
	@Autowired
	private HotelModelMapper hotelModelMapper;
	@Autowired
	private HotelService hotelService;
	@Autowired
	private RoomtypeService roomtypeService;
	@Autowired
	private StandardKafkaProducer standardKafkaProducer;
	// 日常分销价格
	private DistributionPrice ddp = null;
	Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();

	private static Logger logger = LoggerFactory.getLogger(DistributionPriceServiceImpl.class);

	/**
	 * 处理删除条件
	 *
	 * @param deleteCondition
	 * @param roomTypeId
	 * @param day
	 */
	private void saveDeleteCondition(Map<Long, List<Long>> deleteCondition, Long roomTypeId, Long day) {
		List<Long> list = deleteCondition.get(roomTypeId);
		if (list == null) {
			list = new ArrayList<Long>();
			deleteCondition.put(roomTypeId, list);
		}
		list.add(day);
	}

	/**
	 *
	 * @param hotelId
	 * @param roomTypeId
	 */
	private void sendPriceChange(HotelModel hotel, RoomtypeModel roomType) {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("hotelid", hotel.getId());
		jsonObject.put("hotelName", hotel.getHotelname());
		jsonObject.put("roomtypeid", roomType.getId());
		jsonObject.put("roomtypeName", roomType.getName());
		this.standardKafkaProducer.sendPriceChange(jsonObject.toJSONString());
	}

	@Override
	public Integer saveDistributionSpecialPrice(String message) {
		DistributionPriceServiceImpl.logger.info("保存分销特殊价格,参数：{}", message);
		List<DailyDistributePrice> list = new ArrayList<DailyDistributePrice>();
		JSONObject distributionSpecialPriceJSON = JSON.parseObject(message);
		String hotelPmsNo = distributionSpecialPriceJSON.getString("hotelPmsNo");
		JSONArray jsonArray = distributionSpecialPriceJSON.getJSONArray("price");
		DailyDistributePrice distributionSpecialPrice = null;
		HotelModel hotelModel = this.hotelService.queryByPms(hotelPmsNo);
		long hotelId = hotelModel.getId();
		// 批量删除条件
		Map<Long, List<Long>> deleteCondition = new HashMap<Long, List<Long>>();
		for (int i = 0; i < jsonArray.size(); i++) {
			// 组装分销特殊价格
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			distributionSpecialPrice = new DailyDistributePrice();
			distributionSpecialPrice.setCreatetime(new Date());
			distributionSpecialPrice.setDay(Long.valueOf(jsonObject.getString("day").replaceAll("-", "")));
			distributionSpecialPrice.setPrice(jsonObject.getBigDecimal("price"));
			distributionSpecialPrice.setHotelid(hotelId);
			// 查询房型
			String roomtypePmsNo = jsonObject.getString("roomtypePmsNo");
			RoomtypeModel roomtypeModel = this.roomtypeService.queryByPmsOnly(hotelId, roomtypePmsNo);
			this.saveDeleteCondition(deleteCondition, roomtypeModel.getId(), Long.valueOf(jsonObject.getString("day").replaceAll("-", "")));
			distributionSpecialPrice.setRoomtypeid(roomtypeModel.getId());
			list.add(distributionSpecialPrice);
		}
		if (CollectionUtils.isEmpty(list)) {
			DistributionPriceServiceImpl.logger.info("保存分销特殊价格，数据为空，返回0");
			return 0;
		}
		// 删除
		Set<Entry<Long, List<Long>>> set = deleteCondition.entrySet();
		Iterator<Entry<Long, List<Long>>> it = set.iterator();
		DistributionPriceServiceImpl.logger.info("批量删除分销特殊价格，参数：{}", JSON.toJSONString(deleteCondition));
		while (it.hasNext()) {
			Entry<Long, List<Long>> entry = it.next();
			Long rommTypeId = entry.getKey();
			List<Long> dayList = entry.getValue();

			DailyDistributePriceExample example = new DailyDistributePriceExample();
			DailyDistributePriceExample.Criteria criteria = example.createCriteria();
			criteria.andHotelidEqualTo(hotelId);
			criteria.andRoomtypeidEqualTo(rommTypeId);
			criteria.andDayIn(dayList);

			List<DailyDistributePrice> distributePrices = this.dailyDistributePriceMapper.selectByExample(example);
			if (CollectionUtils.isNotEmpty(distributePrices)) {
				for (DailyDistributePrice rackDistributePrice : distributePrices) {

					DailyDistributePriceExample example2 = new DailyDistributePriceExample();
					DailyDistributePriceExample.Criteria criteria2 = example2.createCriteria();
					criteria2.andIdEqualTo(rackDistributePrice.getId());
					this.dailyDistributePriceMapper.deleteByExample(example2);
				}
			}
		}
		// 批量插入
		DistributionPriceServiceImpl.logger.info("批量插入分销特殊价格，参数：{}", JSON.toJSONString(list));
		for (DailyDistributePrice record : list) {
			this.dailyDistributePriceMapper.insertSelective(record);
		}
		Set<Long> roomTypeSet = new HashSet<Long>();
		// 去掉重复的酒店房型
		for (DailyDistributePrice record : list) {
			roomTypeSet.add(record.getRoomtypeid());
		}
		Iterator<Long> roomTypeIt = roomTypeSet.iterator();
		// 发送消息
		while (roomTypeIt.hasNext()) {
			this.sendPriceChange(hotelModel, this.roomtypeService.queryById(roomTypeIt.next()));
		}
		return list.size();
	}

	@Override
	public Integer saveDistributionDailPrice(String message) {
		DistributionPriceServiceImpl.logger.info("保存分销平日价，参数：{}", message);
		JSONObject distributionDailPriceJSON = JSON.parseObject(message);
		String hotelPmsNo = distributionDailPriceJSON.getString("hotelPmsNo");
		JSONArray jsonArray = distributionDailPriceJSON.getJSONArray("price");
		// 得到酒店ID
		HotelModel hotelModel = this.hotelService.queryByPms(hotelPmsNo);
		long hotelId = hotelModel.getId();
		List<Long> roomtypeList = new ArrayList<Long>();
		List<RackDistributePrice> list = new ArrayList<RackDistributePrice>();
		RackDistributePrice distributionDailyPrice = null;
		for (int i = 0; i < jsonArray.size(); i++) {
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			distributionDailyPrice = new RackDistributePrice();
			distributionDailyPrice.setCreatetime(new Date());
			distributionDailyPrice.setHotelid(hotelId);
			// 查询房型
			String roomtypePmsNo = jsonObject.getString("roomtypePmsNo");
			RoomtypeModel roomtypeModel = this.roomtypeService.queryByPmsOnly(hotelId, roomtypePmsNo);
			distributionDailyPrice.setRoomtypeid(roomtypeModel.getId());
			distributionDailyPrice.setPrice(jsonObject.getBigDecimal("price"));
			roomtypeList.add(roomtypeModel.getId());
			list.add(distributionDailyPrice);

		}
		if (CollectionUtils.isEmpty(list)) {
			DistributionPriceServiceImpl.logger.info("保存分销平日价，数据为空，返回0");
			return 0;
		}
		DistributionPriceServiceImpl.logger.info("批量插入分销平日价，参数：{}", JSON.toJSONString(list));
		// 批量删除
		RackDistributePriceExample example = new RackDistributePriceExample();
		RackDistributePriceExample.Criteria criteria = example.createCriteria();
		criteria.andHotelidEqualTo(hotelId);
		criteria.andRoomtypeidIn(roomtypeList);

		List<RackDistributePrice> distributePrices = this.rackDistributePriceMapper.selectByExample(example);
		if (CollectionUtils.isNotEmpty(distributePrices)) {
			for (RackDistributePrice rackDistributePrice : distributePrices) {

				RackDistributePriceExample example2 = new RackDistributePriceExample();
				RackDistributePriceExample.Criteria criteria2 = example2.createCriteria();
				criteria2.andIdEqualTo(rackDistributePrice.getId());
				this.rackDistributePriceMapper.deleteByExample(example2);
			}
		}

		// 批量插入
		for (RackDistributePrice rackDistributePrice : list) {
			this.rackDistributePriceMapper.insertSelective(rackDistributePrice);
		}
		// 发送消息
		for (RackDistributePrice rackDistributePrice : list) {
			this.sendPriceChange(hotelModel, this.roomtypeService.queryById(rackDistributePrice.getRoomtypeid()));
		}
		return list.size();
	}

	@Override
	public RackDistributePrice queryDistributionDailPrice(String hotelPms, String roomtypePmsNo) {
		DistributionPriceServiceImpl.logger.info("查询平日价,参数:hotelPms{},roomtypePmsNo:{}", hotelPms, roomtypePmsNo);
		Long hotelId = null;
		Long roomtypeId = null;
		try {
			hotelId = this.hotelService.queryHotelByPmsOnly(hotelPms).getId();
			roomtypeId = this.roomtypeService.queryByPmsOnly(hotelId, roomtypePmsNo).getId();
		} catch (Exception e) {
			DistributionPriceServiceImpl.logger.error("房型，酒店对应错误，酒店PMS：{},房型PMS:{}", hotelPms, roomtypePmsNo, e);
			return new RackDistributePrice();
		}
		DistributionPriceServiceImpl.logger.info("查询平日价,参数:hotelId{},roomtypeId:{}", hotelId, roomtypeId);

		RackDistributePriceExample example = new RackDistributePriceExample();
		RackDistributePriceExample.Criteria criteria = example.createCriteria();
		criteria.andHotelidEqualTo(hotelId);
		criteria.andRoomtypeidEqualTo(roomtypeId);

		List<RackDistributePrice> distributePrices = this.rackDistributePriceMapper.selectByExample(example);

		if (CollectionUtils.isNotEmpty(distributePrices)) {
			return distributePrices.get(0);
		}
		return null;
		// return dailyDistributePriceMapper.selectByHotelAndRoomtype(hotelId,
		// roomtypeId);
	}

	@Override
	public List<DistributionPrice> queryDistributionPrice(String hotelPmsNo, String roomtypePmsNo, String startTime, String endTime) {
		Long hotelid = null;
		RoomtypeModel roomtypeModel = null;
		try {
			hotelid = this.hotelService.queryHotelByPmsOnly(hotelPmsNo).getId();
			roomtypeModel = this.roomtypeService.queryByPmsOnly(hotelid, roomtypePmsNo);
		} catch (Exception e) {
			DistributionPriceServiceImpl.logger.error("酒店,房型对应错误，pms编码：{}", hotelPmsNo, e);
			return new ArrayList<DistributionPrice>();
		}
		return this.queryDistributionPriceByhotelIdAndRoomTypeId(hotelid, roomtypeModel.getId(), startTime, endTime);
	}

	@Override
	public List<DistributionPrice> queryDistributionPriceByhotelIdAndRoomTypeId(Long hotelid, Long roomtypeId, String startTime, String endTime) {
		// 查询日常价格
		RackDistributePriceExample example = new RackDistributePriceExample();
		RackDistributePriceExample.Criteria criteria = example.createCriteria();
		criteria.andHotelidEqualTo(hotelid);
		criteria.andRoomtypeidEqualTo(roomtypeId);

		List<RackDistributePrice> rackDistributePrices = this.rackDistributePriceMapper.selectByExample(example);
		RackDistributePrice distributionDailyPrice = null;
		if (CollectionUtils.isNotEmpty(rackDistributePrices)) {
			distributionDailyPrice = rackDistributePrices.get(0);
		} else {
			DistributionPriceServiceImpl.logger.error("分销价格，不能没有平常价格,酒店ID:{},房型ID:{}", hotelid, roomtypeId);
			return new ArrayList<DistributionPrice>();
			// throw new MyException(MyErrorEnum.dateError);
		}

		List<Long> days = new ArrayList<Long>();
		// 查询特殊价格
		DailyDistributePriceExample example2 = new DailyDistributePriceExample();
		DailyDistributePriceExample.Criteria criteria2 = example2.createCriteria();
		criteria2.andHotelidEqualTo(hotelid);
		criteria2.andRoomtypeidEqualTo(roomtypeId);
		criteria2.andDayGreaterThanOrEqualTo(Long.valueOf(startTime.replace("-", "")));
		criteria2.andDayLessThanOrEqualTo(Long.valueOf(endTime.replace("-", "")));

		List<DailyDistributePrice> dailyDistributePrices = this.dailyDistributePriceMapper.selectByExample(example2);

		// 整理数据
		Map<String, DailyDistributePrice> distributionSpecialPriceMap = new LinkedHashMap<String, DailyDistributePrice>();
		for (DailyDistributePrice dsp : dailyDistributePrices) {
			String key = dsp.getDay() + "";
			distributionSpecialPriceMap.put(key, dsp);
		}
		// 初始化分销价格
		List<DistributionPrice> list = new ArrayList<DistributionPrice>();
		// 初始化分销日常价格
		this.initDistributionDailyPrice(distributionDailyPrice);
		Date startday = DateUtils.strToDate(startTime, "yyyy-MM-dd");
		Date endtday = DateUtils.strToDate(endTime, "yyyy-MM-dd");
		System.out.println("endday:" + endTime);
		Long day = Long.valueOf(startTime.replace("-", ""));
		// 生成分销价格
		DailyDistributePrice distributionSpecialPrice = null;

		while (startday.compareTo(endtday) != 0) {
			DistributionPrice distributionPrice = new DistributionPrice();
			String startdayString = DateUtils.dateToStr(startday, "yyyy-MM-dd");
			if (distributionSpecialPriceMap.get(DateUtils.dateToStr(startday, "yyyyMMdd")) != null) {
				// 有特殊价格
				distributionSpecialPrice = distributionSpecialPriceMap.get(DateUtils.dateToStr(startday, "yyyyMMdd"));
				distributionPrice.setDay(startdayString);// yyyy-MM-dd
				distributionPrice.setHotelid(hotelid);
				distributionPrice.setPrice(distributionSpecialPrice.getPrice());
				distributionPrice.setWeek(this.getChineseDayOfWeek(startday));
				distributionPrice.setRoomtypeId(distributionSpecialPrice.getRoomtypeid());
			} else {
				DistributionPrice ddp = new DistributionPrice();
				ddp = new DistributionPrice();
				ddp.setHotelid(distributionDailyPrice.getHotelid());
				ddp.setRoomtypeId(distributionDailyPrice.getRoomtypeid());
				ddp.setPrice(distributionDailyPrice.getPrice());
				ddp.setDay(startdayString);
				ddp.setWeek(this.getChineseDayOfWeek(startday));

				// 没有特殊价格
				distributionPrice = ddp;
			}
			list.add(distributionPrice);
			Calendar calendar = new GregorianCalendar();
			calendar.setTime(startday);
			calendar.add(Calendar.DATE, 1);// 把日期往后增加一天.整数往后推,负数往前移动
			startday = calendar.getTime();
		}
		return list;
	}

	/**
	 * 初始化分销日常价格
	 *
	 * @param distributionDailyPrice
	 */
	private void initDistributionDailyPrice(RackDistributePrice distributionDailyPrice) {
		this.ddp = new DistributionPrice();
		this.ddp.setHotelid(distributionDailyPrice.getHotelid());
		this.ddp.setRoomtypeId(distributionDailyPrice.getRoomtypeid());
		this.ddp.setPrice(distributionDailyPrice.getPrice());
	}

	/**
	 * 得到星期
	 *
	 * @param date
	 * @return
	 */
	private String getChineseDayOfWeek(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		int week = calendar.get(Calendar.DAY_OF_WEEK);
		String strWeek = "";

		switch (week) {
		case Calendar.SUNDAY:
			strWeek = "Sun";
			break;
		case Calendar.MONDAY:
			strWeek = "Mon";
			break;
		case Calendar.TUESDAY:
			strWeek = "Tues";
			break;
		case Calendar.WEDNESDAY:
			strWeek = "Wed";
			break;
		case Calendar.THURSDAY:
			strWeek = "Thur";
			break;
		case Calendar.FRIDAY:
			strWeek = "Fri";
			break;
		case Calendar.SATURDAY:
			strWeek = "Sat";
			break;
		}

		return strWeek;
	}
}
