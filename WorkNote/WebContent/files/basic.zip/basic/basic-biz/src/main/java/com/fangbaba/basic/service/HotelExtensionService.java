package com.fangbaba.basic.service;

public interface HotelExtensionService extends com.fangbaba.basic.face.service.HotelExtensionService {
	/**
	 * CMS修改图片
	 * 
	 * @param hotelPms
	 * @param pic
	 */
	public void updatePicByHotelPms(String hotelPms, String pic);
}
