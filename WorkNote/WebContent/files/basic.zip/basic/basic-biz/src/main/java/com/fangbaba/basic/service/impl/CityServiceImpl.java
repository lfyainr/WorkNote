package com.fangbaba.basic.service.impl;

import java.util.List;

import com.fangbaba.basic.face.base.RetInfo;
import com.fangbaba.basic.face.bean.ProvinceModel;
import com.fangbaba.basic.po.ProvinceModelExample;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fangbaba.basic.face.bean.CityModel;
import com.fangbaba.basic.face.service.CityService;
import com.fangbaba.basic.mappers.CityModelMapper;
import com.fangbaba.basic.po.CityModelExample;

/**
 * @author he
 * 城市相关接口
 */
@Service
public class CityServiceImpl implements CityService {
	
	private static Logger logger = LoggerFactory.getLogger(CityServiceImpl.class);
	
	@Autowired
	private CityModelMapper cityModelMapper;

	@Override
	public List<CityModel> queryAllCitys() {
		logger.info(CityServiceImpl.class.getName()+":queryAllCitys begin");
		try {
			return cityModelMapper.selectByExample(null);
		} catch (Exception e) {
			logger.error(CityServiceImpl.class.getName()+":queryAllCitys error",e);
			throw e;
		}
	}

	@Override
	public List<CityModel> queryAllCitysByProvinceCode(Integer proid) {
		CityModelExample example = new CityModelExample();
		example.createCriteria().andProidEqualTo(proid);
		example.setOrderByClause("sort asc");
		return cityModelMapper.selectByExample(example);
	}

	@Override
	public RetInfo<CityModel> queryByCode(String citycode) {
		RetInfo<CityModel> retInfo = new RetInfo<CityModel>();
		if(StringUtils.isBlank(citycode)){
			logger.info("所传参数 citycode为空");
			retInfo.setResult(false);
			retInfo.setMsg("所传参数citycode为空");
			return retInfo;
		}
		CityModelExample example = new CityModelExample();
		CityModelExample.Criteria hoCriteria = example.createCriteria();
		hoCriteria.andCodeEqualTo(citycode);
		List<CityModel> models =  cityModelMapper.selectByExample( example);
		if( models != null && models.size() > 0){
			retInfo.setObj(models.get(0));
			retInfo.setResult(true);
		}else {
			retInfo.setResult(false);
			retInfo.setMsg("未找到"+ citycode + " 省市");
		}
		return retInfo;
	}


}
