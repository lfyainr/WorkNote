package com.fangbaba.basic.kafka;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mk.kafka.client.stereotype.MkMessageService;
import com.mk.kafka.client.stereotype.MkTopicProducer;

@MkMessageService
public class StandardKafkaProducer {

	private Logger logger = LoggerFactory.getLogger(StandardKafkaProducer.class);

	@MkTopicProducer(topic = "standard_test_topic", partitions = 1, serializerClass = "com.mk.kafka.client.serializer.StringEncoder", replicationFactor = 1)
	public void sendMessage(String value) {
		logger.info("StandardKafkaProducer send a message:" + value);
	}

	/**
	 * 更新es
	 */
	@MkTopicProducer(topic = "Gds_inites", partitions = 1, serializerClass = "com.mk.kafka.client.serializer.StringEncoder", replicationFactor = 1, transactional = true)
	public void sendInitEsMessage(String hotelid) {
		logger.info("StandardKafkaProducer sendInitEsMessage:hotelid~" + hotelid);
	}
	
	@MkTopicProducer(topic = "basic_rackrate_change", partitions = 1, serializerClass = "com.mk.kafka.client.serializer.StringEncoder", replicationFactor = 1)
	public void sendRackRateChange(String message) {
		logger.info("StandardKafkaProducer sendRackRateChange:{}", message);
	}

	@MkTopicProducer(topic = "Basic_SyncHotelinfo", partitions = 1, serializerClass = "com.mk.kafka.client.serializer.StringEncoder", replicationFactor = 1, transactional = true)
	public void sendSyncHotelinfo(String message) {
		logger.info("StandardKafkaProducer sendSyncHotelinfo~" + message);
	}
	
	@MkTopicProducer(topic = "Basic_UpdateHotelModel", partitions = 1, serializerClass = "com.mk.kafka.client.serializer.StringEncoder", replicationFactor = 1, transactional = true)
	public void sendUpdateHotelModel(String hotelModel) {
		logger.debug("sendUpdateHotelModel:{}", hotelModel);
	}

	/**
	 * 关闭酒店的分销时发送消息
	 * 
	 * @param message
	 */
	@MkTopicProducer(topic = "Basic_HotelDistrictClose", partitions = 1, serializerClass = "com.mk.kafka.client.serializer.StringEncoder", replicationFactor = 1, transactional = true)
	public void sendHotelDistrictClose(String message) {
		logger.info("sendHotelDistrictClose:{}", message);
	}

	@MkTopicProducer(topic = "Basic_HotelDistrictOpen", partitions = 1, serializerClass = "com.mk.kafka.client.serializer.StringEncoder", replicationFactor = 1, transactional = true)
	public void sendHotelDistrictOpen(String message) {
		logger.info("sendHotelDistrictOpen:{}", message);
	}

	@MkTopicProducer(topic = "Basic_HotelDistrictChange", partitions = 1, serializerClass = "com.mk.kafka.client.serializer.StringEncoder", replicationFactor = 1, transactional = true)
	public void sendHotelBusinessChange(String message) {
		logger.info("sendHotelDistrictChange:{}", message);
	}

	@MkTopicProducer(topic = "Basic_SyncHotelModel", partitions = 1, serializerClass = "com.mk.kafka.client.serializer.StringEncoder", replicationFactor = 1, transactional = true)
	public void sendSyncHotelModel(String hotelModel) {
		logger.info("sendSyncHotelModel:{}", hotelModel);
	}

	/**
	 * 酒店价格变化消息
	 * 
	 * @param price
	 */
	@MkTopicProducer(topic = "Basic_hotel_price_change", partitions = 1, serializerClass = "com.mk.kafka.client.serializer.StringEncoder", replicationFactor = 1, transactional = true)
	public void sendPriceChange(String price) {
		logger.info("发送酒店价格变化通知:{}", price);
	}
	
	/**
	 * 酒店变化消息
	 * 
	 * @param price
	 */
	@MkTopicProducer(topic = "Basic_hotel_sync_change", partitions = 1, serializerClass = "com.mk.kafka.client.serializer.StringEncoder", replicationFactor = 1, transactional = true)
	public void sendSyncHotelChange(String hotelid) {
		logger.info("sendSyncHotelChange:{}", hotelid);
	}
	
	/**
	 * 通知设置了channelid消息
	 * @param json
	 */
	@MkTopicProducer(topic = "Basic_HotelChannelid_Change", partitions = 1, serializerClass = "com.mk.kafka.client.serializer.StringEncoder", replicationFactor = 1, transactional = true)
	public void sendHotelChannelIdUpdate(String json) {
		logger.info("sendHotelChannelIdUpdate:{}", json);
	}
	
	/**
	 * 房型变化
	 * @param data
	 */
	@MkTopicProducer(topic = "Basic_RoomtypeChange", partitions = 1, serializerClass = "com.mk.kafka.client.serializer.StringEncoder", replicationFactor = 1, transactional = true)
	public void sendRoomtypeChange(String data) {
		logger.info("房型变化::sendRoomtypeChange:{}", data);
	}
}
