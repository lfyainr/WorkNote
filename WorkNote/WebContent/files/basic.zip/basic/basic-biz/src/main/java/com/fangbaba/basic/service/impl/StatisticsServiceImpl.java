/**
 * 
 */
package com.fangbaba.basic.service.impl;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.common.geo.GeoDistance;
import org.elasticsearch.common.unit.DistanceUnit;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.GeoDistanceFilterBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.sort.SortOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fangbaba.basic.es.ElasticsearchProxy;
import com.fangbaba.basic.face.bean.HotelModel;
import com.fangbaba.basic.face.bean.MyException;
import com.fangbaba.basic.face.service.HotelService;
import com.fangbaba.basic.face.service.StatisticsService;

/**
 * @author yub
 *
 */

@Service("statisticsService")
public class StatisticsServiceImpl implements StatisticsService {
	
	private final static Logger log = LoggerFactory.getLogger(StatisticsServiceImpl.class);
	
	@Autowired
	private HotelService hotelService;
	@Autowired
	private ElasticsearchProxy<Object> esProxy;

	@Override
	public BigDecimal findOccupancyRankingOfRegion(String hotelpms) {
		try {
			if(StringUtils.isBlank(hotelpms)) {
				log.error("StatisticsService method findOccupancyRankingOfRegion --- param 错误 ：{}", hotelpms);
				throw new MyException("-1", "参数错误");
			}
			HotelModel hotel = hotelService.queryByPms(hotelpms);
			if(hotel == null) {
				log.error("StatisticsService method findOccupancyRankingOfRegion --- 酒店hotelpms : {} 不存在", hotelpms);
				throw new MyException("-2", "酒店不存在");
			}
			String hotelid = String.valueOf(hotel.getId());
			if(StringUtils.isBlank(hotelid)) {
				log.error("StatisticsService method findOccupancyRankingOfRegion --- 酒店hotelpms : {} 酒店ID为空", hotelpms);
				throw new MyException("-3", "酒店ID为空");
			}
			SearchRequestBuilder searchBuilder = esProxy.prepareSearch();
			 // 设置查询类型 1.SearchType.DFS_QUERY_THEN_FETCH = 精确查询 2.SearchType.SCAN = 扫描查询,无序
			searchBuilder.setSearchType(SearchType.DFS_QUERY_THEN_FETCH);
			GeoDistanceFilterBuilder geoFilter = FilterBuilders.geoDistanceFilter("pin");
			if(hotel.getLatitude() == null || hotel.getLongitude() == null) {
				log.error("StatisticsService method findOccupancyRankingOfRegion --- 数据库中酒店hotelid {} hotelpms {} 坐标字段值为空", hotelid, hotelpms);
				throw new MyException("-4", "酒店坐标为空");
			}
			//周边3KM
			geoFilter.point(hotel.getLatitude().doubleValue(), hotel.getLongitude().doubleValue()).distance(3, DistanceUnit.KILOMETERS).optimizeBbox("memory").geoDistance(GeoDistance.ARC);
			searchBuilder.setPostFilter(geoFilter);
			searchBuilder.addSort("occupancyrate", SortOrder.DESC);
			//ES查询默认10条记录
			searchBuilder.setFrom(0).setSize(10000).setExplain(true);
			SearchResponse searchResponse = searchBuilder.execute().actionGet();
			SearchHit[] searchHits = searchResponse.getHits().getHits();
			for (int i = 0; i < searchHits.length; i++) {
				SearchHit searchHit = searchHits[i];
				Map<String, Object> doc = searchHit.getSource();
				if(StringUtils.isBlank(String.valueOf(doc.get("id")))) {
					log.error("StatisticsService method findOccupancyRankingOfRegion --- ES查询周边酒店入住率排名酒店ID为空  hotelpms {}", hotelpms);
					throw new MyException("-5", "ES数据异常");
				}
				if(doc.get("id").toString().equals(hotelid)) {
					return new BigDecimal(i + 1);
				}
			}
		} catch (ElasticsearchException e) {
			log.error("StatisticsService method findOccupancyRankingOfRegion --- ES查询周边酒店入住率排名异常 hotelpms {} exception {}", hotelpms, e);
			e.printStackTrace();
		} 
		return BigDecimal.ZERO;
	}

	@Override
	public BigDecimal findMiddleRateOfRegion(String hotelpms) {
		try {
			if(StringUtils.isBlank(hotelpms)) {
				log.error("StatisticsService method findOccupancyRankingOfRegion --- param 错误 ：{}", hotelpms);
				throw new MyException("-1", "参数错误");
			}
			HotelModel hotel = hotelService.queryByPms(hotelpms);
			if(hotel == null) {
				log.error("StatisticsService method findOccupancyRankingOfRegion --- 酒店hotelpms : {} 不存在", hotelpms);
				throw new MyException("-2", "酒店不存在");
			}
//			String hotelid = String.valueOf(hotel.getId());
//			if(StringUtils.isBlank(hotelid)) {
//				log.error("StatisticsService method findOccupancyRankingOfRegion --- 酒店hotelpms : {} 酒店ID为空", hotelpms);
//				return BigDecimal.ZERO;
//			}
			SearchRequestBuilder searchBuilder = esProxy.prepareSearch();
			 // 设置查询类型 1.SearchType.DFS_QUERY_THEN_FETCH = 精确查询 2.SearchType.SCAN = 扫描查询,无序
			searchBuilder.setSearchType(SearchType.DFS_QUERY_THEN_FETCH);
			GeoDistanceFilterBuilder geoFilter = FilterBuilders.geoDistanceFilter("pin");
			if(hotel.getLatitude() == null || hotel.getLongitude() == null) {
				log.error("StatisticsService method findOccupancyRankingOfRegion --- 数据库中酒店 hotelpms {} 坐标字段值为空", hotelpms);
				throw new MyException("-3", "酒店坐标为空");
			}
			//周边3KM
			geoFilter.point(hotel.getLatitude().doubleValue(), hotel.getLongitude().doubleValue()).distance(3, DistanceUnit.KILOMETERS).optimizeBbox("memory").geoDistance(GeoDistance.ARC);
			searchBuilder.setPostFilter(geoFilter);
			//ES查询默认10条记录
			searchBuilder.setFrom(0).setSize(10000).setExplain(true);
			SearchResponse searchResponse = searchBuilder.execute().actionGet();
			SearchHit[] searchHits = searchResponse.getHits().getHits();
			BigDecimal totalPirce = BigDecimal.ZERO;
			BigDecimal hotelCount = new BigDecimal(searchHits.length);
			for (int i = 0; i < searchHits.length; i++) {
				SearchHit searchHit = searchHits[i];
				Map<String, Object> doc = searchHit.getSource();
				String middlerate = String.valueOf(doc.get("middlerate"));
				if(StringUtils.isNotBlank(middlerate))
					totalPirce = totalPirce.add(new BigDecimal(middlerate));
				else
					log.error("StatisticsService method findOccupancyRankingOfRegion --- es中_index: basic, type: hotel,  _id : {}, hotelid : {} 的酒店数据middlerate为空", searchHit.getId(), doc.get("id"));
			}
			return totalPirce.divide(hotelCount, 2, BigDecimal.ROUND_HALF_UP);
		} catch (ElasticsearchException e) {
			log.error("StatisticsService method findOccupancyRankingOfRegion --- ES查询周边酒店入住率排名异常 hotelpms {} exception {}", hotelpms, e);
			e.printStackTrace();
		}
		return BigDecimal.ZERO;
	}
}
