/**
 * 
 */
package com.fangbaba.basic.kafka;

import java.util.LinkedList;
import java.util.List;

import org.elasticsearch.search.SearchHit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.fangbaba.basic.es.ElasticsearchProxy;
import com.fangbaba.basic.face.bean.HotelModel;
import com.fangbaba.basic.po.ESHotelExample;
import com.fangbaba.basic.service.HotelService;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.mk.kafka.client.exception.KafkaMessageConsumeException;
import com.mk.kafka.client.stereotype.MkMessageService;
import com.mk.kafka.client.stereotype.MkTopicConsumer;

/**
 * 异步更新ES
 * @author yubin
 *
 */
@MkMessageService
public class ESHotelInfoConsumer {


	@Autowired
	private HotelService hotelService;
	@Autowired
	private ElasticsearchProxy<ESHotelExample> elasticsearchProxy;
	

	private static final Logger logger = LoggerFactory.getLogger(ESHotelInfoConsumer.class);
	private Gson gson = new Gson();
	
	@MkTopicConsumer(topic = "Basic_SyncHotelModel",  group = "basic_es_hotel", serializerClass = "com.mk.kafka.client.serializer.StringDecoder")
	public void syncHotelUpdateES(String json) {
		try {
			logger.info("开始消费同步订单数据kafka topic::Basic_SyncHotelModel");
			updateESHotelInfo(json);
			logger.info("消费同步订单数据kafka完成");
		} catch (Exception e) {
			new KafkaMessageConsumeException(e);
		}
	}
	
	
	@MkTopicConsumer(topic = "Basic_UpdateHotelModel",  group = "basic_es_hotel", serializerClass = "com.mk.kafka.client.serializer.StringDecoder")
	public void updateHotelUpdateES(String json) {
		try {
			logger.info("开始消费同步订单数据kafka topic ::Basic_UpdateHotelModel");
			updateESHotelInfo(json);
			logger.info("消费同步订单数据kafka完成");
		} catch (Exception e) {
			new KafkaMessageConsumeException(e);
		}
	}
	
	
	private void updateESHotelInfo(String json) {
		try {
			logger.info("updateESHotelInfo::syncHotelUpdateES:{}", json);
			HotelModel hotelModel = gson.fromJson(json, HotelModel.class);
			String hotelid = String.valueOf(hotelModel.getId());
			logger.info("updateESHotelInfo::hotelid: {}", hotelid);
			if(hotelid == null)
				throw new KafkaMessageConsumeException("更新酒店数据后更新ES 酒店信息ID为空");
			SearchHit[] searchHits = elasticsearchProxy.searchHotelByHotelId(hotelid);
			if (searchHits.length > 1) {
				logger.info("hotel: " + hotelid + " ES result list size > 1");
			}
			logger.info("查询ES酒店信息 size ：" + searchHits.length);
			for (int i = 0; i < searchHits.length; i++) {
				SearchHit searchHit = searchHits[i];
				String _id = searchHit.getId();
				elasticsearchProxy.deleteDocument(_id);
			}
			List<HotelModel> hotels = new LinkedList<HotelModel>();
			hotels.add(hotelModel);
			List<ESHotelExample> esHotelExamples = hotelService.initESHotelPOJO(hotels);
			logger.info("更新ES酒店信息   json : " + gson.toJson(esHotelExamples));
			elasticsearchProxy.batchAddDocument(esHotelExamples);
		} catch (JsonSyntaxException e) {
			throw new KafkaMessageConsumeException("添加酒店数据后更新ES 酒店信息ID为空", e);
		}
	}
}
