package com.fangbaba.basic.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class Temp {

	public static void main(String[] args) {
		String sql = "select * from hotel limit 3";
		Object application = null;
		BasicDataSource ds = (BasicDataSource) WebApplicationContextUtils.getWebApplicationContext(application).getBean("masterDataSource");
		Connection conn = ds.getConnection();
		Statement sm = conn.createStatement();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			if (sql.toLowerCase().startsWith("select")) {
				ResultSet rs = pstmt.executeQuery();
				int col = rs.getMetaData().getColumnCount();
				
				while (rs.next()) {
					for (int i = 1; i <= col; i++) {
						rs.getMetaData().getColumnName(i);
						System.out.print(rs.getString(i) + "\t");
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
