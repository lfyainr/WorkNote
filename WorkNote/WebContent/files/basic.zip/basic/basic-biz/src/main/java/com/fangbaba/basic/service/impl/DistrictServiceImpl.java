package com.fangbaba.basic.service.impl;

import java.util.List;

import com.fangbaba.basic.face.base.RetInfo;
import com.fangbaba.basic.face.bean.CityModel;
import com.fangbaba.basic.po.CityModelExample;
import com.fangbaba.basic.po.DistrictModelExample;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fangbaba.basic.face.bean.DistrictModel;
import com.fangbaba.basic.face.service.DistrictService;
import com.fangbaba.basic.mappers.DistrictModelMapper;

/**
 * @author he
 * 区域相关接口
 */
@Service
public class DistrictServiceImpl implements DistrictService {
	
	private static Logger logger = LoggerFactory.getLogger(DistrictServiceImpl.class);
	
	@Autowired
	private DistrictModelMapper districtModelMapper;

	@Override
	public List<DistrictModel> queryAllDistricts() {
		logger.info(DistrictServiceImpl.class.getName()+":queryAllDistricts begin");
		try {
			return districtModelMapper.selectByExample(null);
		} catch (Exception e) {
			logger.error(DistrictServiceImpl.class.getName()+":queryAllDistricts error",e);
			throw e;
		}
	}

	@Override
	public RetInfo<DistrictModel> queryByCode(String districtcode) {
		RetInfo<DistrictModel> retInfo = new RetInfo<DistrictModel>();
		if(StringUtils.isBlank(districtcode)){
			logger.info("所传参数 districtcode 为空");
			retInfo.setResult(false);
			retInfo.setMsg("所传参数 districtcode 为空");
			return retInfo;
		}
		DistrictModelExample example = new DistrictModelExample();
		DistrictModelExample.Criteria hoCriteria = example.createCriteria();
		hoCriteria.andCodeEqualTo(districtcode);
		List<DistrictModel> models =  districtModelMapper.selectByExample( example);
		if( models != null && models.size() > 0){
			retInfo.setObj(models.get(0));
			retInfo.setResult(true);
		}else {
			retInfo.setResult(false);
			retInfo.setMsg("未找到"+ districtcode + " 区县");
		}
		return retInfo;
	}

}
