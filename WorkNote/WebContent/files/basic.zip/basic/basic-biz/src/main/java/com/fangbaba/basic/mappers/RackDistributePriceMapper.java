package com.fangbaba.basic.mappers;

import com.fangbaba.basic.face.bean.RackDistributePrice;
import com.fangbaba.basic.face.bean.RackDistributePriceExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface RackDistributePriceMapper {
    int countByExample(RackDistributePriceExample example);

    int deleteByExample(RackDistributePriceExample example);

    int deleteByPrimaryKey(Long id);

    int insert(RackDistributePrice record);

    int insertSelective(RackDistributePrice record);

    List<RackDistributePrice> selectByExample(RackDistributePriceExample example);

    RackDistributePrice selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") RackDistributePrice record, @Param("example") RackDistributePriceExample example);

    int updateByExample(@Param("record") RackDistributePrice record, @Param("example") RackDistributePriceExample example);

    int updateByPrimaryKeySelective(RackDistributePrice record);

    int updateByPrimaryKey(RackDistributePrice record);
}