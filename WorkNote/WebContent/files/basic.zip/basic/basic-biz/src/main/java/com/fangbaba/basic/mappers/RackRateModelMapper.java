package com.fangbaba.basic.mappers;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.fangbaba.basic.face.bean.RackRateModel;
import com.fangbaba.basic.po.RackRateModelExample;

public interface RackRateModelMapper {
    int countByExample(RackRateModelExample example);

    int deleteByExample(RackRateModelExample example);

    int deleteByPrimaryKey(Long id);

    int insert(RackRateModel record);

    int insertSelective(RackRateModel record);

    List<RackRateModel> selectByExample(RackRateModelExample example);

    RackRateModel selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") RackRateModel record, @Param("example") RackRateModelExample example);

    int updateByExample(@Param("record") RackRateModel record, @Param("example") RackRateModelExample example);

    int updateByPrimaryKeySelective(RackRateModel record);

    int updateByPrimaryKey(RackRateModel record);
    
    int genRackRates(@Param("hotelids") List<Long> hotelids);
    
    int genRackDistributePrices(@Param("hotelids") List<Long> hotelids);
}