package com.fangbaba.basic.mappers;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.fangbaba.basic.face.bean.DailyRateModel;
import com.fangbaba.basic.face.bean.WeekendRateModel;
import com.fangbaba.basic.po.WeekendRateModelExample;

public interface WeekendRateModelMapper {
    int countByExample(WeekendRateModelExample example);

    int deleteByExample(WeekendRateModelExample example);

    int deleteByPrimaryKey(Long id);

    int insert(WeekendRateModel record);

    int insertSelective(WeekendRateModel record);

    List<WeekendRateModel> selectByExample(WeekendRateModelExample example);

    WeekendRateModel selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") WeekendRateModel record, @Param("example") WeekendRateModelExample example);

    int updateByExample(@Param("record") WeekendRateModel record, @Param("example") WeekendRateModelExample example);

    int updateByPrimaryKeySelective(WeekendRateModel record);

    int updateByPrimaryKey(WeekendRateModel record);
    
    List<WeekendRateModel> findWeekendRates(@Param("hotelid") Long hotelid, @Param("roomtypeids") List<Long> roomtypeids, @Param("weeks") List<Integer> weeks);
    
}