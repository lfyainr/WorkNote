package com.mk.oms.bean;

import java.io.Serializable;

public class ResultDubbo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1172105538042758240L;
	private boolean success;
	private String _MSG_;
	private Object _DATA_ = new Object();;

	public ResultDubbo() {
	}

	public ResultDubbo(boolean success) {
		this.success = success;
	}

	public ResultDubbo(boolean success, String msg) {
		this.success = success;
		this._MSG_ = msg;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String get_MSG_() {
		String msg = "OK,";
		if (success) {
			msg = "OK,";
		} else {
			msg = "ERROR," + this._MSG_;
		}

		return msg;
	}

	public void set_MSG_(String _MSG_) {
		this._MSG_ = _MSG_;
	}

	public Object get_DATA_() {
		return _DATA_;
	}

	public void set_DATA_(Object _DATA_) {
		this._DATA_ = _DATA_;
	}
}
