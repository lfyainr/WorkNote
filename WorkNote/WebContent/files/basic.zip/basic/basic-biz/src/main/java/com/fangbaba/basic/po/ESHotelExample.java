/**
 * 
 */
package com.fangbaba.basic.po;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.elasticsearch.common.geo.GeoPoint;

/**
 * @author yub
 *
 */
public class ESHotelExample implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6185114636018667734L;
	
	

	private Long id;

	private String hotelname;

	private String hotelcontactname;

	private Date regtime;

	private String detailaddr;

	private BigDecimal longitude;

	private BigDecimal latitude;

	private Date opentime;

	private Date repairtime;

	private Integer roomnum;

	private String businesslicensefront;

	private String businesslicenseback;

	private String hotelpms;

	private String isvisible;

	private String isonline;

	private String idcardfront;

	private String idcardback;

	private String retentiontime;

	private String defaultleavetime;

	private String hotelphone;

	private Integer hoteltype;

	private Integer discode;

	private String qtphone;

	private Integer citycode;

	private Integer provcode;

	private String pmstype;

	private String introduction;

	private String provincename;// 省名称
	
	private String cityname;// 市
	
	private String districtname;// 县
	
	private Double range = 5000d;// 搜索范围，默认5000m
	
	private BigDecimal minprice;
	
	private BigDecimal maxprice;
	
	private String hotelpic;// 图片
	
	private Long otatype;
	
	private Integer maxnum;// 房量搜索条件
	
	private Integer minnum;// 房量搜索条件
	
	private Integer totalroom;// 房量
	
	private Date isonlinetime;// 上下线时间戳
	
	private BigDecimal occupancyrate;  //入住率
	
	private BigDecimal middlerate;  //平均价
	
	private GeoPoint pin; //酒店坐标

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the hotelname
	 */
	public String getHotelname() {
		return hotelname;
	}

	/**
	 * @param hotelname the hotelname to set
	 */
	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}

	/**
	 * @return the hotelcontactname
	 */
	public String getHotelcontactname() {
		return hotelcontactname;
	}

	/**
	 * @param hotelcontactname the hotelcontactname to set
	 */
	public void setHotelcontactname(String hotelcontactname) {
		this.hotelcontactname = hotelcontactname;
	}

	/**
	 * @return the regtime
	 */
	public Date getRegtime() {
		return regtime;
	}

	/**
	 * @param regtime the regtime to set
	 */
	public void setRegtime(Date regtime) {
		this.regtime = regtime;
	}

	/**
	 * @return the detailaddr
	 */
	public String getDetailaddr() {
		return detailaddr;
	}

	/**
	 * @param detailaddr the detailaddr to set
	 */
	public void setDetailaddr(String detailaddr) {
		this.detailaddr = detailaddr;
	}

	/**
	 * @return the longitude
	 */
	public BigDecimal getLongitude() {
		return longitude;
	}

	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(BigDecimal longitude) {
		this.longitude = longitude;
	}

	/**
	 * @return the latitude
	 */
	public BigDecimal getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(BigDecimal latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return the opentime
	 */
	public Date getOpentime() {
		return opentime;
	}

	/**
	 * @param opentime the opentime to set
	 */
	public void setOpentime(Date opentime) {
		this.opentime = opentime;
	}

	/**
	 * @return the repairtime
	 */
	public Date getRepairtime() {
		return repairtime;
	}

	/**
	 * @param repairtime the repairtime to set
	 */
	public void setRepairtime(Date repairtime) {
		this.repairtime = repairtime;
	}

	/**
	 * @return the roomnum
	 */
	public Integer getRoomnum() {
		return roomnum;
	}

	/**
	 * @param roomnum the roomnum to set
	 */
	public void setRoomnum(Integer roomnum) {
		this.roomnum = roomnum;
	}

	/**
	 * @return the businesslicensefront
	 */
	public String getBusinesslicensefront() {
		return businesslicensefront;
	}

	/**
	 * @param businesslicensefront the businesslicensefront to set
	 */
	public void setBusinesslicensefront(String businesslicensefront) {
		this.businesslicensefront = businesslicensefront;
	}

	/**
	 * @return the businesslicenseback
	 */
	public String getBusinesslicenseback() {
		return businesslicenseback;
	}

	/**
	 * @param businesslicenseback the businesslicenseback to set
	 */
	public void setBusinesslicenseback(String businesslicenseback) {
		this.businesslicenseback = businesslicenseback;
	}

	/**
	 * @return the hotelpms
	 */
	public String getHotelpms() {
		return hotelpms;
	}

	/**
	 * @param hotelpms the hotelpms to set
	 */
	public void setHotelpms(String hotelpms) {
		this.hotelpms = hotelpms;
	}

	/**
	 * @return the isvisible
	 */
	public String getIsvisible() {
		return isvisible;
	}

	/**
	 * @param isvisible the isvisible to set
	 */
	public void setIsvisible(String isvisible) {
		this.isvisible = isvisible;
	}

	/**
	 * @return the isonline
	 */
	public String getIsonline() {
		return isonline;
	}

	/**
	 * @param isonline the isonline to set
	 */
	public void setIsonline(String isonline) {
		this.isonline = isonline;
	}

	/**
	 * @return the idcardfront
	 */
	public String getIdcardfront() {
		return idcardfront;
	}

	/**
	 * @param idcardfront the idcardfront to set
	 */
	public void setIdcardfront(String idcardfront) {
		this.idcardfront = idcardfront;
	}

	/**
	 * @return the idcardback
	 */
	public String getIdcardback() {
		return idcardback;
	}

	/**
	 * @param idcardback the idcardback to set
	 */
	public void setIdcardback(String idcardback) {
		this.idcardback = idcardback;
	}

	/**
	 * @return the retentiontime
	 */
	public String getRetentiontime() {
		return retentiontime;
	}

	/**
	 * @param retentiontime the retentiontime to set
	 */
	public void setRetentiontime(String retentiontime) {
		this.retentiontime = retentiontime;
	}

	/**
	 * @return the defaultleavetime
	 */
	public String getDefaultleavetime() {
		return defaultleavetime;
	}

	/**
	 * @param defaultleavetime the defaultleavetime to set
	 */
	public void setDefaultleavetime(String defaultleavetime) {
		this.defaultleavetime = defaultleavetime;
	}

	/**
	 * @return the hotelphone
	 */
	public String getHotelphone() {
		return hotelphone;
	}

	/**
	 * @param hotelphone the hotelphone to set
	 */
	public void setHotelphone(String hotelphone) {
		this.hotelphone = hotelphone;
	}

	/**
	 * @return the hoteltype
	 */
	public Integer getHoteltype() {
		return hoteltype;
	}

	/**
	 * @param hoteltype the hoteltype to set
	 */
	public void setHoteltype(Integer hoteltype) {
		this.hoteltype = hoteltype;
	}

	/**
	 * @return the discode
	 */
	public Integer getDiscode() {
		return discode;
	}

	/**
	 * @param discode the discode to set
	 */
	public void setDiscode(Integer discode) {
		this.discode = discode;
	}

	/**
	 * @return the qtphone
	 */
	public String getQtphone() {
		return qtphone;
	}

	/**
	 * @param qtphone the qtphone to set
	 */
	public void setQtphone(String qtphone) {
		this.qtphone = qtphone;
	}

	/**
	 * @return the citycode
	 */
	public Integer getCitycode() {
		return citycode;
	}

	/**
	 * @param citycode the citycode to set
	 */
	public void setCitycode(Integer citycode) {
		this.citycode = citycode;
	}

	/**
	 * @return the provcode
	 */
	public Integer getProvcode() {
		return provcode;
	}

	/**
	 * @param provcode the provcode to set
	 */
	public void setProvcode(Integer provcode) {
		this.provcode = provcode;
	}

	/**
	 * @return the pmstype
	 */
	public String getPmstype() {
		return pmstype;
	}

	/**
	 * @param pmstype the pmstype to set
	 */
	public void setPmstype(String pmstype) {
		this.pmstype = pmstype;
	}

	/**
	 * @return the introduction
	 */
	public String getIntroduction() {
		return introduction;
	}

	/**
	 * @param introduction the introduction to set
	 */
	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}

	/**
	 * @return the provincename
	 */
	public String getProvincename() {
		return provincename;
	}

	/**
	 * @param provincename the provincename to set
	 */
	public void setProvincename(String provincename) {
		this.provincename = provincename;
	}

	/**
	 * @return the cityname
	 */
	public String getCityname() {
		return cityname;
	}

	/**
	 * @param cityname the cityname to set
	 */
	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	/**
	 * @return the districtname
	 */
	public String getDistrictname() {
		return districtname;
	}

	/**
	 * @param districtname the districtname to set
	 */
	public void setDistrictname(String districtname) {
		this.districtname = districtname;
	}

	/**
	 * @return the range
	 */
	public Double getRange() {
		return range;
	}

	/**
	 * @param range the range to set
	 */
	public void setRange(Double range) {
		this.range = range;
	}

	/**
	 * @return the minprice
	 */
	public BigDecimal getMinprice() {
		return minprice;
	}

	/**
	 * @param minprice the minprice to set
	 */
	public void setMinprice(BigDecimal minprice) {
		this.minprice = minprice;
	}

	/**
	 * @return the maxprice
	 */
	public BigDecimal getMaxprice() {
		return maxprice;
	}

	/**
	 * @param maxprice the maxprice to set
	 */
	public void setMaxprice(BigDecimal maxprice) {
		this.maxprice = maxprice;
	}

	/**
	 * @return the hotelpic
	 */
	public String getHotelpic() {
		return hotelpic;
	}

	/**
	 * @param hotelpic the hotelpic to set
	 */
	public void setHotelpic(String hotelpic) {
		this.hotelpic = hotelpic;
	}

	/**
	 * @return the otatype
	 */
	public Long getOtatype() {
		return otatype;
	}

	/**
	 * @param otatype the otatype to set
	 */
	public void setOtatype(Long otatype) {
		this.otatype = otatype;
	}

	/**
	 * @return the maxnum
	 */
	public Integer getMaxnum() {
		return maxnum;
	}

	/**
	 * @param maxnum the maxnum to set
	 */
	public void setMaxnum(Integer maxnum) {
		this.maxnum = maxnum;
	}

	/**
	 * @return the minnum
	 */
	public Integer getMinnum() {
		return minnum;
	}

	/**
	 * @param minnum the minnum to set
	 */
	public void setMinnum(Integer minnum) {
		this.minnum = minnum;
	}

	/**
	 * @return the totalroom
	 */
	public Integer getTotalroom() {
		return totalroom;
	}

	/**
	 * @param totalroom the totalroom to set
	 */
	public void setTotalroom(Integer totalroom) {
		this.totalroom = totalroom;
	}

	/**
	 * @return the isonlinetime
	 */
	public Date getIsonlinetime() {
		return isonlinetime;
	}

	/**
	 * @param isonlinetime the isonlinetime to set
	 */
	public void setIsonlinetime(Date isonlinetime) {
		this.isonlinetime = isonlinetime;
	}

	
	
	/**
	 * @return the occupancyrate
	 */
	public BigDecimal getOccupancyrate() {
		return occupancyrate;
	}

	/**
	 * @param occupancyrate the occupancyrate to set
	 */
	public void setOccupancyrate(BigDecimal occupancyrate) {
		this.occupancyrate = occupancyrate;
	}

	/**
	 * @return the middlerate
	 */
	public BigDecimal getMiddlerate() {
		return middlerate;
	}

	/**
	 * @param middlerate the middlerate to set
	 */
	public void setMiddlerate(BigDecimal middlerate) {
		this.middlerate = middlerate;
	}

	/**
	 * @return the pin
	 */
	public GeoPoint getPin() {
		return pin;
	}

	/**
	 * @param pin the pin to set
	 */
	public void setPin(GeoPoint pin) {
		this.pin = pin;
	}
	
	
	
	

}
