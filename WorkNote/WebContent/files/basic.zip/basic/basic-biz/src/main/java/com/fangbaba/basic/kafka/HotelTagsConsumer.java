package com.fangbaba.basic.kafka;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.service.HotelTagsService;
import com.mk.kafka.client.stereotype.MkMessageService;
import com.mk.kafka.client.stereotype.MkTopicConsumer;

@MkMessageService
public class HotelTagsConsumer {

	private Logger logger = LoggerFactory.getLogger(HotelTagsConsumer.class);
	
	@Autowired
	HotelTagsService hotelTagsService;
	
	@MkTopicConsumer(topic = "Crm_SyncHotelTags",  group = "Crm_SyncHotelTags",serializerClass = "com.mk.kafka.client.serializer.StringDecoder")
	public void consumeHotelTags(String json) {
		logger.info("consumeHotelTags:json:{}", json);
		
		JSONObject data = JSONObject.parseObject(json);
		String hotelid = data.getString("hotelid");
		String _ids = data.getString("tagids");
		List<Long> ids = new ArrayList<>();
		if (_ids != null && _ids.length() > 0) {
			for (String id : _ids.split(",")) {
				ids.add(Long.parseLong(id));
			}
		}
		hotelTagsService.updateHotelTags(hotelid, ids);
	}
}
