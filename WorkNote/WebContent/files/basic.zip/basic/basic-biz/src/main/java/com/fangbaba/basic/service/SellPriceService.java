package com.fangbaba.basic.service;

import java.util.Date;
import java.util.List;

import com.fangbaba.basic.face.bean.DailyRateModel;
import com.fangbaba.basic.face.bean.RackRateModel;
import com.fangbaba.basic.face.bean.WeekendRateModel;
import com.fangbaba.basic.face.bean.jsonbean.DailyRateJsonBean;
import com.fangbaba.basic.face.bean.jsonbean.RackRateJsonBean;
import com.fangbaba.basic.face.bean.jsonbean.WeekendRateJsonBean;

/**
 * @author he
 * 房价service
 * 平日价、周末价、特殊价
 */
public interface SellPriceService extends com.fangbaba.basic.face.service.SellPriceService {
	/**
	 * @param hotelid 酒店id
	 * @param roomtypeid 房型id
	 * 查询平日价
	 */
	public RackRateModel findRackRateByConditions(Long hotelid,Long roomtypeid);
	/**
	 * 保存平日价
	 */
	public int saveRackRate(RackRateModel rackRateModel);
	/**
	 * 更新平日价
	 */
	public int updateRackRate(RackRateModel rackRateModel);
	
	/**
	 * @param hotelid 酒店id
	 * 根据酒店id查询酒店特殊价
	 */
	public List<DailyRateModel> findDailyRatesByHotelid(Long hotelid,Long roomtypeid);
	/**
	 * 批量保存特殊价
	 */
	public Integer saveBatchDailyRate(List<DailyRateModel> insertBatchList);
	/**
	 * 批量更新特殊价
	 */
	public Integer updateBatchDailyRate(List<DailyRateModel> updateBatchList);
	/**
	 * 同步特殊价
	 */
	public boolean syncDailyRate(DailyRateJsonBean dailyRateJsonBean, Long hotelid);
	/**
	 * 同步门市价
	 * @return 是否有改动 
	 */
	public boolean syncRackRate(RackRateJsonBean rackRateJsonBean,Long hotelid);
	/**
	 * @param hotelid 酒店id
	 * @param roomtypeid 房型id
	 * 查询周末价
	 */
	public List<WeekendRateModel> findWeekendRatesByConditions(Long hotelid, Long roomtypeid,Integer week);
	/**
	 * 保存周末价
	 */
	public int saveWeekendRate(WeekendRateModel weekendRateModel);
	/**
	 * 更新周末价
	 */
	public int updateEWeekendRate(WeekendRateModel weekendRateModel);
	/**
	 * 同步周末价
	 */
	public boolean syncWeekendRate(WeekendRateJsonBean weekendRateJsonBean,Long hotelid);
	
}
