package com.fangbaba.basic.mappers;

import com.fangbaba.basic.face.bean.HotelBusiness;
import com.fangbaba.basic.face.bean.HotelBusinessExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface HotelBusinessMapper {
    int countByExample(HotelBusinessExample example);

    int deleteByExample(HotelBusinessExample example);

    int deleteByPrimaryKey(Long id);

    int insert(HotelBusiness record);

    int insertSelective(HotelBusiness record);

    List<HotelBusiness> selectByExample(HotelBusinessExample example);

    HotelBusiness selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") HotelBusiness record, @Param("example") HotelBusinessExample example);

    int updateByExample(@Param("record") HotelBusiness record, @Param("example") HotelBusinessExample example);

    int updateByPrimaryKeySelective(HotelBusiness record);

    int updateByPrimaryKey(HotelBusiness record);
}