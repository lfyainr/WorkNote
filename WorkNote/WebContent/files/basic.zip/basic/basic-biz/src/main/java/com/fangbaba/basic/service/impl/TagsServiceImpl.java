package com.fangbaba.basic.service.impl;

import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fangbaba.basic.face.bean.Tags;
import com.fangbaba.basic.face.service.TagsService;
import com.fangbaba.basic.mappers.TagsMapper;

@Service
public class TagsServiceImpl implements TagsService {
	private static Logger logger = LoggerFactory.getLogger(TagsServiceImpl.class);
	@Autowired
	TagsMapper tagsMapper;

	@Override
	public List<Tags> queryTagsByGroupId(Long groupId) {
		logger.info("queryTagsByGroupId:{}", groupId);
		return tagsMapper.queryTagsByGroupId(groupId);
	}
}
