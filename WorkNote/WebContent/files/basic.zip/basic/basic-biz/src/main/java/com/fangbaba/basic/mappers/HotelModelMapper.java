package com.fangbaba.basic.mappers;

import com.fangbaba.basic.face.bean.HotelModel;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.fangbaba.basic.face.bean.HotelModel;
import com.fangbaba.basic.po.HotelModelExample;

public interface HotelModelMapper {
    int countByExample(HotelModelExample example);

    int deleteByExample(HotelModelExample example);

	int deleteByPrimaryKey(Long id);

	int insert(HotelModel record);

    int insertSelective(HotelModel record);

	HotelModel getPrice(HotelModel record);

	List<HotelModel> selectByExampleWithBLOBs(HotelModelExample example);

	List<HotelModel> selectAll(HotelModelExample example);

	List<HotelModel> selectAllhotelsWithOtaHotels(@Param("otatype") Long otatype);

	List<HotelModel> queryHotelWithHotelids(@Param("hotelids") List<Long> hotelids);

	List<HotelModel> queryHotelPriceWithHotelids(@Param("hotelids") List<Long> hotelids);

	List<HotelModel> selectByExample(HotelModelExample example);

	HotelModel selectByPrimaryKey(Long id);

	int updateByExampleSelective(@Param("record") HotelModel record, @Param("example") HotelModelExample example);

    int updateByExampleWithBLOBs(@Param("record") HotelModel record, @Param("example") HotelModelExample example);

	int updateByExample(@Param("record") HotelModel record, @Param("example") HotelModelExample example);

	int updateByPrimaryKeySelective(HotelModel record);

	int updateByPrimaryKeyWithBLOBs(HotelModel record);

	int updateByPrimaryKey(HotelModel record);

	List<HotelModel> selectByExampleByPage(@Param("hotelModel") HotelModel hotelModel, @Param("tagids") List<List<Long>> tagids, @Param("limitstart") Integer limitstart, @Param("limitend") Integer limitend);

	int countByExampleByPage(@Param("hotelModel") HotelModel hotelModel, @Param("tagids") List<List<Long>> tagids);

	/**
	 * 查询所有酒店
	 * 
	 * @return
	 */
	public List<HotelModel> selectAllHotel();

	/**
	 * 根据pmsId修改
	 * 
	 * @param record
	 * @return
	 */
	int updateByPmsId(HotelModel record);

	/**
	 * 根据酒店pms查酒店
	 * 
	 * @param hotelPms
	 * @return
	 */
	List<HotelModel> selectHotelByHotelPms(String hotelpms);
}