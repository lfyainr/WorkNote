package com.fangbaba.basic.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.bean.HotelModel;
import com.fangbaba.basic.face.bean.MyException;
import com.fangbaba.basic.face.bean.RoomtypeModel;
import com.fangbaba.basic.face.bean.RoomtypeinfoModelExample;
import com.fangbaba.basic.face.bean.RoomtypeinfoModelExample.Criteria;
import com.fangbaba.basic.face.bean.jsonbean.PmsHotelJsonBean;
import com.fangbaba.basic.face.bean.jsonbean.PmsRoomtypeJsonBean;
import com.fangbaba.basic.face.bean.jsonbean.RoomtypeJsonBean;
import com.fangbaba.basic.face.enums.MyErrorEnum;
import com.fangbaba.basic.face.service.HotelService;
import com.fangbaba.basic.kafka.StandardKafkaProducer;
import com.fangbaba.basic.mappers.RackRateModelMapper;
import com.fangbaba.basic.mappers.RoomtypeModelMapper;
import com.fangbaba.basic.mappers.RoomtypeinfoModelMapper;
import com.fangbaba.basic.po.HotelModelExample;
import com.fangbaba.basic.po.RackRateModelExample;
import com.fangbaba.basic.po.RoomtypeModelExample;
import com.fangbaba.basic.service.RoomService;
import com.fangbaba.basic.service.RoomtypeService;
import com.google.gson.Gson;

/**
 * @author he 房型相关接口
 */
@Service
public class RoomtypeServiceImpl implements RoomtypeService {

	private static Logger logger = LoggerFactory.getLogger(RoomtypeServiceImpl.class);

	@Autowired
	private RoomtypeModelMapper roomtypeModelMapper;
	@Autowired
	private RoomtypeinfoModelMapper roomtypeinfoModelMapper;
	@Autowired
	private RoomService roomService;
	@Autowired
	private HotelService hotelService;
	@Autowired
	private StandardKafkaProducer standardKafkaProducer;
	@Autowired
	private RackRateModelMapper rackRateModelMapper;

	Gson gson = new Gson();

	@Override
	public BigDecimal queryPriceByRoomTypeId(Long id) {
		RoomtypeServiceImpl.logger.info(RoomtypeServiceImpl.class.getName() + ":queryPriceByRoomTypeId begin");
		try {
			RoomtypeModel bean = this.roomtypeModelMapper.selectByPrimaryKey(id);
			if (bean == null) {
				return null;
			}
			return bean.getCost();
		} catch (Exception e) {
			RoomtypeServiceImpl.logger.error(RoomtypeServiceImpl.class.getName() + ":queryPriceByRoomTypeId error", e);
			throw e;
		}
	}

	@Override
	public RoomtypeModel queryById(Long id) {
		RoomtypeServiceImpl.logger.info(RoomtypeServiceImpl.class.getName() + ":queryById begin");
		try {
			return this.roomtypeModelMapper.selectByPrimaryKey(id);
		} catch (Exception e) {
			RoomtypeServiceImpl.logger.error(RoomtypeServiceImpl.class.getName() + ":queryById error", e);
			throw e;
		}
	}

	@Override
	public List<RoomtypeModel> queryByHotelId(Long hotelid) {
		RoomtypeServiceImpl.logger.info(RoomtypeServiceImpl.class.getName() + ":queryByHotelId begin");
		try {
			RoomtypeModelExample example = new RoomtypeModelExample();
			RoomtypeModelExample.Criteria criteria = example.createCriteria();
			criteria.andHotelidEqualTo(hotelid);
			return this.roomtypeModelMapper.selectByExample(example);
		} catch (Exception e) {
			RoomtypeServiceImpl.logger.error(RoomtypeServiceImpl.class.getName() + ":queryByHotelId error", e);
			throw e;
		}
	}

	@Override
	public RoomtypeModel queryByPmsAndHotelid(String pms, Long hotelid) {
		RoomtypeServiceImpl.logger.info(RoomtypeServiceImpl.class.getName() + ":queryByPms begin");
		try {
			RoomtypeModelExample example = new RoomtypeModelExample();
			example.createCriteria().andHotelidEqualTo(hotelid).andRoomtypepmsEqualTo(pms);
			List<RoomtypeModel> list = this.roomtypeModelMapper.selectByExample(example);
			if (CollectionUtils.isNotEmpty(list)) {
				return list.get(0);
			} else {
				return null;
			}
		} catch (Exception e) {
			RoomtypeServiceImpl.logger.error(RoomtypeServiceImpl.class.getName() + ":queryByPms error", e);
			throw e;
		}
	}

	@Override
	public void syncRoomtypeInfo(Long hotelid, List<PmsRoomtypeJsonBean> roomtypes, Map<String, Long> map) {
		RoomtypeServiceImpl.logger.info(RoomtypeServiceImpl.class.getName() + ":syncRoomtypeInfo begin: " + JSONObject.toJSONString(roomtypes));
		try {
			// 找出酒店下所有房型
			List<RoomtypeModel> roomtypelist = this.queryByHotelId(hotelid);
			logger.info("syncRoomtypeinfo: before update hotelid: {}, roomtypes: {} ", hotelid, JSONObject.toJSONString(roomtypelist));
			// 更新的房型pms号
			List<String> updateidlist = new ArrayList<String>();
			for (RoomtypeModel roomtypeModel : roomtypelist) {
				String roomtypepms = roomtypeModel.getRoomtypepms();
				boolean isexits = false;
				for (PmsRoomtypeJsonBean pmsRoomtypeJsonBean : roomtypes) {
					// 如果本地房型id 和 crm传过来的房型id一样，进行更新
					if (pmsRoomtypeJsonBean.getId().equals(roomtypepms)) {
						// update
						roomtypeModel.setId(map.get(pmsRoomtypeJsonBean.getId()));
						roomtypeModel.setCost(new BigDecimal(pmsRoomtypeJsonBean.getPrice()));
						roomtypeModel.setName(pmsRoomtypeJsonBean.getName());
						roomtypeModel.setRoomnum(pmsRoomtypeJsonBean.getRoom().size());
						roomtypeModel.setUpdatetime(new Date());
						this.updateById(roomtypeModel);
						logger.info("酒店:{} 更新房型: {}", hotelid, JSONObject.toJSONString(roomtypeModel));
						this.roomService.syncRoomInfo(roomtypeModel.getId(), pmsRoomtypeJsonBean.getRoom(), map);
						updateidlist.add(pmsRoomtypeJsonBean.getId());
						isexits = true;
						break;
					}
				}
				// 如果没有和crm匹配的房型id，则删除本地这个房型
				if (!isexits) {
					// delete
					this.delRoomtypeById(roomtypeModel.getId());
					logger.info("酒店:{} 删除房型: {}", hotelid, JSONObject.toJSONString(roomtypeModel));
					// delete room
					this.roomService.delRoomByRoomtypeid(roomtypeModel.getId());
				}
			}
			// 循环crm传过来的数据
			for (PmsRoomtypeJsonBean pmsRoomtypeJsonBean : roomtypes) {
				boolean isexits = false;
				for (String pmsno : updateidlist) {
					if (pmsno.equals(pmsRoomtypeJsonBean.getId())) {
						isexits = true;
						break;
					}
				}
				if (!isexits && map.get(pmsRoomtypeJsonBean.getId()) != null) {
					// 没有插入过则进行插入房型
					RoomtypeModel roomtypeModel = new RoomtypeModel();
					roomtypeModel.setRoomtypepms(pmsRoomtypeJsonBean.getId());
					roomtypeModel.setCost(new BigDecimal(pmsRoomtypeJsonBean.getPrice()));
					roomtypeModel.setName(pmsRoomtypeJsonBean.getName());
					roomtypeModel.setRoomnum(pmsRoomtypeJsonBean.getRoom().size());
					roomtypeModel.setHotelid(hotelid);
					roomtypeModel.setUpdatetime(new Date());
					roomtypeModel.setId(Long.parseLong(map.get(pmsRoomtypeJsonBean.getId()).toString()));
					this.addRoomtype(roomtypeModel);
					this.roomService.syncRoomInfo(roomtypeModel.getId(), pmsRoomtypeJsonBean.getRoom(), map);
					logger.info("酒店:{} 添加房型: {}", hotelid, JSONObject.toJSONString(roomtypeModel));
				}
			}
		} catch (Exception e) {
			RoomtypeServiceImpl.logger.error(RoomtypeServiceImpl.class.getName() + ":syncRoomtypeInfo error", e);
			throw e;
		}
	}
	/**
	 * 自助酒店和临时酒店rpc调用
	 * 插入房型和门市价，并发送SyncHotelModel消息
	 */
	@Override
	public void syncRoomtypes(Long hotelid, List<PmsRoomtypeJsonBean> roomtypes) {
		RoomtypeServiceImpl.logger.info("syncRoomtypeInfos crm同步房型::hotelid:{}", hotelid);
		syncRoomtypeInfos(hotelid, roomtypes, null);
		
		HotelModel hotelModel = hotelService.queryById(hotelid);
		standardKafkaProducer.sendSyncHotelModel(JSONObject.toJSONString(hotelModel));
		
		RackRateModelExample example = new RackRateModelExample();
		RackRateModelExample.Criteria criteria = example.createCriteria();
		criteria.andHotelidEqualTo(hotelid);
		rackRateModelMapper.deleteByExample(example);
		
		rackRateModelMapper.genRackRates(Arrays.asList(hotelid));
	}

	@Override
	public void syncRoomtypeInfos(Long hotelid, List<PmsRoomtypeJsonBean> roomtypes, Map<String, Long> map) {
		RoomtypeServiceImpl.logger.info(RoomtypeServiceImpl.class.getName() + ":syncRoomtypeInfos begin: " + JSONObject.toJSONString(roomtypes));
		try {
			// 找出酒店下所有房型
			List<RoomtypeModel> roomtypelist = this.queryByHotelId(hotelid);
			logger.info("syncRoomtypeInfos: before update hotelid: {}, roomtypes: {} ", hotelid, JSONObject.toJSONString(roomtypelist));
			// 更新的房型pms号
			List<String> updateidlist = new ArrayList<String>();
			for (RoomtypeModel roomtypeModel : roomtypelist) {
				String roomtypepms = roomtypeModel.getRoomtypepms();
				boolean isexits = false;
				for (PmsRoomtypeJsonBean pmsRoomtypeJsonBean : roomtypes) {
					// 如果本地房型id 和 crm传过来的房型id一样，进行更新
					if (pmsRoomtypeJsonBean.getId().equals(roomtypepms)) {
						// update
						roomtypeModel.setId(pmsRoomtypeJsonBean.getRoomtypegdsid());
						if (map != null && roomtypeModel.getId() == null && map.containsKey(pmsRoomtypeJsonBean.getId())) {
							roomtypeModel.setId(map.get(pmsRoomtypeJsonBean.getId()));
						}
						roomtypeModel.setCost(new BigDecimal(pmsRoomtypeJsonBean.getPrice()));
						roomtypeModel.setName(pmsRoomtypeJsonBean.getName());
						roomtypeModel.setRoomnum(pmsRoomtypeJsonBean.getRoomnum() == null ? 0 : pmsRoomtypeJsonBean.getRoomnum());
						roomtypeModel.setUpdatetime(new Date());
						this.updateById(roomtypeModel);
						logger.info("syncRoomtypeInfos酒店:{} 更新房型: {}", hotelid, JSONObject.toJSONString(roomtypeModel));
						updateidlist.add(pmsRoomtypeJsonBean.getId());
						isexits = true;
						break;
					}
				}
				// 如果没有和crm匹配的房型id，则删除本地这个房型
				if (!isexits) {
					// delete
					this.delRoomtypeById(roomtypeModel.getId());
					logger.info("syncRoomtypeInfos酒店:{} 删除房型: {}", hotelid, JSONObject.toJSONString(roomtypeModel));
				}
			}
			// 循环crm传过来的数据
			for (PmsRoomtypeJsonBean pmsRoomtypeJsonBean : roomtypes) {
				boolean isexits = false;
				for (String pmsno : updateidlist) {
					if (pmsno.equals(pmsRoomtypeJsonBean.getId())) {
						isexits = true;
						break;
					}
				}
				if (!isexits) {
					// 没有插入过则进行插入房型
					RoomtypeModel roomtypeModel = new RoomtypeModel();
					roomtypeModel.setId(pmsRoomtypeJsonBean.getRoomtypegdsid());
					roomtypeModel.setRoomtypepms(pmsRoomtypeJsonBean.getId());
					if (roomtypeModel.getRoomtypepms() == null) {
						roomtypeModel.setRoomtypepms("" + pmsRoomtypeJsonBean.getRoomtypegdsid());
					}
					roomtypeModel.setCost(new BigDecimal(pmsRoomtypeJsonBean.getPrice()));
					roomtypeModel.setName(pmsRoomtypeJsonBean.getName());
					roomtypeModel.setRoomnum(pmsRoomtypeJsonBean.getRoomnum() == null ? 0 : pmsRoomtypeJsonBean.getRoomnum());
					roomtypeModel.setHotelid(hotelid);
					roomtypeModel.setUpdatetime(new Date());
					if (map != null && roomtypeModel.getId() == null && map.containsKey(pmsRoomtypeJsonBean.getId())) {
						roomtypeModel.setId(map.get(pmsRoomtypeJsonBean.getId()));
					}
					this.addRoomtype(roomtypeModel);
					logger.info("酒店:{} 添加房型: {}", hotelid, JSONObject.toJSONString(roomtypeModel));
				}
			}
		} catch (Exception e) {
			RoomtypeServiceImpl.logger.error(RoomtypeServiceImpl.class.getName() + ":syncRoomtypeInfos error", e);
			throw e;
		}
	}

	private void updateById(RoomtypeModel roomtypeModel) {
		this.roomtypeModelMapper.updateByPrimaryKeySelective(roomtypeModel);
		String str = "{\"hotelid\": " + roomtypeModel.getHotelid() + ", \"roomtypeid\":" + roomtypeModel.getId().toString() + ",\"act\":\"modify\"}";
		standardKafkaProducer.sendRoomtypeChange(str);
	}

	@Override
	public void addRoomtype(RoomtypeModel roomtypeModel) {
		this.roomtypeModelMapper.insertSelective(roomtypeModel);
		String str = "{\"hotelid\": " + roomtypeModel.getHotelid() + ", \"roomtypeid\":" + roomtypeModel.getId().toString() + ",\"act\":\"add\"}";
		standardKafkaProducer.sendRoomtypeChange(str);
		logger.info("addRoomtype::ok");
	}
	
	private void delRoomtypeById(Long roomtypeid) {
		logger.info("delRoomtypeById::{}", roomtypeid);
		RoomtypeModel roomtypeModel = roomtypeModelMapper.selectByPrimaryKey(roomtypeid);
		
		this.roomtypeModelMapper.deleteByPrimaryKey(roomtypeid);
		
		RoomtypeinfoModelExample example = new RoomtypeinfoModelExample();
		Criteria cri = example.createCriteria();
		cri.andRoomtypeidEqualTo(roomtypeid);
		this.roomtypeinfoModelMapper.deleteByExample(example);
		
		String str = "{\"hotelid\": " + roomtypeModel.getHotelid() + ", \"roomtypeid\":" + roomtypeModel.getId().toString() + ",\"act\":\"delete\"}";
		standardKafkaProducer.sendRoomtypeChange(str);
		logger.info("delRoomtypeById::ok");
	}

	public void setRoomtypeModelMapper(RoomtypeModelMapper roomtypeModelMapper) {
		this.roomtypeModelMapper = roomtypeModelMapper;
	}

	@Override
	public boolean syncRoomtypeForHMS(List<RoomtypeJsonBean> roomtypeModels) {
		if (CollectionUtils.isNotEmpty(roomtypeModels)) {
			for (RoomtypeJsonBean roomtypeJsonBean : roomtypeModels) {
				if (null != roomtypeJsonBean.getRoomtypeModel()) {
					RoomtypeModel roomtypeModel2 = this.queryById(roomtypeJsonBean.getRoomtypeModel().getId());
					if (null != roomtypeModel2) {
						this.delRoomtypeById(roomtypeJsonBean.getRoomtypeModel().getId());
						try {
							throw new Exception();
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						this.addRoomtype(roomtypeJsonBean.getRoomtypeModel());
						if (CollectionUtils.isNotEmpty(roomtypeJsonBean.getRoomModels())) {
							this.roomService.syncRoomForHMS(roomtypeJsonBean.getRoomModels());
						} else {
							RoomtypeServiceImpl.logger.info("roomtype id:{} with 0 room.", roomtypeJsonBean.getRoomtypeModel().getId());
						}
					} else {
						RoomtypeServiceImpl.logger.info("cann't find roomtype data with id:{}", roomtypeJsonBean.getRoomtypeModel().getId());
					}
				} else {
					RoomtypeServiceImpl.logger.info("syncRoomtypeForHMS roomtype is null.");
				}
			}
		} else {
			RoomtypeServiceImpl.logger.info("syncRoomtypeForHMS received nothing.");
		}
		return false;
	}

	@Override
	public void updateRoomTypeByRoomTypePms(RoomtypeModel roomtypeModel) {
		logger.info("CRM修改房型，参数：{}", gson.toJson(roomtypeModel));
		int result = this.roomtypeModelMapper.updateByPmsId(roomtypeModel);
		logger.info("CRM修改房型，影响行数：{}，pms房型ID:{}", result, roomtypeModel.getRoomtypepms());
	}

	@Override
	public List<RoomtypeModel> queryByRoomtypePmsAndHotelId(Long hotelid, String pmsString) {
		logger.info("查询房型，参数,hotelid:{},pmsString:{}", hotelid, pmsString);
		List<RoomtypeModel> list = this.roomtypeModelMapper.selectByPms(hotelid, pmsString);
		logger.info("查询房型,结果：{}", gson.toJson(list));
		return list;
	}

	@Override
	public RoomtypeModel queryByPmsOnly(Long hotelId, String pmsNo) {
		this.logger.info("hotel:{},房型：{}", hotelId, pmsNo);
		List<RoomtypeModel> roomtypeModelList = roomtypeModelMapper.selectByPms(hotelId, pmsNo);

		if (roomtypeModelList == null || roomtypeModelList.size() == 0) {
			logger.error("没 找到房型：{}", pmsNo);
			throw new MyException(MyErrorEnum.dateError);
		}
		if (roomtypeModelList.size() > 1) {
			logger.error("发现多个房型，pmsid:{}", pmsNo);
			throw new MyException(MyErrorEnum.dateError);
		}
		return roomtypeModelList.get(0);
	}
	
	@Override
	public void syncPushCrmSyncAddRoomType(String json){
		PmsHotelJsonBean pmsHotelJsonBean = JSON.parseObject(json, PmsHotelJsonBean.class);
		Long hotelid = pmsHotelJsonBean.getHotelgdsid();
		List<PmsRoomtypeJsonBean> roomtypes = pmsHotelJsonBean.getRoomtype();
		Map<String, Object> map = pmsHotelJsonBean.getIdsmap();
		try {
			// 找出酒店下所有房型
			List<RoomtypeModel> roomtypelist = this.queryByHotelId(hotelid);
			logger.info("syncRoomtypeInfo2: before update hotelid: {}, roomtypes: {} ", hotelid, JSONObject.toJSONString(roomtypelist));
			// 更新的房型pms号
			List<String> updateidlist = new ArrayList<String>();
			for (RoomtypeModel roomtypeModel : roomtypelist) {
				String roomtypepms = roomtypeModel.getRoomtypepms();
				boolean isexits = false;
				for (PmsRoomtypeJsonBean pmsRoomtypeJsonBean : roomtypes) {
					// 如果本地房型id 和 crm传过来的房型id一样，进行更新
					if (pmsRoomtypeJsonBean.getId().equals(roomtypepms)) {
						// update
						String id = map.get(pmsRoomtypeJsonBean.getId()).toString();
						roomtypeModel.setId(Long.parseLong(id));
						//roomtypeModel.setCost(new BigDecimal(pmsRoomtypeJsonBean.getPrice()));
						roomtypeModel.setName(pmsRoomtypeJsonBean.getName());
						roomtypeModel.setRoomnum(pmsRoomtypeJsonBean.getRoomnum() == null ? 0 : pmsRoomtypeJsonBean.getRoomnum());
						roomtypeModel.setUpdatetime(new Date());
						this.updateById(roomtypeModel);

						logger.info("syncRoomtypeInfo2酒店:{} 更新房型: {}", hotelid, JSONObject.toJSONString(roomtypeModel));
						updateidlist.add(pmsRoomtypeJsonBean.getId());
						isexits = true;
						break;
					}
				}
			}
			// 循环crm传过来的数据
			for (PmsRoomtypeJsonBean pmsRoomtypeJsonBean : roomtypes) {
				boolean isexits = false;
				for (String pmsno : updateidlist) {
					if (pmsno.equals(pmsRoomtypeJsonBean.getId())) {
						isexits = true;
						break;
					}
				}
				if (!isexits && map.get(pmsRoomtypeJsonBean.getId()) != null) {
					// 没有插入过则进行插入房型
					RoomtypeModel roomtypeModel = new RoomtypeModel();
					roomtypeModel.setRoomtypepms(pmsRoomtypeJsonBean.getId());
					// roomtypeModel.setCost(new BigDecimal(pmsRoomtypeJsonBean.getPrice()));
					roomtypeModel.setName(pmsRoomtypeJsonBean.getName());
					roomtypeModel.setRoomnum(pmsRoomtypeJsonBean.getRoomnum() == null ? 0 : pmsRoomtypeJsonBean.getRoomnum());
					roomtypeModel.setHotelid(hotelid);
					roomtypeModel.setUpdatetime(new Date());
					String id = map.get(pmsRoomtypeJsonBean.getId()).toString();
					roomtypeModel.setId(Long.parseLong(id));
					this.addRoomtype(roomtypeModel);

					logger.info("酒店:{} 添加房型: {}", hotelid, JSONObject.toJSONString(roomtypeModel));
				}
			}
		} catch (Exception e) {
			RoomtypeServiceImpl.logger.error(RoomtypeServiceImpl.class.getName() + ":syncRoomtypeInfo2 error", e);
			throw e;
		}
		HotelModel hotelModel = hotelService.queryById(hotelid);
		standardKafkaProducer.sendSyncHotelModel(JSONObject.toJSONString(hotelModel));
	}
	
	@Override
	public void syncPushCrmSyncDelRoomType(String json){
		logger.info("syncPushCrmSyncDelRoomType: {}", json);
		PmsHotelJsonBean pmsHotelJsonBean = JSON.parseObject(json, PmsHotelJsonBean.class);
		List<PmsRoomtypeJsonBean> roomtypes = pmsHotelJsonBean.getRoomtype();
		Map<String, Object> map = pmsHotelJsonBean.getIdsmap();
		logger.info("syncPushCrmSyncDelRoomType:map{}", map);
		if (roomtypes != null && roomtypes.size() > 0) {
			for (PmsRoomtypeJsonBean pmsRoomtypeJsonBean : roomtypes) {
				if (map.containsKey(pmsRoomtypeJsonBean.getId())) {
					String id = map.get(pmsRoomtypeJsonBean.getId()).toString();
					Long roomtypeid = Long.parseLong(id);
					logger.info("delRoomtypeById:{}", roomtypeid);
					delRoomtypeById(roomtypeid);
				}
			}
		}
		HotelModel hotelModel = hotelService.queryById(pmsHotelJsonBean.getHotelgdsid());
		if (hotelModel != null) {
			logger.info("delRoomtypeById:hotelModel:{}", hotelModel);
			standardKafkaProducer.sendSyncHotelModel(JSONObject.toJSONString(hotelModel));
		} else {
			logger.info("delRoomtypeById:没找到hotelmodel:{}", pmsHotelJsonBean.getHotelgdsid());
		}
		logger.info("delRoomtypeById:ok");
	}

	@Override
	public List<RoomtypeModel> queryByIds(List<Long> roomtypeids) {
		return roomtypeModelMapper.queryByIds(roomtypeids);
	}
}
