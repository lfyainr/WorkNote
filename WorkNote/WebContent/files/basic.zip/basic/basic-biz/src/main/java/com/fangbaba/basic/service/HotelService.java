package com.fangbaba.basic.service;

import java.util.List;

import com.fangbaba.basic.face.bean.HotelModel;
import com.fangbaba.basic.po.ESHotelExample;


public interface HotelService extends com.fangbaba.basic.face.service.HotelService {
	/**
	 * 同步酒店信息
	 *
	 * @param json
	 */
	public void syncHotelInfo(String json);

	/**
	 * 初始化ES 酒店基础信息 index = basic type = hotel
	 */
	public void initESHotelInfo();

	/**
	 * 更新酒店上下线状态
	 * 
	 * @param json
	 */
	void updateHotelOnlineState(String json);

	/**
	 * 根据pmsid查询唯一酒店
	 * 
	 * @param hotelPms
	 * @return
	 */
	public HotelModel queryHotelByPmsOnly(String hotelPms);
	
	/**
	 * 
	 * @param hotels
	 * @return
	 */
	public List<ESHotelExample> initESHotelPOJO(List<HotelModel> hotels);
	
	/**
	 * 
	 * @param hotelpms
	 * @param state
	 */
	public void updateHotelState(String hotelpms, Integer state);

	public void syncPushCrmSyncHotelOfSwitchMsg(String json);
	
	/**
	 * 酒店上下线
	 * @param json
	 */
	public void syncStatusOnline(String json);
}
