package com.fangbaba.basic.mappers;

import com.fangbaba.basic.face.bean.Hoteltags;
import com.fangbaba.basic.face.bean.HoteltagsExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface HoteltagsMapper {
    int countByExample(HoteltagsExample example);

    int deleteByExample(HoteltagsExample example);

    int deleteByPrimaryKey(Long id);

    int insert(Hoteltags record);

    int insertSelective(Hoteltags record);

    List<Hoteltags> selectByExample(HoteltagsExample example);

    Hoteltags selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") Hoteltags record, @Param("example") HoteltagsExample example);

    int updateByExample(@Param("record") Hoteltags record, @Param("example") HoteltagsExample example);

    int updateByPrimaryKeySelective(Hoteltags record);

    int updateByPrimaryKey(Hoteltags record);
    
    void deleteHotelTags(@Param("hotelid") Long hotelid);
}