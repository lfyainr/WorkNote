package com.fangbaba.basic.service.impl;

import java.util.List;

import com.fangbaba.basic.face.base.RetInfo;
import com.fangbaba.basic.po.HotelExtensionExample;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fangbaba.basic.face.bean.ProvinceModel;
import com.fangbaba.basic.face.service.ProvinceService;
import com.fangbaba.basic.mappers.ProvinceModelMapper;
import com.fangbaba.basic.po.ProvinceModelExample;

/**
 * @author he
 * 省相关接口
 */
@Service
public class ProvinceServiceImpl implements ProvinceService {
	
	private static Logger logger = LoggerFactory.getLogger(ProvinceServiceImpl.class);
	
	@Autowired
	private ProvinceModelMapper provinceModelMapper;

	@Override
	public List<ProvinceModel> queryAllProvinces() {
		logger.info(ProvinceServiceImpl.class.getName()+":queryAllProvinces begin");
		try {
			ProvinceModelExample example = new ProvinceModelExample();
			example.setOrderByClause("sort asc");
			return provinceModelMapper.selectByExample(example);
		} catch (Exception e) {
			logger.error(ProvinceServiceImpl.class.getName()+":queryAllProvinces error",e);
			throw e;
		}
	}

	@Override
	public RetInfo<ProvinceModel> queryByCode(String provCode) {
		RetInfo<ProvinceModel> retInfo = new RetInfo<ProvinceModel>();
		if(StringUtils.isBlank(provCode)){
			logger.info("所传参数 provCode 为空");
			retInfo.setResult(false);
			retInfo.setMsg("所传参数provCode为空");
			return retInfo;
		}
		ProvinceModelExample example = new ProvinceModelExample();
		ProvinceModelExample.Criteria hoCriteria = example.createCriteria();
		hoCriteria.andCodeEqualTo(provCode);
		List<ProvinceModel> models =  provinceModelMapper.selectByExample( example);
		if( models != null && models.size() > 0){
			retInfo.setObj(models.get(0));
			retInfo.setResult(true);
		}else {
			retInfo.setResult(false);
			retInfo.setMsg("未找到"+ provCode + " 省市");
		}
		return retInfo;
	}

}
