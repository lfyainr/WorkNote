package com.fangbaba.basic.mappers;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.fangbaba.basic.face.bean.RoomtypeModel;
import com.fangbaba.basic.po.RoomtypeModelExample;

public interface RoomtypeModelMapper {
	int countByExample(RoomtypeModelExample example);

	int deleteByExample(RoomtypeModelExample example);

	int deleteByPrimaryKey(Long id);

	int insert(RoomtypeModel record);

	int insertSelective(RoomtypeModel record);

	List<RoomtypeModel> selectByExample(RoomtypeModelExample example);

	RoomtypeModel selectByPrimaryKey(Long id);

	int updateByExampleSelective(@Param("record") RoomtypeModel record, @Param("example") RoomtypeModelExample example);

	int updateByExample(@Param("record") RoomtypeModel record, @Param("example") RoomtypeModelExample example);

	int updateByPrimaryKeySelective(RoomtypeModel record);

	int updateByPrimaryKey(RoomtypeModel record);

	/**
	 * 根据pmsId修改房型
	 * 
	 * @param record
	 * @return
	 */
	int updateByPmsId(RoomtypeModel record);

	/**
	 * 根据酒店和房型pmsID查房型
	 * 
	 * @param hotelid
	 * @param pmsString
	 * @return
	 */
	List<RoomtypeModel> selectByPms(@Param("hotelid") Long hotelid, @Param("pmsString") String pmsString);
	
	public List<RoomtypeModel> queryByIds(@Param("roomtypeids") List<Long> roomtypeids);
}