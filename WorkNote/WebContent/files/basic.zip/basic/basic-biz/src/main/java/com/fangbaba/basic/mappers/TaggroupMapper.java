package com.fangbaba.basic.mappers;

import com.fangbaba.basic.face.bean.Taggroup;
import com.fangbaba.basic.face.bean.TaggroupExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TaggroupMapper {
    int countByExample(TaggroupExample example);

    int deleteByExample(TaggroupExample example);

    int deleteByPrimaryKey(Long id);

    int insert(Taggroup record);

    int insertSelective(Taggroup record);

    List<Taggroup> selectByExample(TaggroupExample example);

    Taggroup selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") Taggroup record, @Param("example") TaggroupExample example);

    int updateByExample(@Param("record") Taggroup record, @Param("example") TaggroupExample example);

    int updateByPrimaryKeySelective(Taggroup record);

    int updateByPrimaryKey(Taggroup record);
}