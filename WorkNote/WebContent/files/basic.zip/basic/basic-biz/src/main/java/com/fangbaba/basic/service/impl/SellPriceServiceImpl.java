package com.fangbaba.basic.service.impl;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.bean.DailyDistributePrice;
import com.fangbaba.basic.face.bean.DailyDistributePriceExample;
import com.fangbaba.basic.face.bean.DailyRateModel;
import com.fangbaba.basic.face.bean.RackDistributePrice;
import com.fangbaba.basic.face.bean.RackDistributePriceExample;
import com.fangbaba.basic.face.bean.RackRateModel;
import com.fangbaba.basic.face.bean.RoomtypeModel;
import com.fangbaba.basic.face.bean.WeekendRateModel;
import com.fangbaba.basic.face.bean.jsonbean.DailyRateInfoDataJsonBean;
import com.fangbaba.basic.face.bean.jsonbean.DailyRateInfoJsonBean;
import com.fangbaba.basic.face.bean.jsonbean.DailyRateJsonBean;
import com.fangbaba.basic.face.bean.jsonbean.RackRateInfoJsonBean;
import com.fangbaba.basic.face.bean.jsonbean.RackRateJsonBean;
import com.fangbaba.basic.face.bean.jsonbean.WeekendRateInfoDataJsonBean;
import com.fangbaba.basic.face.bean.jsonbean.WeekendRateInfoJsonBean;
import com.fangbaba.basic.face.bean.jsonbean.WeekendRateJsonBean;
import com.fangbaba.basic.face.enums.MyErrorEnum;
import com.fangbaba.basic.mappers.DailyDistributePriceMapper;
import com.fangbaba.basic.mappers.DailyRateModelMapper;
import com.fangbaba.basic.mappers.RackDistributePriceMapper;
import com.fangbaba.basic.mappers.RackRateModelMapper;
import com.fangbaba.basic.mappers.RoomtypeModelMapper;
import com.fangbaba.basic.mappers.WeekendRateModelMapper;
import com.fangbaba.basic.po.DailyRateModelExample;
import com.fangbaba.basic.po.RackRateModelExample;
import com.fangbaba.basic.po.RackRateModelExample.Criteria;
import com.fangbaba.basic.po.WeekendRateModelExample;
import com.fangbaba.basic.service.RoomtypeService;
import com.fangbaba.basic.service.SellPriceService;
import com.fangbaba.basic.util.DateUtil;
import com.fangbaba.order.common.utils.DateUtils;
import com.google.gson.Gson;

/**
 * @author he
 * 价格service
 */
@Service
public class SellPriceServiceImpl implements SellPriceService{
	
	private static final Logger log = LoggerFactory.getLogger(SellPriceServiceImpl.class);
	@Autowired
	private RackRateModelMapper rackRateMapper;
	@Autowired
	private WeekendRateModelMapper weekendRateModelMapper;
	@Autowired
	private DailyRateModelMapper dailyRateMapper;
	@Autowired
	private DailyDistributePriceMapper dailyDistributePriceMapper;
	@Autowired
	private RackDistributePriceMapper rackDistributePriceMapper;
	@Autowired
	private RoomtypeService roomtypeService;
	@Autowired
	private RoomtypeModelMapper roomtypeModelMapper;
	
	private RackRateModelExample rackRateModelExample;
	private DailyRateModelExample dailyRateModelExample;
	private WeekendRateModelExample weekendRateModelExample;

	@Override
	public RackRateModel findRackRateByConditions(Long hotelid, Long roomtypeid) {
		RackRateModelExample rackRateModelExample = new RackRateModelExample();
		rackRateModelExample.createCriteria().andHotelidEqualTo(hotelid)
				.andRoomtypeidEqualTo(roomtypeid);
		List<RackRateModel> list = rackRateMapper
				.selectByExample(rackRateModelExample);
		if (list != null && list.size() > 0) {
			return list.get(0);
		} else {
			return null;
		}
	}
	public List<RackRateModel> findRackRatesByHotelid(Long hotelid){
		RackRateModelExample rackRateModelExample = new RackRateModelExample();
		rackRateModelExample.createCriteria().andHotelidEqualTo(hotelid);
		return rackRateMapper.selectByExample(rackRateModelExample);
	}
	public List<RackDistributePrice> findRackRatesByHotelidNew(Long hotelid){
		RackDistributePriceExample rackRateModelExample = new RackDistributePriceExample();
		rackRateModelExample.createCriteria().andHotelidEqualTo(hotelid);
		return rackDistributePriceMapper.selectByExample(rackRateModelExample);
	}

	@Override
	public int saveRackRate(RackRateModel rackRateModel) {
		return rackRateMapper.insertSelective(rackRateModel);
	}

	@Override
	public int updateRackRate(RackRateModel rackRateModel) {
		return rackRateMapper.updateByPrimaryKeySelective(rackRateModel);
	}

	@Override
	public List<DailyRateModel> findDailyRatesByHotelid(Long hotelid,Long roomtypeid) {
		DailyRateModelExample dailyRateModelExample = new DailyRateModelExample();
		dailyRateModelExample.createCriteria().andHotelidEqualTo(hotelid).andRoomtypeidEqualTo(roomtypeid);
		List<DailyRateModel> list = dailyRateMapper
				.selectByExample(dailyRateModelExample);
		return list;
	}

	@Override
	public Integer saveBatchDailyRate(List<DailyRateModel> insertBatchList) {
		int i=0;
		for (DailyRateModel dailyRateModel:insertBatchList) {
			i+=dailyRateMapper.insertSelective(dailyRateModel);
		}
		return i;
	}

	@Override
	public Integer updateBatchDailyRate(List<DailyRateModel> updateBatchList) {
		int i=0;
		for (DailyRateModel dailyRateModel:updateBatchList) {
			i+=dailyRateMapper.updateByPrimaryKeySelective(dailyRateModel);
		}
		return i;
	}

	@Override
	public boolean syncDailyRate(DailyRateJsonBean dailyRateJsonBean, Long hotelid) {
		boolean ischange = false;
		
		List<Long> roomtypelist = new ArrayList<Long>();
		for (DailyRateInfoJsonBean info : dailyRateJsonBean.getRoomtype()) {
			//删除非传入房型数据
			String roomtypepms = info.getId();
			if (StringUtils.isEmpty(roomtypepms)) {
				throw MyErrorEnum.errorParm.getMyException("参数错误!roomtype中id为空");
			}
			List<DailyRateInfoDataJsonBean> data = info.getData();

			// roomtype 根据pms查询
			RoomtypeModel roomType = roomtypeService.queryByPmsAndHotelid(roomtypepms, hotelid);
			if (roomType == null) {
				log.error("未找到hotelid为"+ hotelid + ",pms为 " + roomtypepms + " 的房型信息");
				continue;
			}
			Long roomtypeid = roomType.getId();
			roomtypelist.add(roomtypeid);
			List<DailyRateModel> dailyrates = this.findDailyRatesByHotelid(hotelid,roomtypeid);
			if (data.size() == 0) {
				//清空数据
				for (DailyRateModel dailyRateModel : dailyrates) {
					//清空此房型数据
					dailyRateMapper.deleteByPrimaryKey(dailyRateModel.getId());
					ischange = true;
				}
				continue;
				//throw MyErrorEnum.errorParm.getMyException("参数错误!roomtype中data为空");
			}
			// 循环已有数据集
			Map<String, DailyRateModel> existsMap = new HashMap<String, DailyRateModel>();
			for (DailyRateModel dailyRateModel : dailyrates) {
				existsMap.put(dailyRateModel.getDay() + "", dailyRateModel);
			}
			
			// 循环传入数据并找出需要插入的记录
			Map<String, DailyRateInfoDataJsonBean> dataMap = new HashMap<String, DailyRateInfoDataJsonBean>();
			for (DailyRateInfoDataJsonBean dailyRateInfoDataJsonBean : data) {
				String day = dailyRateInfoDataJsonBean.getDay();
				if (existsMap.containsKey(day)) {
					dataMap.put(day, dailyRateInfoDataJsonBean);
				} else {
					DailyRateModel dailyRateModel = new DailyRateModel();
					dailyRateModel.setHotelid(hotelid);
					dailyRateModel.setRoomtypeid(roomtypeid);
					dailyRateModel.setDay(Long.parseLong(day));
					dailyRateModel.setPrice(new BigDecimal(dailyRateInfoDataJsonBean.getPrice()));
					dailyRateModel.setCreatetime(DateUtil.getNowDate());
					dailyRateModel.setCreateuser("pms");
					dailyRateModel.setUpdatetime(DateUtil.getNowDate());
					dailyRateModel.setUpdateuser("pms");
					dailyRateMapper.insertSelective(dailyRateModel);
					ischange = true;
				}
			}
			// 循环数据库结果集
			for (DailyRateModel dailyRateModel : dailyrates) {
				String day = dailyRateModel.getDay() + "";
				if (dataMap.containsKey(day)) {
					DailyRateInfoDataJsonBean dailyRateInfoDataJsonBean = dataMap
							.get(day);
					BigDecimal newprice = new BigDecimal(
							dailyRateInfoDataJsonBean.getPrice());
					BigDecimal oldprice = dailyRateModel.getPrice();
					BigDecimal a = oldprice.setScale(2,
							BigDecimal.ROUND_HALF_DOWN);
					BigDecimal b = newprice.setScale(2,
							BigDecimal.ROUND_HALF_DOWN);
					if (!a.equals(b)) {
						// 更新
						dailyRateModel.setUpdatetime(DateUtil.getNowDate());
						dailyRateModel.setUpdateuser("PMS");
						dailyRateModel.setPrice(newprice);
						dailyRateMapper.updateByPrimaryKeySelective(dailyRateModel);
						ischange = true;
					}
				} else {
					// 删除
					dailyRateMapper.deleteByPrimaryKey(dailyRateModel.getId());
					ischange = true;
				}
			}
		}
		//删除非传入房型数据
		if(CollectionUtils.isNotEmpty(roomtypelist)){
			DailyRateModelExample example = new DailyRateModelExample();
			DailyRateModelExample.Criteria criteria = example.createCriteria();
			criteria.andHotelidEqualTo(hotelid).andRoomtypeidNotIn(roomtypelist);
			int i = dailyRateMapper.deleteByExample(example);
			if(i>0){
				ischange = true;
			}
		}
		return ischange;
	}
	
	
	@Override
	public boolean syncWeekendRate(WeekendRateJsonBean weekendRateJsonBean, Long hotelid) {
		boolean ischange = false;
		List<Long> roomtypelist = new ArrayList<Long>();
		for (WeekendRateInfoJsonBean info : weekendRateJsonBean.getRoomtype()) {
			String roomtypepms = info.getId();
			if (StringUtils.isEmpty(roomtypepms)) {
				throw MyErrorEnum.errorParm
						.getMyException("参数错误!roomtype中id为空");
			}
			List<WeekendRateInfoDataJsonBean> data = info.getData();
			// roomtype 根据pms查询
			RoomtypeModel roomType = roomtypeService.queryByPmsAndHotelid(roomtypepms, hotelid);
			if (roomType == null) {
				log.error("未找到hotelid为"+ hotelid + ",pms为 " + roomtypepms + " 的房型信息");
				continue;
			}
			Long roomtypeid = roomType.getId();
			roomtypelist.add(roomtypeid);
			// 判断weekend_rate表中是否存在记录
			List<WeekendRateModel> weekendrates = findWeekendRatesByConditions(
					hotelid, roomtypeid,null);
			if (data.size() == 0) {
				for (WeekendRateModel weekendRateModel : weekendrates) {
					//清空此房型数据
					weekendRateModelMapper.deleteByPrimaryKey(weekendRateModel.getId());
					ischange = true;
				}
				continue;
				//throw MyErrorEnum.errorParm.getMyException("参数错误!data为空");
			}

			// 循环已有数据集
			Map<String, WeekendRateModel> existsMap = new HashMap<String, WeekendRateModel>();
			for (WeekendRateModel weekendRate : weekendrates) {
				existsMap.put(weekendRate.getWeek() + "", weekendRate);
			}

			// 循环传入数据并找出需要插入的记录
			Map<String, WeekendRateInfoDataJsonBean> dataMap = new HashMap<String, WeekendRateInfoDataJsonBean>();
			for (WeekendRateInfoDataJsonBean weekendRateInfoDataJsonBean : data) {
				String week = weekendRateInfoDataJsonBean.getWeek();
				if (existsMap.containsKey(week)) {
					dataMap.put(week, weekendRateInfoDataJsonBean);
				} else {
					WeekendRateModel weekendRateModel = new WeekendRateModel();
					weekendRateModel.setCreatetime(DateUtil.getNowDate());
					weekendRateModel.setCreateuser("PMS");
					weekendRateModel.setUpdatetime(DateUtil.getNowDate());
					weekendRateModel.setUpdateuser("PMS");
					weekendRateModel.setHotelid(hotelid);
					weekendRateModel.setWeek(Integer
							.parseInt(weekendRateInfoDataJsonBean.getWeek()));
					weekendRateModel.setPrice(new BigDecimal(
							weekendRateInfoDataJsonBean.getPrice()));
					weekendRateModel.setRoomtypeid(roomtypeid);
					saveWeekendRate(weekendRateModel);
					ischange = true;
				}

			}

			// 循环数据库结果集
			for (WeekendRateModel weekendRateModel : weekendrates) {
				String week = weekendRateModel.getWeek() + "";
				if (dataMap.containsKey(week)) {
					WeekendRateInfoDataJsonBean weekendRateInfoDataJsonBean = dataMap
							.get(week);
					BigDecimal newprice = new BigDecimal(
							weekendRateInfoDataJsonBean.getPrice());
					BigDecimal oldprice = weekendRateModel.getPrice();
					BigDecimal a = oldprice.setScale(2,
							BigDecimal.ROUND_HALF_DOWN);
					BigDecimal b = newprice.setScale(2,
							BigDecimal.ROUND_HALF_DOWN);
					if (!a.equals(b)) {
						// 更新
						weekendRateModel.setUpdatetime(DateUtil.getNowDate());
						weekendRateModel.setUpdateuser("PMS");
						weekendRateModel.setPrice(newprice);
						updateEWeekendRate(weekendRateModel);
						ischange = true;
					}
				} else {
					// 删除
					weekendRateModelMapper.deleteByPrimaryKey(weekendRateModel.getId());
					ischange = true;
				}
			}
		}
		//删除非传入房型数据
		if(CollectionUtils.isNotEmpty(roomtypelist)){
			WeekendRateModelExample example = new WeekendRateModelExample();
			WeekendRateModelExample.Criteria criteria = example.createCriteria();
			criteria.andHotelidEqualTo(hotelid).andRoomtypeidNotIn(roomtypelist);
			int i = weekendRateModelMapper.deleteByExample(example);
			if(i>0){
				ischange = true;
			}
		}
		return ischange;
	}

	@Override
	public boolean syncRackRate(RackRateJsonBean rackRateJsonBean, Long hotelid) {
		boolean ischange = false;
		List<Long> roomtypelist = new ArrayList<Long>();
		for (RackRateInfoJsonBean info : rackRateJsonBean.getRoomtype()) {
			String roomtypepms = info.getId();
			if (StringUtils.isEmpty(roomtypepms)) {
				throw MyErrorEnum.errorParm
						.getMyException("参数错误!roomtype中id为空");
			}
			String price = info.getPrice();
			if (StringUtils.isEmpty(price)) {
				throw MyErrorEnum.errorParm
						.getMyException("参数错误!roomtype中price为空");
			}
			BigDecimal newprice = new BigDecimal(price);
			// roomtype 根据pms查询
			RoomtypeModel roomType = roomtypeService.queryByPmsAndHotelid(roomtypepms, hotelid);
			if (roomType == null) {
				log.error("未找到hotelid为"+ hotelid + ",pms为 " + roomtypepms + " 的房型信息");
				continue;
			}
			Long roomtypeid = roomType.getId();
			roomType.setCost(newprice);
			roomtypeModelMapper.updateByPrimaryKeySelective(roomType);
			roomtypelist.add(roomtypeid);
			// 判断rack_rate表中是否存在记录
			RackRateModel erackrate = findRackRateByConditions(hotelid,
					roomtypeid);
			if (erackrate == null) {
				// 添加
				erackrate = new RackRateModel();
				erackrate.setCreatetime(DateUtil.getNowDate());
				erackrate.setCreateuser("PMS");
				erackrate.setUpdatetime(DateUtil.getNowDate());
				erackrate.setUpdateuser("PMS");
				erackrate.setHotelid(hotelid);
				erackrate.setPrice(newprice);
				erackrate.setRoomtypeid(roomtypeid);
				saveRackRate(erackrate);
				ischange = true;
			} else {
				// 更新
				// 判断价格是否更改
				BigDecimal oldprice = erackrate.getPrice();

				BigDecimal a = oldprice.setScale(2, BigDecimal.ROUND_HALF_DOWN);
				BigDecimal b = newprice.setScale(2, BigDecimal.ROUND_HALF_DOWN);
				if (!a.equals(b)) {
					erackrate.setUpdatetime(DateUtil.getNowDate());
					erackrate.setUpdateuser("PMS");
					erackrate.setPrice(newprice);
					updateRackRate(erackrate);
					ischange = true;
				}
			}
		}
		//删除非传入房型数据
		if(CollectionUtils.isNotEmpty(roomtypelist)){
			RackRateModelExample example = new RackRateModelExample();
			RackRateModelExample.Criteria criteria = example.createCriteria();
			criteria.andHotelidEqualTo(hotelid).andRoomtypeidNotIn(roomtypelist);
			int i = rackRateMapper.deleteByExample(example);
			if(i>0){
				ischange = true;
			}
		}
		return ischange;
	}

	@Override
	public List<WeekendRateModel> findWeekendRatesByConditions(Long hotelid, Long roomtypeid,Integer week) {
		WeekendRateModelExample weekendRateExample = new WeekendRateModelExample();
		WeekendRateModelExample.Criteria criteria = weekendRateExample.createCriteria();
		if(hotelid!=null){
			criteria.andHotelidEqualTo(hotelid);
		}
		if(roomtypeid!=null){
			criteria.andRoomtypeidEqualTo(roomtypeid);
		}
		if(week!=null){
			criteria.andWeekEqualTo(week);
		}
		return weekendRateModelMapper.selectByExample(weekendRateExample);
	}

	@Override
	public int saveWeekendRate(WeekendRateModel weekendRateModel) {
		return weekendRateModelMapper.insertSelective(weekendRateModel);
	}

	@Override
	public int updateEWeekendRate(WeekendRateModel weekendRateModel) {
		return weekendRateModelMapper.updateByPrimaryKeySelective(weekendRateModel);
	}

	
	public List<DailyRateModel> findDailyRatesByConditions(Long hotelid,Long roomtypeid,String date,List<Long> days) {
		DailyRateModelExample dailyRateModelExample = new DailyRateModelExample();
		DailyRateModelExample.Criteria criteria = dailyRateModelExample.createCriteria();
		if(hotelid!=null){
			criteria.andHotelidEqualTo(hotelid);
		}
		if(roomtypeid!=null){
			criteria.andRoomtypeidEqualTo(roomtypeid);
		}
		if(date!=null){
			criteria.andDayEqualTo(Long.parseLong(date));
		}
		if(CollectionUtils.isNotEmpty(days)){
			criteria.andDayIn(days);
		}
		List<DailyRateModel> list = dailyRateMapper
				.selectByExample(dailyRateModelExample);
		return list;
	}
	
	
	public List<DailyDistributePrice> findDailyRatesByConditionsNew(Long hotelid,Long roomtypeid,String date,List<Long> days) {
		DailyDistributePriceExample example = new DailyDistributePriceExample();
		DailyDistributePriceExample.Criteria criteria = example.createCriteria();
		if(hotelid!=null){
			criteria.andHotelidEqualTo(hotelid);
		}
		if(roomtypeid!=null){
			criteria.andRoomtypeidEqualTo(roomtypeid);
		}
		if(date!=null){
			criteria.andDayEqualTo(Long.parseLong(date));
		}
		if(CollectionUtils.isNotEmpty(days)){
			criteria.andDayIn(days);
		}
		List<DailyDistributePrice> list = dailyDistributePriceMapper
				.selectByExample(example);
		
		
		
		return list;
	}

	@Override
	public BigDecimal queryPrice(Long hotelid, Long roomtypeid, String date) throws Exception {
		//先查询特殊价
		List<DailyRateModel> dailyrates = findDailyRatesByConditions(hotelid,roomtypeid,date,null);
		if(CollectionUtils.isNotEmpty(dailyrates)){
			DailyRateModel dailyRateModel = dailyrates.get(0);
			return dailyRateModel.getPrice(); 
		}else{
			//查询周末价
			int week = DateUtil.getWeekTime(date);
			List<WeekendRateModel> weekendrates = findWeekendRatesByConditions(hotelid, roomtypeid, week);
			if(CollectionUtils.isNotEmpty(weekendrates)){
				WeekendRateModel weekendRateModel = weekendrates.get(0);
				return weekendRateModel.getPrice();
			}else{
				//查询门市价
				RackRateModel rackRateModel = findRackRateByConditions(hotelid, roomtypeid);
				if(rackRateModel!=null){
					return rackRateModel.getPrice();
				}else{
					return null;
				}
			}
		}
	}

	@Override
	public Map<String, BigDecimal> queryPriceByDaysOld(Long hotelid, List<Long> days) throws Exception {
		//先查询特殊价
		List<DailyRateModel> dailyrates = findDailyRatesByConditions(hotelid,null,null,days);
		Map<String,BigDecimal> dailyratesmap = new HashMap<String,BigDecimal>();
		for (DailyRateModel dailyRateModel:dailyrates) {
			dailyratesmap.put(dailyRateModel.getRoomtypeid()+"@"+dailyRateModel.getDay().toString(), dailyRateModel.getPrice());
		}
		//查询周末价
		List<WeekendRateModel> weekendrates = findWeekendRatesByConditions(hotelid, null, null);
		Map<String,BigDecimal> weekendratesmap = new HashMap<String,BigDecimal>();
		for (WeekendRateModel weekendRateModel:weekendrates) {
			weekendratesmap.put(weekendRateModel.getRoomtypeid()+"@"+weekendRateModel.getWeek().toString(), weekendRateModel.getPrice());
		}
		//查询平日价
		List<RackDistributePrice> rackrates = findRackRatesByHotelidNew(hotelid);
		Map<String,BigDecimal> rackratesmap = new HashMap<String,BigDecimal>();
		for (RackDistributePrice rackRateModel:rackrates) {
			rackratesmap.put(rackRateModel.getRoomtypeid().toString(), rackRateModel.getPrice());
		}
		//返回结果
		Map<String, BigDecimal> result = new HashMap<String,BigDecimal>();
		List<RoomtypeModel> roomtypes = roomtypeService.queryByHotelId(hotelid);
			//房型列表
		for (RoomtypeModel roomtypeModel:roomtypes) {
			for (Long day:days) {
				//先查询是否有特殊价
				BigDecimal dailiprice = dailyratesmap.get(roomtypeModel.getId()+"@"+day);
				if(dailiprice!=null){
					result.put(roomtypeModel.getId()+"@"+day, dailiprice);
					continue;
				}else{
					//查询是否有周末价
					int week = DateUtil.getWeekTime(day.toString());
					BigDecimal weekendprice = weekendratesmap.get(roomtypeModel.getId()+"@"+week);
					if(weekendprice!=null){
						result.put(roomtypeModel.getId()+"@"+day, weekendprice);
						continue;
					}else{
						//查询平日价
						BigDecimal rackprice = rackratesmap.get(roomtypeModel.getId());
						if(rackprice!=null){
							result.put(roomtypeModel.getId()+"@"+day, rackprice);
							continue;
						}else{
							result.put(roomtypeModel.getId()+"@"+day, roomtypeModel.getCost());
							continue;
						}
					}
				}
			}
		}
		return result;
	}
	
	
	/**
	 * 查询价格，按照酒店设置分销价查询
	 * @param hotelid
	 * @param days
	 * @return
	 * @throws Exception
	 */
	@Override
	public Map<String, BigDecimal> queryPriceByDays(Long hotelid, List<Long> days) throws Exception {
		//先查询特殊价
		List<DailyDistributePrice> dailyrates = findDailyRatesByConditionsNew(hotelid,null,null,days);
		Map<String,BigDecimal> dailyratesmap = new HashMap<String,BigDecimal>();
		for (DailyDistributePrice dailyRateModel:dailyrates) {
			dailyratesmap.put(dailyRateModel.getRoomtypeid()+"@"+dailyRateModel.getDay().toString(), dailyRateModel.getPrice());
		}
		
		log.info("开始查询特殊价格,{}",new Gson().toJson(dailyratesmap));
		//查询周末价 暂时去掉周末价判断
		/**
		 * 
		List<WeekendRateModel> weekendrates = findWeekendRatesByConditions(hotelid, null, null);
		Map<String,BigDecimal> weekendratesmap = new HashMap<String,BigDecimal>();
		for (WeekendRateModel weekendRateModel:weekendrates) {
			weekendratesmap.put(weekendRateModel.getRoomtypeid()+"@"+weekendRateModel.getWeek().toString(), weekendRateModel.getPrice());
		}
		 */
		//查询平日价
		List<RackDistributePrice> rackrates = findRackRatesByHotelidNew(hotelid);
		Map<Long,BigDecimal> rackratesmap = new HashMap<Long,BigDecimal>();
		for (RackDistributePrice rackRateModel:rackrates) {
			rackratesmap.put(rackRateModel.getRoomtypeid(), rackRateModel.getPrice());
		}
		
		log.info("开始查询平日价格,{}",new Gson().toJson(rackratesmap));
		//返回结果
		Map<String, BigDecimal> result = new HashMap<String,BigDecimal>();
		List<RoomtypeModel> roomtypes = roomtypeService.queryByHotelId(hotelid);
			//房型列表
		for (RoomtypeModel roomtypeModel:roomtypes) {
			for (Long day:days) {
				//先查询是否有特殊价
				BigDecimal dailiprice = dailyratesmap.get(roomtypeModel.getId()+"@"+day);
				if(dailiprice!=null){
					result.put(roomtypeModel.getId()+"@"+day, dailiprice);
					continue;
				}else{
					//查询平日价
					BigDecimal rackprice = rackratesmap.get(roomtypeModel.getId());
					if(rackprice!=null){
						result.put(roomtypeModel.getId()+"@"+day, rackprice);
						continue;
					}else{
						//没有价格，不展示
						//result.put(roomtypeModel.getId()+"@"+day, roomtypeModel.getCost());
						continue;
					}
				}
			}
		}
		
		log.info("结束查询价格，结果：{}",new Gson().toJson(result));
		return result;
	}
	@Override
	public BigDecimal querySalePrice(Long hotelid, Long roomtypeid) {
		RackRateModel rackRateModel = findRackRateByConditions(hotelid, roomtypeid);
		if(rackRateModel!=null){
			return rackRateModel.getPrice();
		}else{
			return null;
		}
	}
	
	@Override
	public Map<String, BigDecimal> findRackRateByConditions(Long hotelid, List<Long> roomtypeids, Date begintime, Date endtime) throws Exception {
		log.info("findRackRateByConditions:hotelid:{},roomtypeids:{},begintime:{},endtime:{}", hotelid, roomtypeids, begintime, endtime);
		Date begintime_ = (Date) begintime.clone();
		// 特殊价
		int begin = Integer.parseInt(DateUtils.getStringFromDate(begintime, "yyyyMMdd"));
		int end = Integer.parseInt(DateUtils.getStringFromDate(endtime, "yyyyMMdd"));
		List<DailyRateModel> dailyRates = dailyRateMapper.findDailyRates(hotelid, roomtypeids, begin, end);

		// 周末价
		List<Integer> weeks = new ArrayList<>();
		while (begintime_.before(endtime) || begintime_.equals(endtime)) {
			weeks.add(DateUtil.getWeekTime(DateUtils.getStringFromDate(begintime_, "yyyyMMdd")));
			begintime_ = DateUtils.addDays(begintime_, 1);
		}
		List<WeekendRateModel> weekendRates = weekendRateModelMapper.findWeekendRates(hotelid, roomtypeids, weeks);

		// 平日价
		rackRateModelExample = new RackRateModelExample();
		if (hotelid != null) {
			Criteria criteria = rackRateModelExample.or();
			criteria.andHotelidEqualTo(hotelid);
		}
		if (CollectionUtils.isNotEmpty(roomtypeids)) {
			Criteria criteria = rackRateModelExample.or();
			criteria.andRoomtypeidIn(roomtypeids);
		}
		// 1、查酒店的门市价
		List<RackRateModel> rackRates = rackRateMapper.selectByExample(rackRateModelExample);
		
		begintime_ = (Date) begintime.clone();
		Map<String, BigDecimal> resultMap = new HashMap<>();
		while (begintime_.before(endtime) || begintime_.equals(endtime)) {
			String yyyymmdd = DateUtils.getStringFromDate(begintime_, "yyyyMMdd");
			Map<String, BigDecimal> rackMap = new HashMap<>();
			// 1、初始化rackMap，数据为：房型id@20150524--->120(优先级3)
			for (RackRateModel rackRate : rackRates) {
				rackMap.put(rackRate.getRoomtypeid() + "@" + yyyymmdd, rackRate.getPrice());
			}
			// 2、周末价往里放(优先级2)
			for (WeekendRateModel weekRate : weekendRates) {
				int w = DateUtil.getWeekTime(yyyymmdd);
				// 判断是否和今天星期几一致
				if (w == weekRate.getWeek()) {
					rackMap.put(weekRate.getRoomtypeid() + "@" + yyyymmdd, weekRate.getPrice());
				}
			}
			// 3、特殊价往里放(优先级1)
			for (DailyRateModel dailyRate : dailyRates) {
				// 判断day是否和当天一致
				if (String.valueOf(dailyRate.getDay()).equals(yyyymmdd)) {
					rackMap.put(dailyRate.getRoomtypeid() + "@" + yyyymmdd, dailyRate.getPrice());
				}
			}
			resultMap.putAll(rackMap);
			begintime_ = DateUtils.addDays(begintime_, 1);
		}
		log.info("findRackRateByConditions:返回结果:{}", resultMap);
		return resultMap;
	}
	
	@Override
	public Boolean genRackRateAndDistributePrices(List<Long> hotelids) {
		log.info("genRackRateAndDistributePrices:hotelids:{}", hotelids);
		int c = rackRateMapper.genRackRates(hotelids);
		log.info("genRackRates:插入数量:{}", c);
		c = rackRateMapper.genRackDistributePrices(hotelids);
		log.info("genRackDistributePrices:插入数量:{}.ok", c);
		return true;
	}
}
