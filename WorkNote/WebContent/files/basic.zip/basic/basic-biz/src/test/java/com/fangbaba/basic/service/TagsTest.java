package com.fangbaba.basic.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.bean.BasicHotelTags;
import com.fangbaba.basic.face.bean.Tags;
import com.fangbaba.basic.face.service.HotelTagsService;
import com.fangbaba.basic.mappers.TagsMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/applicationContext*.xml" })
public class TagsTest {
	
	@Autowired
	TagsMapper tagsMapper;
	@Autowired
	HotelTagsService hotelTagsService;
	
	@Test
	public void TagsTest1() {
		List<Tags> tagList = new ArrayList<>();
		List<Long> ids = new ArrayList<>();
		ids.add(1l);
		ids.add(2l);
		tagList = tagsMapper.queryTagsByIds(ids);
		System.out.println(tagList);
	}
	@Test
	public void TagsTest2() {
		List<Tags> tagList = new ArrayList<>();
		tagList = tagsMapper.queryTagsByGroupId(1l);
		System.err.println(JSONObject.toJSON(tagList));
	}
	@Test
	public void TagsTest3() {
		BasicHotelTags b = hotelTagsService.queryHotelTagsByHotelid("569cbfa7e4b0b240c313f78e");
		System.out.println(JSONObject.toJSON(b));
	}
}
