package com.fangbaba.basic.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fangbaba.basic.face.bean.HotelModel;
import com.fangbaba.basic.mappers.HotelModelMapper;
import com.fangbaba.basic.po.HotelModelExample;
import com.fangbaba.basic.po.HotelModelExample.Criteria;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class HotelModelMapperTest {

	@Autowired
	HotelModelMapper hotelModelMapper;
	
	@Test
	public void testUpdateByPmsId() {
		HotelModel hotel = new HotelModel();
		hotel.setId(416l);
		hotel.setHotelname("");
		hotel.setPmstype("CQ");
		hotel.setHotelpms("3101070090");
		hotelModelMapper.updateByPmsId(hotel);
	}

	@Test
	public void testupdateByPrimaryKeySelective() {
		HotelModel hotel = new HotelModel();
		hotel.setId(416l);
		hotel.setPmstype("CQ");
		hotel.setHotelname("");
		hotel.setHotelpms("3101070090");
		hotelModelMapper.updateByPrimaryKeySelective(hotel);
	}
	@Test
	public void testupdateByExampleSelective() {
		HotelModelExample exa = new HotelModelExample();
		Criteria cri = exa.createCriteria();
		cri.andIdEqualTo(416l);
		HotelModel hotel = new HotelModel();
		hotel.setId(416l);
		hotel.setPmstype("CQ");
		hotel.setHotelname("");
		hotel.setHotelpms("3101070090");
		hotelModelMapper.updateByExampleSelective(hotel, exa);
	}
	
	@Test
	public void testselectByPrimaryKey() {
		
		HotelModel h = hotelModelMapper.selectByPrimaryKey(399l);
		System.out.println(h.getDistrictname());
		System.out.println(h.getProvincename());
		System.out.println(h.getCityname());
	}

}
