-- modify roomtype add column timestamp
ALTER table roomtype add COLUMN updatetime timestamp DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP;
