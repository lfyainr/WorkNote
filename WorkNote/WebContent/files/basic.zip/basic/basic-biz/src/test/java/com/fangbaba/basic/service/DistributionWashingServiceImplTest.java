//package com.fangbaba.basic.service;
//
//import static org.junit.Assert.fail;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//import com.alibaba.fastjson.JSONObject;
//import com.fangbaba.basic.kafka.StandardKafkaProducer;
//import com.fangbaba.basic.service.impl.DistributionWashingServiceImpl;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = { "classpath*:spring/applicationContext*.xml" })
//public class DistributionWashingServiceImplTest {
//	@Autowired
//	DistributionWashingServiceImpl distributionWashingServiceImpl;
//	@Autowired
//	StandardKafkaProducer standardKafkaProducer;
//	
//	@Test
//	public void testOpenWashing() {
//		distributionWashingServiceImpl.openWashing("0elwr9aSl6ya76RblbQdu7");
//	}
//
//	@Test
//	public void testCloseWashing() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testUpdateWashing() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testQueryWashingByHotelpms() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testQueryWashingByHotelid() {
//		fail("Not yet implemented");
//	}
//	@Test
//	public void test1() {
//		JSONObject message = new JSONObject();
//		message.put("hotelid", "3101170862");
//		message.put("flag", "T");
//		message.put("business", "switch");
//		standardKafkaProducer.sendHotelDistrictChange(message.toJSONString());
//	}
//
//}
