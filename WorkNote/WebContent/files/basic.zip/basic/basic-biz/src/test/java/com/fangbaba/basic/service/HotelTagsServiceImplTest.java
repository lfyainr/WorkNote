package com.fangbaba.basic.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.bean.Tags;
import com.fangbaba.basic.face.service.HotelTagsService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/applicationContext*.xml" })
public class HotelTagsServiceImplTest {

	@Autowired
	private HotelTagsService hotelTagsService;
	//@Test
	public void addTags() {
		List<Tags> tagList = new ArrayList<Tags>();
		for (int i = 0; i < 5; i++) {
			Tags tag = new Tags();
			tag.setCreatetime(new Date());
			tag.setTaggroupid(1l);
			tag.setTagname("太阳宫商圈:"+i);
			tagList.add(tag);
		}
		
		hotelTagsService.addTags(tagList);
	}
	
	@Test
	public void delTags() {
		List<Tags> tagList = new ArrayList<Tags>();
		for (int i = 0; i < 10; i++) {
			Tags tag = new Tags();
			tag.setId(Long.valueOf(i+9));
			tagList.add(tag);
		}
		
		hotelTagsService.delTags(tagList);
	}
	
	@Test
	public void test1(){
		System.err.println(JSONObject.toJSON(hotelTagsService.queryTagsByHotelid(35360l)));
	}
}
