package com.fangbaba.basic.service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.bean.DistributionPrice;
import com.fangbaba.basic.face.bean.RackDistributePrice;
import com.fangbaba.basic.face.service.DistributionPriceService;
import com.google.gson.Gson;
import com.mk.oms.bean.ResultDubbo;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/applicationContext*.xml" })
public class DistributionPriceServiceTest {
	@Autowired
	private DistributionPriceService distributionPriceService;

	@Test
	public void testSaveDistributionDailPrice() {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("hotelPmsNo", "3ZyeYNlYZ6LEhi6WWak1");
		JSONArray jsonArray = new JSONArray();
		JSONObject price = new JSONObject();
		price.put("roomtypePmsNo", "174We7hIxdaV8mRg5aN31qj");
		price.put("price", new BigDecimal(10.00));
		jsonArray.add(price);
		jsonObject.put("price", jsonArray);
		distributionPriceService.saveDistributionDailPrice(JSON.toJSONString(jsonObject));
	}

	@Test
	public void testSaveDistributionSpecialPrice() {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("hotelPmsNo", "3ZyeYNlYZ6LEhi6WWak1");
		JSONArray jsonArray = new JSONArray();
		JSONObject price = new JSONObject();
		price.put("roomtypePmsNo", "174We7hIxdaV8mRg5aN31qj");
		price.put("price", new BigDecimal(10.00));
		price.put("day", "2016-12-01");
		jsonArray.add(price);
		jsonObject.put("price", jsonArray);
		distributionPriceService.saveDistributionSpecialPrice(JSON.toJSONString(jsonObject));
	}

	@Test
	public void testQueryDistributionDailPrice() {
		RackDistributePrice rackDistributePrice = distributionPriceService.queryDistributionDailPrice("3ZyeYNlYZ6LEhi6WWak1", "174We7hIxdaV8mRg5aN31qj");
		System.out.println(JSON.toJSONString(rackDistributePrice));
	}

	@Test
	public void testQueryDistributionPriceByhotelIdAndRoomTypeId() {
		List<DistributionPrice> list = distributionPriceService.queryDistributionPrice("3ZyeYNlYZ6LEhi6WWak1", "174We7hIxdaV8mRg5aN31qj", "2016-11-01", "2016-12-12");
		System.out.println("结果：");
		System.out.println(new Gson().toJson(list));
	}

	@Test
	public void TestAA() {
		String hotelId = "3ZyeYNlYZ6LEhi6WWak1";

		RackDistributePrice rtnObj = distributionPriceService.queryDistributionDailPrice(hotelId, "174We7hIxdaV8mRg5aN31qj");

		ResultDubbo result = new ResultDubbo(true);

		Map<String, Object> data = new HashMap<String, Object>();
		if (rtnObj != null) {
			data.put("price", rtnObj.getPrice());
		} else {
			data.put("price", null);
		}

		result.set_DATA_(data);

		System.out.println(new Gson().toJson(result));
	}

	@Test
	public void TestBB() {
		String hotelId = "3ZyeYNlYZ6LEhi6WWak1";

		List<DistributionPrice> priceList = distributionPriceService.queryDistributionPrice(hotelId, "174We7hIxdaV8mRg5aN31qj", "2016-11-01", "2016-12-12");

		ResultDubbo result = new ResultDubbo(true);
		result.set_DATA_(priceList);

		System.out.println(new Gson().toJson(result));
	}

	@Test
	public void TestDD() {
		String hotelId = "3ZyeYNlYZ6LEhi6WWak1";
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("hotelPmsNo", hotelId);
		JSONArray jsonArray = new JSONArray();

		JSONObject price = new JSONObject();
		price.put("roomtypePmsNo", "174We7hIxdaV8mRg5aN31qj");
		price.put("price", new BigDecimal(10.00));
		jsonArray.add(price);

		jsonObject.put("price", jsonArray);
		jsonObject.put("roomtypePmsNo", "174We7hIxdaV8mRg5aN31qj");
		distributionPriceService.saveDistributionDailPrice(jsonObject.toJSONString());
	}

	@Test
	public void TestCC() {

		String hotelId = "3ZyeYNlYZ6LEhi6WWak1";

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("hotelPmsNo", hotelId);
		JSONArray jsonArray = new JSONArray();

		JSONObject price = new JSONObject();
		price.put("roomtypePmsNo", "174We7hIxdaV8mRg5aN31qj");
		price.put("price", new BigDecimal(10.00));
		price.put("day", "2016-02-28");
		jsonArray.add(price);

		jsonObject.put("price", jsonArray);

		int rtnValue = distributionPriceService.saveDistributionSpecialPrice(jsonObject.toString());
		System.out.println(new Gson().toJson(rtnValue));
		ResultDubbo result = new ResultDubbo(true);

		System.out.println(new Gson().toJson(result));

	}

	public static void main(String[] args) {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("hotelPmsNo", "3ZyeYNlYZ6LEhi6WWak1");
		JSONArray jsonArray = new JSONArray();
		JSONObject price = new JSONObject();
		price.put("roomtypePmsNo", "174We7hIxdaV8mRg5aN31qj");
		price.put("price", new BigDecimal(10.00));
		price.put("day", "2016-12-01");
		jsonArray.add(price);
		jsonObject.put("price", jsonArray);
		System.out.println(jsonObject.toJSONString());
	}

	@Test
	public void testDir() {
		String mess = "{\"startTime\":\"2016-03-01\",\"endTime\":\"2016-04-30\",\"hotelPmsNo\":\"3EoSFvFu97yHwnaFUY2xFs\",\"roomtypePmsNo\":\"0UIvSQWAx64qHaFiXhZqga\"}";
		JSONObject message = JSONObject.parseObject(mess);
		String hotelId = message.getString("hotelPmsNo");
		String roomtypePmsNo = message.getString("roomtypePmsNo");
		String startTime = message.getString("startTime");
		String endTime = message.getString("endTime");
		List<DistributionPrice> priceList = distributionPriceService.queryDistributionPrice(hotelId, roomtypePmsNo, startTime, endTime);
		System.out.println(new Gson().toJson(priceList));
	}
}
