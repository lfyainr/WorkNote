package com.fangbaba.basic.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.httpclient.NameValuePair;

import com.fangbaba.basic.util.MD5Util;
import com.fangbaba.basic.util.NetUtil;

public class HotelbusinessUtil {

	public static void main(String[] args) {
		String[] hotelids = { "2324", "45345" };
		for (String id : hotelids) {
			List<NameValuePair> params = new ArrayList<>();
			params.add(new NameValuePair("BUSINESS", "switch"));
			params.add(new NameValuePair("FLAG", "T"));
			params.add(new NameValuePair("optuser", ""));
			
			NameValuePair[] headers = { 
					new NameValuePair("HOTELID", id), 
					new NameValuePair("TOKEN", MD5Util.encryption("11111")) };
			String data = NetUtil.methodPost("http://openapi.fangbaba.com/wash/distributbusiness", headers, params.toArray(new NameValuePair[0]));
		}
	}
}