package com.fangbaba.basic.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.bean.Tags;
import com.fangbaba.basic.face.service.HotelTagsService;
import com.fangbaba.basic.face.service.TagsService;
import com.fangbaba.basic.mappers.TagsMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/applicationContext*.xml" })
public class GenHotelTagsSqlTest {
	@Autowired
	HotelTagsService hoteltagsService;
	@Autowired
	TagsService tagService;
	@Autowired
	TagsMapper tagsmapper;
	
	@Test
	public void GenHotelTagsSqltest() throws IOException {
		List<Tags> tags = tagsmapper.queryAllTags();
		Map<String, Tags> tMap = new HashMap<String, Tags>();
		for (Tags tg : tags) {
			tMap.put(tg.getTagname(), tg);
		}
		System.out.println(JSONObject.toJSON(tMap));
		String path = GenHotelTagsSqlTest.class.getResource("/").getPath()+"/酒店标签信息录入模板.xlsx";
		// 读取excel
		InputStream input = new FileInputStream(new File(path));
		
        XSSFWorkbook workBook = new XSSFWorkbook(input);
        XSSFSheet sheet = workBook.getSheetAt(0);
        if (sheet == null) {
            return;
        }
        List<Tags> rule = new ArrayList<>();
        for (int i = 0; i <= sheet.getLastRowNum(); i++) {
			XSSFRow row = sheet.getRow(i);
			
			// 找到酒店id
			Long hotelid = -1l;
			if(i > 0){
				XSSFCell cell = row.getCell(0);
				if (cell.getCellType() == cell.CELL_TYPE_NUMERIC) {
					hotelid = (long) cell.getNumericCellValue();
				}
				if (cell.getCellType() == cell.CELL_TYPE_STRING) {
					hotelid = Long.parseLong(cell.getStringCellValue());
				}
			}
			
			for (int j = 0; j < row.getLastCellNum(); j++) {
				rule.add(new Tags());
				XSSFCell cell = row.getCell(j);
				if(cell == null) continue;
				int cellValueType = cell.getCellType();
                if (cellValueType == cell.CELL_TYPE_STRING && i == 0 && j >= 3) {
                    String cellValue = cell.getStringCellValue();
                    if (!tMap.containsKey(cellValue)) {
						System.err.println(cellValue + "不包含啊");
					} else if(i == 0){
						// 初始化对应关系
						rule.set(j, tMap.get(cellValue));
					}
                }
                //i>0开始业务数据。3开始
                if(i > 0 && j >= 3){
                    if (cellValueType == cell.CELL_TYPE_NUMERIC) {
                    	Tags t = rule.get(j);
                        Double number = cell.getNumericCellValue();
                        String sql = String.format("insert into hoteltags(`hotelid`, `tagid`) values (%d, %d);", hotelid, t.getId());
                        System.err.println(sql);
                    }
                }
			}
		}
        
	}

}
