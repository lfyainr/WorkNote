package com.fangbaba.basic.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.bean.RoomtypeinfoModel;
import com.fangbaba.basic.face.service.RoomtypeinfoService;
import com.fangbaba.basic.mappers.RoomtypeinfoModelMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class RoomtypeinfoServiceImplTest {

	@Autowired
	RoomtypeinfoService roomtypeinfoService;
	@Autowired
	RoomtypeinfoModelMapper map;
	
	@Test
	public void testFindRoomtypeinfoByRoomtypeIdLong() {
		RoomtypeinfoModel r = roomtypeinfoService.findRoomtypeinfoByRoomtypeId(206l);
		System.out.println(JSONObject.toJSON(r));
	}

	@Test
	public void testxxxx() {
		RoomtypeinfoModel record = JSON.toJavaObject(JSON.parseObject("{\"bedsize\":\"2\",\"maxarea\":22,\"bedtype\":1,\"roomtypeid\":159401,\"id\":8836}"),
				RoomtypeinfoModel.class);
		int c = map.insertSelective(record);
		System.out.println(c);
	}

	@Test
	public void testFindRoomtypeinfoByRoomtypeIdListOfLong() {
		List<Long> ids = new ArrayList<Long>();
		ids.add(206l);
		ids.add(207l);
		ids.add(208l);
		List<RoomtypeinfoModel> rs = roomtypeinfoService.findRoomtypeinfoByRoomtypeIds(ids);
		System.out.println(JSONObject.toJSON(rs));
	}

}
