package com.fangbaba.basic.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fangbaba.basic.service.impl.SellPriceServiceImpl;
import com.fangbaba.order.common.utils.DateUtils;
import com.google.common.collect.Lists;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class SellPriceServiceImplTest {
	@Autowired
	private SellPriceServiceImpl sellPriceServiceImpl;

	@Test
	public void testFindRackRateByConditionsLongListOfLong() throws Exception {
//		List<Long> roomtypeids = new ArrayList<Long>();
//		roomtypeids.add(30014l);
//		roomtypeids.add(2117l);
//		roomtypeids.add(2116l);
//		Map<String, BigDecimal> rates = sellPriceServiceImpl.findRackRateByConditions(2814l, roomtypeids, 
//				DateUtils.getDateFromString("20150524"),
//				DateUtils.getDateFromString("20150529"));
//		System.err.println(rates);
		List<Long> hotelids = new ArrayList<Long>();
		hotelids.add(399l);
		hotelids.add(418l);
		sellPriceServiceImpl.genRackRateAndDistributePrices(hotelids);
	}

}
