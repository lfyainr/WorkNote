CREATE TABLE `hotel_business` (
  `id` bigint(20) NOT NULL,
  `hotelid` bigint(20) DEFAULT NULL,
  `hotelpms` varchar(45) DEFAULT NULL,
  `purchasing` int(3) DEFAULT '1' COMMENT '是否开通采购\n1 未开通\n2 开通中\n3 开通确认\n4 已开通',
  `switchs` int(3) DEFAULT NULL COMMENT '是否开通 分销\nT、F',
  `washing` int(3) DEFAULT NULL,
  `washingmode` varchar(10) DEFAULT NULL COMMENT '洗涤模式',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
