CREATE TABLE `hotel_business` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hotelid` bigint(20) DEFAULT NULL,
  `hotelpms` varchar(45) DEFAULT NULL,
  `purchasing` int(3) DEFAULT NULL COMMENT '是否开通采购\n1 未开通\n2 开通中\n3 开通确认\n4 已开通',
  `distribution` int(3) DEFAULT NULL COMMENT '是否开通 分销\nT、F',
  `washing` int(3) DEFAULT NULL,
  `washingmode` varchar(10) DEFAULT NULL COMMENT '洗涤模式',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


ALTER TABLE `gds`.`hotel` 
ADD COLUMN `state` INT(4) NULL COMMENT '酒店状态\n4店长正在编辑中，（审核通过）\n5审核中' AFTER `hotelfax`;

INSERT INTO hotel_business
(`hotelid`,`hotelpms`,`distribution`,`washing`,`washingmode`) 
SELECT 
    case when w.hotelid = null then s.hotelid else w.hotelid end 'hotelid',
    case when w.hotelpms = null then s.hotelpms else w.hotelpms end 'hotelpms',
    CASE w.is_open
        WHEN 'T' THEN 30
        ELSE 10
    END 'distribution',
    CASE s.is_open
        WHEN 'T' THEN 30
        ELSE 10
    END 'washing',
    s.washingmode
FROM
    distribution_switch w
        LEFT OUTER JOIN
    distribution_washing s ON w.hotelid = s.hotelid
    where not exists(select id from hotel_business b where b.hotelid=w.hotelid)
			and not exists(select id from hotel_business b where b.hotelid=s.hotelid);
			
UPDATE hotel_business y
        INNER JOIN
    (SELECT 
        CASE
                WHEN w.hotelid = NULL THEN s.hotelid
                ELSE w.hotelid
            END 'hotelid',
            CASE
                WHEN w.hotelpms = NULL THEN s.hotelpms
                ELSE w.hotelpms
            END 'hotelpms',
            CASE w.is_open
                WHEN 'T' THEN 30
                ELSE 10
            END 'distribution',
            CASE s.is_open
                WHEN 'T' THEN 30
                ELSE 10
            END 'washing',
            s.washingmode
    FROM
        distribution_switch w
    LEFT OUTER JOIN distribution_washing s ON w.hotelid = s.hotelid
    WHERE
        EXISTS( SELECT 
                id
            FROM
                hotel_business b
            WHERE
                b.hotelid = w.hotelid)
            OR EXISTS( SELECT 
                id
            FROM
                hotel_business b
            WHERE
                b.hotelid = s.hotelid)) x ON y.hotelid = x.hotelid 
SET 
    y.distribution = x.distribution,
    y.washing = x.washing,
    y.washingmode = x.washingmode;
