CREATE TABLE `distribution_washing` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hotelid` bigint(20) NOT NULL COMMENT '酒店id',
  `hotelpms` varchar(100) NOT NULL COMMENT '酒店pms号',
  `is_open` char(1) DEFAULT 'T' COMMENT '是否开启，F不开启，T开启',
  `washingmode` varchar(10) DEFAULT NULL COMMENT '洗涤模式：1原洗、2混洗',
  `createtime` datetime DEFAULT NULL COMMENT '创建时间',
  `createuser` varchar(20) DEFAULT NULL COMMENT '创建人',
  `updatetime` datetime DEFAULT NULL COMMENT '更新时间',
  `updateuser` varchar(20) DEFAULT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_hotelid` (`hotelid`) USING BTREE,
  KEY `idx_hotelpms` (`hotelpms`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='洗涤开关表';
