package com.fangbaba.basic.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.bean.HotelModel;
import com.fangbaba.basic.kafka.StandardKafkaProducer;
import com.fangbaba.basic.mappers.HotelModelMapper;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })

public class StandardKafkaProducerTest {

	@Autowired
	StandardKafkaProducer producter;
	
	@Autowired
	HotelModelMapper mapper;
	
	@Test
	public void testSendSyncHotelModel() {
		HotelModel hotel = mapper.selectByPrimaryKey(399l);
		JSONObject j = (JSONObject) JSONObject.toJSON(hotel);
		producter.sendSyncHotelModel(j.toJSONString());
	}

}
