package com.fangbaba.basic.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.bean.HotelModel;
import com.fangbaba.basic.face.bean.vo.HotelVo;
import com.fangbaba.basic.mappers.HotelModelMapper;
import com.fangbaba.basic.po.HotelModelExample;
import com.fangbaba.basic.service.impl.HotelServiceImpl;



@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class HotelServiceTest extends AbstractTransactionalJUnit4SpringContextTests{
	private Logger logger = LoggerFactory.getLogger(HotelServiceTest.class);
    @Autowired
    private HotelServiceImpl hotelServiceImpl;
    @Autowired
    private HotelModelMapper hotelModelMapper;
    
    
    @Before
    public void before(){

//        String sql = "delete from hotel";
//        jdbcTemplate.update(sql);
    
    }
    @Test
	public  void testQueryAllHotels() {
    	String sql = "INSERT INTO `hotel` VALUES (399, '上轩商务酒店', '上轩商务', '2015-3-26 17:12:27', '天津市和平区', 117.19590800, 39.11832800, '2014-1-28 00:00:00', '2014-2-11 00:00:00', 68, '性价比高，住宿环境、通风采光较好。', 'https://dn-imke-pro.qbox.me/FmalZsisRpZVQMWKauH3vDFJDmub', '', '3ZyeYNlYZ6LEhi6WWak123', 'T', 'T', '', '', '180000', '120000', '021-56792199', 2, 500101, '010-8189001', 500000, 500000, NULL);";
    	jdbcTemplate.update(sql);
    	 
    	List<HotelModel> list =  hotelServiceImpl.queryAllHotels();
    	

		Assert.assertNotNull(list);
		Assert.assertEquals(list.size()==1,true);
		
    }
    @Test
	public void testQueryById() {
//    	String sql = "INSERT INTO `hotel` VALUES (399, '上轩商务酒店', '上轩商务', '2015-3-26 17:12:27', '天津市和平区', 117.19590800, 39.11832800, '2014-1-28 00:00:00', '2014-2-11 00:00:00', 68, '性价比高，住宿环境、通风采光较好。', 'https://dn-imke-pro.qbox.me/FmalZsisRpZVQMWKauH3vDFJDmub', '', '3ZyeYNlYZ6LEhi6WWak123', 'T', 'T', '', '', '180000', '120000', '021-56792199', 2, 500101, '010-8189001', 500000, 500000, NULL);";
//    	jdbcTemplate.update(sql);
    	 
    	HotelModel hotelModel =  hotelServiceImpl.queryById(399L);    	
    	System.err.println(JSON.toJSON(hotelModel));
    	hotelModel.setIsselfbuildhotel("T");
    	int c = hotelModelMapper.updateByPrimaryKey(hotelModel);
    	System.err.println(c);
		Assert.assertNotNull(hotelModel);
		//Assert.assertEquals(hotelModel.getHotelname().equals("上轩商务酒店"),true);
	}

    @Test
//    @Rollback(false)
    public void testSyncHotelInfo(){
//    	String sql = "INSERT INTO `hotel` (`id`, `hotelname`, `hotelcontactname`, `regtime`, `detailaddr`, `longitude`, `latitude`, `opentime`, `repairtime`, `roomnum`, `introduction`, `businesslicensefront`, `businesslicenseback`, `hotelpms`, `isvisible`, `isonline`, `idcardfront`, `idcardback`, `retentiontime`, `defaultleavetime`, `hotelphone`, `hoteltype`, `discode`, `qtphone`, `citycode`, `provcode`, `pmstype`) VALUES ('410', '万鑫全时尚宾馆', '翁老板', '2015-03-30 12:28:10', '川黄路191号', '0.00000000', '0.00000000', '2013-02-01 00:00:01', '2013-02-01 00:00:01', '43', '\"上海万鑫全时尚宾馆位于上海市迪斯尼板块川沙镇，步行即可达川沙古镇。上海万鑫全时尚宾馆是一家集创意、设计、装饰、培训为一体的主题概念酒店，坚持“个性与原创、舒适与环保”的设计理念，以时尚、前卫为主题，定位于休闲、都市、潮流。宾馆房间设计新颖，线条简练，更配备有空调、电视等，为您旅游休闲提供便利的住宿体验\"', 'https://dn-imke-pro.qbox.me/FnYB1nVDMl-AJ81pNeOgLs9exfk0', '', '2zCMvWZL9bIWgvq5MZ8pv3', 'T', 'T', '', '', '200000', '120000', '021-50965796', NULL, '310115', '', '310000', '310000', NULL)";
//    	String sql1 = "INSERT INTO `roomtype` (`id`, `hotelid`, `name`, `roomtypepms`, `roomnum`, `cost`) VALUES ('234', '410', '时尚圆床房', '1HIIGTijVcs9cIm8QyO7s7l', '5', '188.00')";
//    	String sql2="INSERT INTO `room` (`id`, `roomtypeid`, `roomno`, `roompms`, `tel`, `remark`) VALUES ('2568', '234', '8303', '1g2gDyXAZ3CHaVanBjKVLU', '', NULL)";
//    	jdbcTemplate.update(sql);
//    	jdbcTemplate.update(sql1);
//    	jdbcTemplate.update(sql2);
    	String json = "{\"hoteladdress\":\"\",\"hotelcontactor\":\"\",\"hoteldesc\":\"\",\"hotelfax\":\"\",\"hotelgdsid\":30377,\"hotelid\":\"0RyoATnVZ80UuGQmXuYvoR\",\"hotelname\":\"连云港市冷库招待所\",\"idsmap\":{\"0g7TvV2w140pgYILes1GiC\":100073,\"0RyoATnVZ80UuGQmXuYvoR\":30377,\"2iho772Vh4bWAZCTNIL0Kd\":702605,\"2Pbw1L3pVe6qQ5hMsv5aP5\":702606,\"2rrqSxLC52VU5j8c2Z5LvI\":702607,\"3Jz9iBb5t2oGuYuFnA4DSd\":702609,\"3qiJCvCbt75pcV3doWyvl5\":702610,\"211gIVdX9p2iFAwPgIgIcwiD7\":702603,\"22h8M2HvxeFqZfIvd6F4nU\":702604,\"2VyRtmCLFh5FGklLdJcumCVu\":702608,\"0FooDBzlB67V0XuosgauYe6\":702601,\"0krtpaP5pc6qsgkCR5Vg4MQ\":702602},\"pmstype\":\"CQ\",\"roomtype\":[{\"id\":\"0g7TvV2w140pgYILes1GiC\",\"name\":\"标间\",\"price\":\"50\",\"room\":[{\"id\":\"0FooDBzlB67V0XuosgauYe6\",\"roomno\":\"301\"},{\"id\":\"0krtpaP5pc6qsgkCR5Vg4MQ\",\"roomno\":\"302\"},{\"id\":\"211gIVdX9p2iFAwPgIgIcwiD7\",\"roomno\":\"203\"},{\"id\":\"22h8M2HvxeFqZfIvd6F4nU\",\"roomno\":\"206\"},{\"id\":\"2iho772Vh4bWAZCTNIL0Kd\",\"roomno\":\"304\"},{\"id\":\"2Pbw1L3pVe6qQ5hMsv5aP5\",\"roomno\":\"204\"},{\"id\":\"2rrqSxLC52VU5j8c2Z5LvI\",\"roomno\":\"305\"},{\"id\":\"2VyRtmCLFh5FGklLdJcumCVu\",\"roomno\":\"303\"},{\"id\":\"3Jz9iBb5t2oGuYuFnA4DSd\",\"roomno\":\"306\"},{\"id\":\"3qiJCvCbt75pcV3doWyvl5\",\"roomno\":\"307\"}]}],\"timestamp\":\"20160322191002\"}";
    	hotelServiceImpl.syncHotelInfo(json);
    	
//    	HotelModel hotelModel =  hotelServiceImpl.queryById(410L); 
//		Assert.assertNotNull(hotelModel);
//		Assert.assertEquals(hotelModel.getHotelphone().equals("18600210340"),true);
//		try {
//			Thread.sleep(1000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
    }
    @Test
    public void test2(){
    	HotelModelExample example = new HotelModelExample();
		HotelModelExample.Criteria criteria = example.createCriteria();
		criteria.andHotelpmsEqualTo("0RyoATnVZ80UuGQmXuYvoR");
		List<HotelModel> list = this.hotelModelMapper.selectByExample(example);
		System.err.println(list);
    }
    
    @Test
    //@Rollback(false)
    public void testSyncHotelInfoAdd(){
    	String sql = "INSERT INTO `hotel` (`id`, `hotelname`, `hotelcontactname`, `regtime`, `detailaddr`, `longitude`, `latitude`, `opentime`, `repairtime`, `roomnum`, `introduction`, `businesslicensefront`, `businesslicenseback`, `hotelpms`, `isvisible`, `isonline`, `idcardfront`, `idcardback`, `retentiontime`, `defaultleavetime`, `hotelphone`, `hoteltype`, `discode`, `qtphone`, `citycode`, `provcode`, `pmstype`) VALUES ('410', '万鑫全时尚宾馆', '翁老板', '2015-03-30 12:28:10', '川黄路191号', '0.00000000', '0.00000000', '2013-02-01 00:00:01', '2013-02-01 00:00:01', '43', '\"上海万鑫全时尚宾馆位于上海市迪斯尼板块川沙镇，步行即可达川沙古镇。上海万鑫全时尚宾馆是一家集创意、设计、装饰、培训为一体的主题概念酒店，坚持“个性与原创、舒适与环保”的设计理念，以时尚、前卫为主题，定位于休闲、都市、潮流。宾馆房间设计新颖，线条简练，更配备有空调、电视等，为您旅游休闲提供便利的住宿体验\"', 'https://dn-imke-pro.qbox.me/FnYB1nVDMl-AJ81pNeOgLs9exfk0', '', '2zCMvWZL9bIWgvq5MZ8pv3', 'T', 'T', '', '', '200000', '120000', '021-50965796', NULL, '310115', '', '310000', '310000', NULL)";
    	String sql1 = "INSERT INTO `roomtype` (`id`, `hotelid`, `name`, `roomtypepms`, `roomnum`, `cost`) VALUES ('234', '410', '时尚圆床房', '1HIIGTijVcs9cIm8QyO7s7l', '5', '188.00')";
    	String sql2="INSERT INTO `room` (`id`, `roomtypeid`, `roomno`, `roompms`, `tel`, `remark`) VALUES ('2568', '234', '8303', '1g2gDyXAZ3CHaVanBjKVLU', '', NULL)";
    	jdbcTemplate.update(sql);
    	jdbcTemplate.update(sql1);
    	jdbcTemplate.update(sql2);
    	String json = "{\"pmstypeid\":1,\"hotelid\":\"xxxxx\",\"phone\":18600210340,\"roomtype\":[{\"id\":\"1HIIGTijVcs9cIm8QyO7s7l\",\"name\":\"hehe\",\"price\":\"300\",\"room\":[{\"id\":\"1g2gDyXAZ3CHaVanBjKVLU\",\"roomno\":\"1111\"}]},{\"id\":\"174We7hIxdaV8mRg5aN31qj\",\"name\":\"nimei\",\"price\":\"299\",\"rooms\":[{\"id\":\"1eLf2qEBdeeXtBy1aOgXzx\",\"roomno\":\"2222\"}]}]}";
    	hotelServiceImpl.syncHotelInfo(json);
		List<HotelModel> list =  hotelServiceImpl.queryAllHotels();
    	

		Assert.assertNotNull(list);
		Assert.assertEquals(list.size()==2,true);
    }
    @Test
    public void queryDetail(){
    	String sql = "INSERT INTO `hotel` (`id`, `hotelname`, `hotelcontactname`, `regtime`, `detailaddr`, `longitude`, `latitude`, `opentime`, `repairtime`, `roomnum`, `introduction`, `businesslicensefront`, `businesslicenseback`, `hotelpms`, `isvisible`, `isonline`, `idcardfront`, `idcardback`, `retentiontime`, `defaultleavetime`, `hotelphone`, `hoteltype`, `discode`, `qtphone`, `citycode`, `provcode`, `pmstype`) VALUES ('410', '万鑫全时尚宾馆', '翁老板', '2015-03-30 12:28:10', '川黄路191号', '0.00000000', '0.00000000', '2013-02-01 00:00:01', '2013-02-01 00:00:01', '43', '\"上海万鑫全时尚宾馆位于上海市迪斯尼板块川沙镇，步行即可达川沙古镇。上海万鑫全时尚宾馆是一家集创意、设计、装饰、培训为一体的主题概念酒店，坚持“个性与原创、舒适与环保”的设计理念，以时尚、前卫为主题，定位于休闲、都市、潮流。宾馆房间设计新颖，线条简练，更配备有空调、电视等，为您旅游休闲提供便利的住宿体验\"', 'https://dn-imke-pro.qbox.me/FnYB1nVDMl-AJ81pNeOgLs9exfk0', '', '2zCMvWZL9bIWgvq5MZ8pv3', 'T', 'T', '', '', '200000', '120000', '021-50965796', NULL, '310115', '', '310000', '310000', NULL)";
    	String sql1 = "INSERT INTO `roomtype` (`id`, `hotelid`, `name`, `roomtypepms`, `roomnum`, `cost`) VALUES ('234', '410', '时尚圆床房', '1HIIGTijVcs9cIm8QyO7s7l', '5', '188.00')";
    	String sql2="INSERT INTO `room` (`id`, `roomtypeid`, `roomno`, `roompms`, `tel`, `remark`) VALUES ('2568', '234', '8303', '1g2gDyXAZ3CHaVanBjKVLU', '', NULL)";
    	jdbcTemplate.update(sql);
    	jdbcTemplate.update(sql1);
    	jdbcTemplate.update(sql2);
    	Long id = 410l;
    	HotelVo vo = hotelServiceImpl.queryDetail(id, null, null);
    	Assert.assertNotNull(vo);
    }
    @Test
    public void queryByPms(){
    	String sql = "INSERT INTO `hotel` (`id`, `hotelname`, `hotelcontactname`, `regtime`, `detailaddr`, `longitude`, `latitude`, `opentime`, `repairtime`, `roomnum`, `introduction`, `businesslicensefront`, `businesslicenseback`, `hotelpms`, `isvisible`, `isonline`, `idcardfront`, `idcardback`, `retentiontime`, `defaultleavetime`, `hotelphone`, `hoteltype`, `discode`, `qtphone`, `citycode`, `provcode`, `pmstype`) VALUES ('410', '万鑫全时尚宾馆', '翁老板', '2015-03-30 12:28:10', '川黄路191号', '0.00000000', '0.00000000', '2013-02-01 00:00:01', '2013-02-01 00:00:01', '43', '\"上海万鑫全时尚宾馆位于上海市迪斯尼板块川沙镇，步行即可达川沙古镇。上海万鑫全时尚宾馆是一家集创意、设计、装饰、培训为一体的主题概念酒店，坚持“个性与原创、舒适与环保”的设计理念，以时尚、前卫为主题，定位于休闲、都市、潮流。宾馆房间设计新颖，线条简练，更配备有空调、电视等，为您旅游休闲提供便利的住宿体验\"', 'https://dn-imke-pro.qbox.me/FnYB1nVDMl-AJ81pNeOgLs9exfk0', '', '2zCMvWZL9bIWgvq5MZ8pv3', 'T', 'T', '', '', '200000', '120000', '021-50965796', NULL, '310115', '', '310000', '310000', NULL)";
    	jdbcTemplate.update(sql);
    	String pms = "2zCMvWZL9bIWgvq5MZ8pv3";
    	HotelModel vo = hotelServiceImpl.queryByPms(pms);
    	Assert.assertNotNull(vo);
    	Assert.assertEquals(vo.getHotelname().equals("万鑫全时尚宾馆"),true);
    }
    
    @Test
    public void testQueryHotelWithTagids(){
    	HotelModel h = new HotelModel();
    	List<Long> tagids = new ArrayList<>();
    	tagids.add(1l);
    	tagids.add(2l);
    	List<List<Long>> _ids = new ArrayList<>();
    	_ids.add(tagids);
    	Map<String, Object> m = hotelServiceImpl.queryByConditions(h, _ids, 1, 10);
    	JSONObject j = new JSONObject(m);
    	System.err.println(j.toJSONString());
    }
    
    @Test 
    public void testSyncStatusOnline(){
    	String json = "{\n" +
    			"	'header': {\n" +
    			"		'function': 'statusonline',\n" +
    			"		'timestamp': '20160512094823',\n" +
    			"		'pmstypeid': '2',\n" +
    			"		'uuid': '10SngTEcNcQq5YwljVTI7y'\n" +
    			"	},\n" +
    			"	'data': {\n" +
    			"		'status': '1',\n" +
    			"		'changetime': '20160518',\n" +
    			"		'hotellist': [{\n" +
    			"			'hotelid': '3101081064'\n" +
    			"		}]\n" +
    			"	}\n" +
    			"}";
    	hotelServiceImpl.syncStatusOnline(json);
    }
    @Test 
    public void testupdateHotelOnlineState(){
    	String json = "{\n" +
    			"	\"data\": [{\n" +
    			"		\"action\": \"online\",\n" +
    			"		\"time\": \"20160520172204680\",\n" +
    			"		\"hotelid\": \"56a74274e4b0b240c3140863\"\n" +
    			"	}],\n" +
    			"	\"pmstypeid\": \"2\",\n" +
    			"	\"function\": \"changeonlinestatus\",\n" +
    			"	\"uuid\": \"3DWQhgAp10CWT5yH4CVUBE\",\n" +
    			"	\"timestamp\": \"20160520172157\"\n" +
    			"}";
    	hotelServiceImpl.updateHotelOnlineState(json);;
    }
}
