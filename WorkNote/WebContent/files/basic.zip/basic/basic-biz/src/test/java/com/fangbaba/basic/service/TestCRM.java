package com.fangbaba.basic.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fangbaba.basic.face.bean.HotelModel;
import com.fangbaba.basic.face.bean.RoomModel;
import com.fangbaba.basic.face.bean.RoomtypeModel;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/applicationContext*.xml" })
public class TestCRM {
	@Autowired
	private RoomService roomService;
	@Autowired
	private RoomtypeService roomtypeService;
	@Autowired
	private HotelService hotelService;
	@Autowired
	private HotelExtensionService hotelExtensionService;

	@Test
	public void testRoom() {
		RoomModel roomModel = new RoomModel();
		roomModel.setRoompms("2eiNyEOzhaCXOXIPXMMmJCG");
		roomModel.setRemark("aaa");
		roomService.updateRoomByRoomPms(roomModel);
	}

	@Test
	public void testRoomType() {
		RoomtypeModel roomtypeModel = new RoomtypeModel();
		roomtypeModel.setRoomtypepms("174We7hIxdaV8mRg5aN31qj");
		roomtypeModel.setName("nimeimei");
		roomtypeService.updateRoomTypeByRoomTypePms(roomtypeModel);
	}

	@Test
	public void testHotel() {
		HotelModel hotelModel = new HotelModel();
		hotelModel.setHotelpms("3ZyeYNlYZ6LEhi6WWak123");
		hotelModel.setHotelname("上海如嘉宾馆1");
		hotelService.updateHotelByHotelPms(hotelModel);
	}

	@Test
	public void testHotelList() {
		hotelService.queryHotelByHotelPms("3ZyeYNlYZ6LEhi6WWak123");
	}

	@Test
	public void testHotelExtension() {
		hotelExtensionService.updatePicByHotelPms("3ZyeYNlYZ6LEhi6WWak123", "aaa");
	}

}
