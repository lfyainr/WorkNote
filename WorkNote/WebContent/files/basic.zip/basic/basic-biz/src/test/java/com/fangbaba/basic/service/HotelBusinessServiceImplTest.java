package com.fangbaba.basic.service;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSONObject;
import com.fangbaba.basic.face.base.RetInfo;
import com.fangbaba.basic.face.bean.HotelBusiness;
import com.fangbaba.basic.face.enums.HotelBusinessEnum;
import com.fangbaba.basic.face.service.HotelBusinessService;
import com.fangbaba.order.common.utils.DateUtils;
import com.lz.mongo.bislog.BisLog;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class HotelBusinessServiceImplTest {

	@Autowired
	HotelBusinessService hotelBusinessService;
	
	@Test
	public void testOpenBusiness() {
		hotelBusinessService.openBusiness("3ZyeYNlYZ6LEhi6WWak123", HotelBusinessEnum.SWITCHS, "酒店老板");
	}

	@Test
	public void testCloseBusiness() {
		hotelBusinessService.closeBusiness("3ZyeYNlYZ6LEhi6WWak123", HotelBusinessEnum.SWITCHS, "酒店老板");
	}

	@Test
	public void testQueryBusinessStateByHotelpms() {
		hotelBusinessService.queryBusinessStateByHotelpms("3101011252", HotelBusinessEnum.SWITCHS);
	}

	@Test
	public void testQueryHotelBusinessByHotelid() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateWashMode() {
		fail("Not yet implemented");
	}

	@Test
	public void testHotelConfirmSyncBusinessState() {
		hotelBusinessService.hotelConfirmSyncBusinessState("3ZyeYNlYZ6LEhi6WWak1");
	}

	@Test
	public void testUpdateBusinessData(){
		HotelBusiness hotelBusiness = new HotelBusiness();
		hotelBusiness.setHotelid(23232323l);
		HotelBusinessEnum business = HotelBusinessEnum.SWITCHS;
		Integer flag = 30;
		switch (business) {
		case SWITCHS:
			
			BisLog bisLog = new BisLog();
			bisLog.setSystem("basic");
			bisLog.setBussinessId(hotelBusiness.getHotelid().toString());
			bisLog.setBussinssType(flag.toString());
			bisLog.setContent(String.format("酒店id：%d进行【%s】的【%s】操作", hotelBusiness.getHotelid(), business.getName(), flag == 0 ? "关闭" : "开通") );
			bisLog.setCreateTime(new Date());
			System.err.println(JSONObject.toJSON(bisLog));
			hotelBusiness.setDistribution(flag);
			hotelBusiness.setDistributionCreatetime(new Date());
			break;
		case WASHING:
			hotelBusiness.setWashing(flag);
			hotelBusiness.setWashingCreatetime(new Date());
			break;
		case PURCHASING:
			hotelBusiness.setPurchasing(flag);
			hotelBusiness.setPurchasingCreatetime(new Date());
			break;
			
		default:
			break;
		}
	}
	
	@Test
	public void testqueryHotelBusinessState() {
		List<Long> hotelids = new ArrayList<Long>();
		hotelids.add(399l);
		hotelids.add(2807l);
		hotelids.add(2805l);
		Date begintime = DateUtils.getDateFromString("2016-03-01");
		Date endtime = DateUtils.getDateFromString("2016-06-01");
		RetInfo<List<Long>> ret = hotelBusinessService.queryHotelBusinessState(HotelBusinessEnum.SWITCHS, hotelids, begintime, endtime);
		System.err.println(JSONObject.toJSON(ret.getObj()));
	}
}
