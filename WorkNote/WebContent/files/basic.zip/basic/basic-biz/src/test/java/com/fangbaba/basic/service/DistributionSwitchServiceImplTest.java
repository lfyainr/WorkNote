//package com.fangbaba.basic.service;
//
//import static org.junit.Assert.fail;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//import com.fangbaba.basic.service.impl.DistributionSwitchServiceImpl;
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = { "classpath*:spring/applicationContext*.xml" })
//public class DistributionSwitchServiceImplTest {
//	@Autowired
//	DistributionSwitchServiceImpl distributionSwitchServiceImpl;
//	@Test
//	public void testOpenSwitch() {
//		distributionSwitchServiceImpl.openSwitch("0elwr9aSl6ya76RblbQdu7");
//	}
//
//	@Test
//	public void testCloseSwitch() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testUpdateSwitch() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testQuerySwitchByHotelpms() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testQuerySwitchByHotelid() {
//		fail("Not yet implemented");
//	}
//
//}
