package com.fangbaba.order.common.enums;

import com.fangbaba.order.exception.BasicException;

/**
 * 基础信息系统错误信息枚举类
 */
public enum BasicErrorEnum {
	
	// 酒店
	FIND_HOTEL_INFO("-100", "酒店信息错误."),
	
	// 酒店标签模块
    BATCH_ADD_TAGS("-101", "酒店标签批量插入出错!"),
    BATCH_DEL_TAGS("-102", "酒店标签批量删除出错!"),
	// 其他
	CUSTOME_RROR("0000",""),
	PARAMS_ERROR("10000", "非法参数请求");
	
	private final String errorCode;
	private final String errorMsg;
	
	private BasicErrorEnum(String errorCode,String errorMsg){
		this.errorCode=errorCode;
		this.errorMsg=errorMsg;
	}
	
	public BasicException getException(){
		return getBasicException(errorMsg);
	}
	
	public BasicException getBasicException(String msg){
		return new BasicException(errorCode, "", msg);//  返回输入的错误信息
	}
	
	public String getErrorCode() {
		return errorCode;
	}
	 
	public String getErrorMsg() {
		return errorMsg;
	}
	
	public static BasicErrorEnum findByCode(String code){
		for (BasicErrorEnum value : BasicErrorEnum.values()) {
			if(value.errorCode.equalsIgnoreCase(code)){
				return value;
			}
		}
		return null;
	}
}
