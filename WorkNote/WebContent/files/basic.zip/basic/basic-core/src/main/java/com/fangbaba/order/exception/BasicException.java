package com.fangbaba.order.exception;

import java.io.Serializable;

import com.fangbaba.order.common.enums.BasicErrorEnum;

/**
 * @author 李善维
 * @version 创建时间：2012-2-2 下午01:09:49
 * 
 */
public class BasicException extends RuntimeException implements Serializable{

	/**
	 * 基础信息公用exception
	 */
	private static final long serialVersionUID = 1L;
	
	private String errorCode;
	private String errorKey;
	
	public BasicException(String errorCode, String errorKey, String errorMsg) {
		super(errorMsg);
		this.errorCode = errorCode;
		this.errorKey = errorKey;
	}

	public BasicException(String errorCode,String errorKey){
		super("errorcode:"+errorCode);
		this.errorCode=errorCode;
		this.errorKey=errorKey;
	}
	
	
	public BasicException(BasicErrorEnum errorEnum){
		this(errorEnum.getErrorCode(),errorEnum.getErrorMsg());
	}
	
	public BasicErrorEnum getErrorEnum(){
		return BasicErrorEnum.findByCode(errorCode);
	}

	public final String getErrorKey() {
		return errorKey;
	}

	public final void setErrorKey(String errorKey) {
		this.errorKey = errorKey;
	}
}
